import com.sun.source.util.JavacTask;
import javax.tools.*;
import java.io.File;
import java.nio.file.*;
import java.util.*;
import java.util.stream.*;

/** Syntax-only check of every source file (no classpath needed). Reports any parse error. */
public class ParseCheck {
    public static void main(String[] args) throws Exception {
        JavaCompiler c = ToolProvider.getSystemJavaCompiler();
        List<File> files; try (Stream<Path> s = Files.walk(Path.of(args[0]))) { files = s.filter(p -> p.toString().endsWith(".java")).map(Path::toFile).collect(Collectors.toList()); }
        DiagnosticCollector<JavaFileObject> d = new DiagnosticCollector<>();
        try (StandardJavaFileManager fm = c.getStandardFileManager(d, null, null)) {
            JavacTask t = (JavacTask) c.getTask(null, fm, d, List.of("-proc:none"), null, fm.getJavaFileObjectsFromFiles(files));
            t.parse();
        }
        int n = 0; for (var x : d.getDiagnostics()) if (x.getKind() == Diagnostic.Kind.ERROR) { n++; System.out.println(x); }
        System.out.println(files.size() + " files parsed, " + n + " syntax error(s)"); System.exit(n == 0 ? 0 : 1);
    }
}
