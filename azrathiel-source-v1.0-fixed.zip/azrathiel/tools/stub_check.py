#!/usr/bin/env python3
"""Internal-consistency compile: external Bukkit/Paper/Adventure/JOML types are replaced by empty stubs, then javac runs and ONLY
errors that concern the project's own classes are shown (wrong method names, argument counts, missing fields between our own files).
Errors about external API members are expected here and are filtered out - they CANNOT be verified without the Paper jar."""
import os, re, shutil, subprocess, sys, tempfile
ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
SRC = os.path.join(ROOT, "src", "main", "java")
files = [os.path.join(dp, f) for dp, _, fs in os.walk(SRC) for f in fs if f.endswith(".java")]
ext = {}
for p in files:
    for m in re.finditer(r"^import (static )?([\w.]+?)(\.\*)?;", open(p).read(), re.M):
        fq = m.group(2)
        if m.group(1) or m.group(3): fq = ".".join(fq.split(".")[:-1]) if m.group(1) else None
        if fq and not fq.startswith(("java.", "javax.", "com.des.")) and fq.split(".")[-1][0].isupper(): ext[fq] = 1
# wildcard-imported packages: add the types we know are used from them
for fq in ["org.bukkit.Color", "org.bukkit.Location", "org.bukkit.Particle", "org.bukkit.SoundCategory", "org.bukkit.FluidCollisionMode", "org.bukkit.World",
           "org.bukkit.entity.Bat", "org.bukkit.entity.Blaze", "org.bukkit.entity.Boss", "org.bukkit.entity.EnderDragon", "org.bukkit.entity.Enemy", "org.bukkit.entity.Flying",
           "org.bukkit.entity.Monster", "org.bukkit.entity.Phantom", "org.bukkit.entity.Tameable", "org.bukkit.entity.Vex", "org.bukkit.entity.Warden", "org.bukkit.entity.Mob", "org.bukkit.entity.Entity",
           "org.bukkit.entity.LivingEntity", "org.bukkit.entity.Player",
           "org.bukkit.event.player.PlayerBedEnterEvent", "org.bukkit.event.player.PlayerChangedWorldEvent", "org.bukkit.event.player.PlayerInteractEvent", "org.bukkit.event.player.PlayerJoinEvent",
           "org.bukkit.event.player.PlayerQuitEvent", "org.bukkit.event.player.PlayerRespawnEvent", "org.bukkit.event.player.PlayerSwapHandItemsEvent", "org.bukkit.event.player.PlayerTeleportEvent"]: ext[fq] = 1
IFACES = {"Listener", "InventoryHolder", "Inventory", "Plugin", "CommandSender", "Entity", "LivingEntity", "Player", "Mob", "Monster", "Boss", "Enemy", "Flying", "Tameable", "Projectile",
          "Zombie", "Warden", "Phantom", "Vex", "Blaze", "EnderDragon", "Bat", "ItemDisplay", "Display", "Damageable", "Team", "Block", "OfflinePlayer", "ItemMeta", "CustomModelDataComponent",
          "DamageSource", "Registry", "Component", "PotionEffectType", "Attribute", "BukkitTask"}
HIER = {"LivingEntity": ["Entity", "Damageable"], "Player": ["LivingEntity", "CommandSender", "OfflinePlayer"], "Mob": ["LivingEntity"], "Monster": ["Mob"], "Boss": ["Entity"], "Enemy": ["Entity"],
        "Flying": ["Mob"], "Tameable": ["Entity"], "Projectile": ["Entity"], "Zombie": ["Monster"], "Warden": ["Monster"], "Phantom": ["Mob"], "Vex": ["Mob"], "Blaze": ["Monster"],
        "EnderDragon": ["Mob"], "Bat": ["LivingEntity"], "ItemDisplay": ["Display"], "Display": ["Entity"], "Damageable": ["Entity"],
        "EntityDamageByEntityEvent": ["EntityDamageEvent"], "YamlConfiguration": ["FileConfiguration"], "Zombie2": []}
EXTRA = {"Location": "public Location clone() { return this; } public Location add(double a, double b, double c) { return this; } public Location subtract(double a, double b, double c) { return this; }",
         "Command": "protected Command(String a, String b, String c, java.util.List<String> d) {} public void setPermission(String p) {} public boolean unregister(Object o) { return true; } public boolean execute(CommandSender s, String l, String[] a) { return true; } public java.util.List<String> tabComplete(CommandSender s, String a, String[] b) { return null; }",
         "JavaPlugin": "public java.util.logging.Logger getLogger() { return null; } public java.io.File getDataFolder() { return null; } public java.io.InputStream getResource(String s) { return null; } public Object getServer() { return null; }",
         "InventoryHolder": "Inventory getInventory();", "Listener": ""}
out = tempfile.mkdtemp(prefix="stubs_")
for fq in ext:
    pk, n = fq.rsplit(".", 1); d = os.path.join(out, *pk.split(".")); os.makedirs(d, exist_ok=True)
    if n in ("Command", "JavaPlugin") or True:
        kind = "interface" if n in IFACES else "class"; ex = HIER.get(n)
        simple = {k.rsplit(".", 1)[1]: k for k in ext}
        exq = [simple[x] for x in (ex or []) if x in simple]
        if n == "Player": exq = [simple[x] for x in ("LivingEntity", "CommandSender", "OfflinePlayer") if x in simple]
        ext_s = (" extends " + ", ".join(exq)) if exq and kind == "interface" else (" extends " + exq[0] if exq else "")
        body = EXTRA.get(n, "")
        if n == "JavaPlugin": ext_s = " implements " + simple["Plugin"] if "Plugin" in simple else ""
        open(os.path.join(d, n + ".java"), "w").write("package %s; public %s %s%s { %s }\n" % (pk, kind, n, ext_s, body))
cls = tempfile.mkdtemp(prefix="cls_")
cmd = [sys.executable and "java", "-m", "jdk.compiler/com.sun.tools.javac.Main", "-proc:none", "-Xmaxerrs", "100000", "-Xmaxwarns", "0", "-d", cls, "-sourcepath", out] + files
r = subprocess.run(cmd, capture_output=True, text=True); text = r.stderr
proj = set()
def _strip(t): t = re.sub(r"/\*.*?\*/", " ", t, flags=re.S); t = re.sub(r"//[^\n]*", " ", t); return re.sub(r'"(?:\\.|[^"\\])*"', '""', t)
for p in files:
    for n in re.findall(r"\b(?:class|interface|enum|record)\s+([A-Z]\w*)\s*[({<e]", _strip(open(p).read())): proj.add(n)
proj -= set(ext_simple) if False else set()
blocks = re.split(r"\n(?=[^\s].*\.java:\d+: error:)", text); shown = 0; ignored = 0
for b in blocks:
    if ".java:" not in b or "error:" not in b: continue
    head = b.splitlines()[0]; body = " ".join(b.splitlines()[1:])
    loc = re.search(r"location: (.*)", b); sym = re.search(r"symbol:\s+(.*)", b)
    locs = loc.group(1) if loc else ""
    locproj = any(re.search(r"\b%s\b" % re.escape(n), locs) for n in proj if n not in ("Settings",)) or "class" in locs and any(("class " + n) in locs for n in proj)
    msg = head.split("error:", 1)[1]
    internal = ("cannot be applied" in msg or "cannot be dereferenced" in msg or "incompatible" in msg or "unreported" in msg)
    ext_names = {k.rsplit(".", 1)[1] for k in ext}
    if "Annotation" in msg: ignored += 1; continue
    locproj = locproj and not any(re.search(r"\b(class|interface) %s\b" % re.escape(n), locs) for n in ext_names)
    ismine = locproj and "cannot find symbol" in msg
    mentions_ext_only = any(re.search(r"in (class|interface) %s\b" % re.escape(n), b) for n in ext_names)
    if ismine or (internal and not mentions_ext_only and any(re.search(r"\b%s\b" % re.escape(n), head + body) for n in proj) and "org.bukkit" not in b and "net.kyori" not in b):
        print(b.strip()[:600]); print("---"); shown += 1
    else: ignored += 1
print("\nstub-check: %d project-related diagnostics shown, %d external-API diagnostics ignored" % (shown, ignored))
shutil.rmtree(out, ignore_errors=True); shutil.rmtree(cls, ignore_errors=True)
sys.exit(1 if shown else 0)
