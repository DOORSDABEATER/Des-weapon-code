#!/usr/bin/env python3
"""
Generates the AZRATHIEL resource pack (assets/azrathiel/...) with NO third-party dependencies.

  python3 tools/gen_resourcepack.py              # (re)generate models, textures, item definitions, sounds.json, voice manifest
  python3 tools/gen_resourcepack.py --scan-voice # also register any .ogg voice recordings found under assets/azrathiel/sounds/voice/

IMPORTANT / HONEST NOTE: the geometry here is procedural blocky art (cuboids) and the textures are procedurally drawn
16x16 / 32x32 pixel art. They make every bone of the rig render correctly and look intentional, but they are PLACEHOLDER-GRADE
art. For a showcase look, replace the files in assets/azrathiel/models and textures with Blockbench exports using the SAME file
names - nothing in the plugin needs to change.
"""
import json, os, random, re, struct, sys, zlib

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
PACK = os.path.join(ROOT, "resourcepack")
AS = os.path.join(PACK, "assets", "azrathiel")
EIDOLONS = [("vigor", 0xFF6A1F), ("abyss", 0x6A1BFF), ("fate", 0x7FDBFF), ("ruin", 0xB31217),
            ("aegis", 0x2E6FFF), ("evolution", 0x39E06B), ("wraith", 0xC9F4F0), ("dominion", 0xFFC83D)]

def w(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w" if isinstance(data, str) else "wb") as f: f.write(data)
def wjson(path, obj): w(path, json.dumps(obj, indent=2) + "\n")
def rgb(c): return ((c >> 16) & 255, (c >> 8) & 255, c & 255)

# ------------------------------------------------------------------------------------------------ PNG writer
class Img:
    def __init__(self, wd, ht, fill=(0, 0, 0, 0)): self.w, self.h = wd, ht; self.px = [[fill] * wd for _ in range(ht)]
    def put(self, x, y, c):
        if 0 <= x < self.w and 0 <= y < self.h: self.px[y][x] = c if len(c) == 4 else (c[0], c[1], c[2], 255)
    def rect(self, x1, y1, x2, y2, c):
        for y in range(y1, y2 + 1):
            for x in range(x1, x2 + 1): self.put(x, y, c)
    def save(self, path):
        raw = b"".join(b"\x00" + bytes(v for p in row for v in p) for row in self.px)
        def ch(t, d): return struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d) & 0xFFFFFFFF)
        data = b"\x89PNG\r\n\x1a\n" + ch(b"IHDR", struct.pack(">IIBBBBB", self.w, self.h, 8, 6, 0, 0, 0)) + ch(b"IDAT", zlib.compress(raw, 9)) + ch(b"IEND", b"")
        w(path, data)

def shade(c, k): return (max(0, min(255, int(c[0] * k))), max(0, min(255, int(c[1] * k))), max(0, min(255, int(c[2] * k))), 255)

def tex_bone(seed, base=(52, 46, 58)):
    r = random.Random(seed); im = Img(16, 16)
    for y in range(16):
        for x in range(16):
            n = r.randint(-7, 7); im.put(x, y, (base[0] + n, base[1] + n, base[2] + n))
    for y in (4, 9, 14):
        for x in range(16): im.put(x, y, shade(base, 0.55))
    for x in range(16): im.put(x, 0, shade(base, 1.7)); im.put(x, 15, shade(base, 0.5))
    for y in range(16): im.put(0, y, shade(base, 1.45)); im.put(15, y, shade(base, 0.55))
    for _ in range(7): im.put(r.randint(1, 14), r.randint(1, 14), (122, 27, 255))        # faint violet cracks
    return im

def tex_gold(seed):
    r = random.Random(seed); im = Img(16, 16)
    for y in range(16):
        for x in range(16): n = r.randint(-10, 10); im.put(x, y, (230 + n // 2, 178 + n, 50 + n // 2))
    for x in range(16): im.put(x, 0, (255, 230, 140)); im.put(x, 15, (150, 105, 25))
    return im

def tex_face():
    im = Img(16, 16, (190, 184, 172, 255)); r = random.Random(7)
    for y in range(16):
        for x in range(16): n = r.randint(-6, 6); im.put(x, y, (190 + n, 184 + n, 172 + n))
    for (x0, x1) in ((2, 6), (9, 13)):
        im.rect(x0, 4, x1, 8, (12, 10, 16)); im.rect(x0 + 1, 5, x1 - 1, 7, (255, 200, 61)); im.rect(x0 + 2, 6, x0 + 2, 6, (255, 255, 220))   # glowing sockets
    im.rect(7, 9, 8, 11, (15, 12, 18))
    im.rect(3, 12, 12, 14, (20, 16, 24))
    for x in range(3, 13, 2): im.rect(x, 12, x, 14, (205, 200, 188))
    for x in range(16): im.put(x, 0, (90, 84, 96))
    return im

def tex_glow():
    im = Img(16, 16)
    for y in range(16):
        for x in range(16):
            d = max(abs(x - 7.5), abs(y - 7.5)) / 7.5; v = int(255 - 70 * d * d); im.put(x, y, (v, v, v))
    return im

def tex_shard():
    r = random.Random(11); im = Img(16, 16)
    for y in range(16):
        for x in range(16): n = r.randint(-8, 8); im.put(x, y, (58 + n, 48 + n, 84 + n))
    for i in range(16): im.put(i, i, (150, 120, 255)); im.put(15 - i, i, (110, 90, 200))
    for x in range(16): im.put(x, 0, (190, 170, 255)); im.put(x, 15, (35, 28, 55))
    return im

def tex_halo(c):
    im = Img(16, 16); base = rgb(c)
    for y in range(16):
        k = 1.25 - 0.55 * abs(y - 7.5) / 7.5
        for x in range(16): im.put(x, y, shade(base, k))
    for x in range(16): im.put(x, 0, (255, 255, 255)); im.put(x, 15, shade(base, 0.45))
    return im

GLYPHS = {
 "vigor": ["..####..", ".######.", "########", "..####..", "...##...", "...##...", "...##...", "..####.."],
 "abyss": ["..####..", ".#....#.", "#..##..#", "#.####.#", "#.####.#", "#..##..#", ".#....#.", "..####.."],
 "fate": ["........", "..####..", ".#....#.", "#..##..#", "#.####.#", ".#.##.#.", "..####..", "........"],
 "ruin": ["##....##", ".##..##.", "..####..", "...##...", "...##...", "..####..", ".##..##.", "##....##"],
 "aegis": ["########", "#......#", "#.####.#", "#.####.#", ".#.##.#.", ".#.##.#.", "..#..#..", "...##..."],
 "evolution": [".......#", "......##", ".....###", "....####", "...#####", "..######", ".#######", "########"],
 "wraith": ["..####..", ".#....#.", ".....##.", "....##..", "...##...", "...#....", "........", "...##..."],
 "dominion": ["#..##..#", "#.####.#", "########", "########", "#.#..#.#", "########", "########", "........"],
}
def tex_mark(name, c, lit):
    im = Img(16, 16, (14, 12, 20, 255)); col = rgb(c) if lit else (rgb(c)[0] // 5 + 30, rgb(c)[1] // 5 + 30, rgb(c)[2] // 5 + 30)
    for y, row in enumerate(GLYPHS[name]):
        for x, ch in enumerate(row):
            if ch == "#": im.rect(x * 2, y * 2, x * 2 + 1, y * 2 + 1, col)
    edge = rgb(c) if lit else (60, 58, 66)
    for i in range(16): im.put(i, 0, edge); im.put(i, 15, edge); im.put(0, i, edge); im.put(15, i, edge)
    return im

def tex_weapon():
    im = Img(32, 32)
    def line(x0, y0, x1, y1, c, t=1):
        n = max(abs(x1 - x0), abs(y1 - y0)) or 1
        for i in range(n + 1):
            x = round(x0 + (x1 - x0) * i / n); y = round(y0 + (y1 - y0) * i / n)
            for dx in range(-t, t + 1): im.put(x + dx, y, c); im.put(x, y + dx, c)
    for k in range(3, 0, -1): line(8, 24, 28, 4, (122, 27, 255, 70 * (4 - k)), k + 1)       # violet aura
    line(8, 24, 28, 4, (48, 44, 62), 1); line(9, 23, 29, 3, (150, 140, 175), 0)             # dark-steel blade with bright edge
    for i, (n, c) in enumerate(EIDOLONS):                                                   # eight inset gems along the blade
        t = (i + 1) / 9.0; x = round(8 + 20 * t); y = round(24 - 20 * t); im.rect(x - 1, y - 1, x, y, rgb(c))
    line(4, 20, 14, 28, (255, 200, 61), 0); line(5, 20, 15, 28, (200, 150, 30), 0)          # gold cross-guard
    line(7, 25, 3, 29, (38, 30, 44), 1); im.rect(2, 29, 3, 30, (255, 200, 61))              # grip and pommel
    return im

# ------------------------------------------------------------------------------------------------ models
FACES = ["north", "east", "south", "west", "up", "down"]
def C(x1, y1, z1, x2, y2, z2): return [8 + x1, 8 + y1, 8 + z1], [8 + x2, 8 + y2, 8 + z2]

def el(box, tex="#0", tint=False, rot=None, face_tex=None, faces=None):
    frm, to = box; wd, ht, dp = to[0] - frm[0], to[1] - frm[1], to[2] - frm[2]
    dims = {"north": (wd, ht), "south": (wd, ht), "east": (dp, ht), "west": (dp, ht), "up": (wd, dp), "down": (wd, dp)}
    f = {}
    for k in (faces or FACES):
        a, b = dims[k]; fc = {"uv": [0, 0, round(min(16, max(1, a)), 2), round(min(16, max(1, b)), 2)], "texture": (face_tex or {}).get(k, tex)}
        if tint: fc["tintindex"] = 0
        f[k] = fc
    e = {"from": [round(v, 3) for v in frm], "to": [round(v, 3) for v in to], "faces": f}
    if rot: e["rotation"] = {"angle": rot[0], "axis": rot[1], "origin": [round(v, 3) for v in rot[2]]}
    return e

def mirror(box): (x1, y1, z1), (x2, y2, z2) = box; return [16 - x2, y1, z1], [16 - x1, y2, z2]
def pivot(box): (x1, y1, z1), (x2, y2, z2) = box; return [(x1 + x2) / 2, (y1 + y2) / 2, (z1 + z2) / 2]

def model(elements, textures):
    return {"textures": dict(textures, particle=list(textures.values())[0]), "elements": elements,
            "display": {"fixed": {"rotation": [0, 0, 0], "translation": [0, 0, 0], "scale": [1, 1, 1]}}}

T = lambda n: "azrathiel:item/" + n
MODELS = {}   # key -> (model json, uses tint)

def add(key, elements, textures, tint=False): MODELS[key] = (model(elements, textures), tint)

def horn(sign, y0, out_rot=22.5, tex="#0"):
    """three stacked boxes curving up and outward"""
    els = []
    for i in range(3):
        x = sign * (3.6 + i * 1.6); y = y0 + i * 2.0; b = C(x - 0.9, y, -0.9, x + 0.9, y + 2.4, 0.9)
        els.append(el(b, tex, rot=(out_rot * sign * -1, "z", pivot(b))))
    return els

def build_models():
    bone = {"0": T("bone_armor"), "1": T("skull_face"), "2": T("shard"), "3": T("gold_trim")}
    # ---- Dormant ----
    e = [el(C(-3.6, -3.2, -3.4, 3.6, 3.8, 3.4), face_tex={"south": "#1"}), el(C(-2.6, -5.2, -2.4, 2.6, -3.2, 2.6)), el(C(-4.2, 2.0, -3.0, 4.2, 3.2, 3.6)),
         el(C(-0.6, 3.8, -0.6, 0.6, 7.6, 0.6), "#3"), el(C(-4.4, -2.5, -2.0, -3.6, 1.5, 2.0)), el(C(3.6, -2.5, -2.0, 4.4, 1.5, 2.0)), el(C(-1, -2, 3.4, 1, 5, 5.0), "#2")]
    b1 = C(-2.6, 3.8, -0.4, -1.6, 6.2, 0.4); b2 = C(1.6, 3.8, -0.4, 2.6, 6.2, 0.4)
    e += [el(b1, "#3", rot=(22.5, "z", pivot(b1))), el(b2, "#3", rot=(-22.5, "z", pivot(b2))), el(C(-6.4, -1, -1.5, -4.8, 3, 1.5), "#2"), el(C(4.8, -1, -1.5, 6.4, 3, 1.5), "#2")]
    add("dormant/body", e, bone)
    ring = []
    for sx in (-1, 1):
        ring.append(el(([8 - 2.7, 8 + sx * 6.5 - 0.6, 7.4], [8 + 2.7, 8 + sx * 6.5 + 0.6, 8.6]), "#0", tint=True))
        ring.append(el(([8 + sx * 6.5 - 0.6, 8 - 2.7, 7.4], [8 + sx * 6.5 + 0.6, 8 + 2.7, 8.6]), "#0", tint=True))
    for sx, sy in ((1, 1), (-1, -1), (1, -1), (-1, 1)):
        cx, cy = 8 + sx * 4.6, 8 + sy * 4.6; ring.append(el(([cx - 2.7, cy - 0.6, 7.4], [cx + 2.7, cy + 0.6, 8.6]), "#0", tint=True, rot=(-45 if sx == sy else 45, "z", [cx, cy, 8])))
    add("dormant/ring", ring, {"0": T("glow_white")}, True)
    core = [el(C(-3, -3, -3, 3, 3, 3), "#0", True, rot=(45, "y", [8, 8, 8])), el(C(-3, -3, -3, 3, 3, 3), "#0", True, rot=(45, "x", [8, 8, 8])), el(C(-3, -3, -3, 3, 3, 3), "#0", True, rot=(45, "z", [8, 8, 8]))]
    add("core", core, {"0": T("glow_white")}, True)
    spikes = list(core)
    for (a, b_) in ((C(-0.5, -0.5, 4, 0.5, 0.5, 8)), (C(-0.5, -0.5, -8, 0.5, 0.5, -4)), (C(-0.5, 4, -0.5, 0.5, 8, 0.5)), (C(-0.5, -8, -0.5, 0.5, -4, 0.5)), (C(4, -0.5, -0.5, 8, 0.5, 0.5)), (C(-8, -0.5, -0.5, -4, 0.5, 0.5))):
        spikes.append(el(([a[0], a[1], a[2]], [b_[0], b_[1], b_[2]]), "#0", True))
    add("core_apoc", spikes, {"0": T("glow_white")}, True)
    add("frag_a", [el(C(-1, -5, -1, 1, 5, 1), "#0", rot=(22.5, "z", [8, 8, 8])), el(C(-1.5, -2, -1.5, 1.5, 2, 1.5), "#0")], {"0": T("shard")})
    wedge = C(-2, -4, -1, 2, 4, 1); add("frag_b", [el(wedge, "#0", rot=(45, "x", pivot(wedge))), el(C(-1, -5, -0.5, 1, 5, 0.5), "#0")], {"0": T("shard")})
    add("frag_c", [el(C(-0.8, -5, -0.8, 0.8, 5, 0.8), "#0", rot=(45, "z", [8, 8, 8])), el(C(-0.8, -5, -0.8, 0.8, 5, 0.8), "#0", rot=(-45, "z", [8, 8, 8]))], {"0": T("shard")})

    # ---- Released / Apocalypse bodies ----
    def torso(apoc):
        t = [el(C(-7, -6, -4.2, 7, 9, 4.2)), el(C(-5.5, -9, -3.2, 5.5, -6, 3.2)), el(C(-5.5, -4, 4.2, 5.5, 8, 4.9)), el(C(-3, -8, -5.2, 3, 9, -4.2)), el(C(-4, 9, -2.6, 4, 11, 2.6)),
             el(C(-2.6, 1.2, 4.9, 2.6, 6.4, 5.2), "#2")]
        for i in range(4): t.append(el(C(-6, -3 + i * 2.4, 4.9, 6, -3 + i * 2.4 + 0.9, 5.4)))
        for s in (-1, 1):
            pa = C(7, 4.5, -3.2, 12, 10, 3.2) if s == 1 else C(-12, 4.5, -3.2, -7, 10, 3.2); t.append(el(pa))
            sp = C(8.5, 9, -0.8, 12, 13.5, 0.8) if s == 1 else C(-12, 9, -0.8, -8.5, 13.5, 0.8); t.append(el(sp, "#3" if apoc else "#0", rot=(-22.5 * s, "z", pivot(sp))))
        for i, x in enumerate((-3, 0, 3)): bk = C(x - 0.6, 8, -6.5, x + 0.6, 14 + (i == 1) * 2, -5); t.append(el(bk, "#3" if apoc else "#2", rot=(-22.5, "x", pivot(bk))))
        if apoc:
            t += [el(C(-0.9, 9, 4.9, 0.9, 16, 6.2), "#3"), el(C(-6.5, 7.5, 4.2, 6.5, 8.6, 5.0), "#3"), el(C(-8, -9.4, -4, 8, -8.6, 4), "#3")]
            for s in (-1, 1):
                cr = C(5 * s - 0.8, 10, -0.8, 5 * s + 0.8, 17, 0.8) if s == 1 else C(-5.8, 10, -0.8, -4.2, 17, 0.8); t.append(el(cr, "#3", rot=(-22.5 * s, "z", pivot(cr))))
        return t
    add("released/torso", torso(False), bone); add("apoc/torso", torso(True), bone)

    def head(apoc):
        h = [el(C(-4.2, -3.6, -4, 4.2, 4.6, 4), face_tex={"south": "#1"}), el(C(-3, -6, -3, 3, -3.6, 3)), el(C(-4.8, 2.6, -3.4, 4.8, 3.8, 4.4)), el(C(-5, -2, -2.4, -4.2, 2.6, 2.4)), el(C(4.2, -2, -2.4, 5, 2.6, 2.4))]
        h += horn(-1, 3.0) + horn(1, 3.0)
        if apoc:
            for i, x in enumerate((-3.2, -1.6, 0, 1.6, 3.2)):
                sp = C(x - 0.6, 4.6, -0.6, x + 0.6, 8.5 + (3 - abs(i - 2)) * 1.6, 0.6); h.append(el(sp, "#3", rot=([-22.5, -22.5, 0, 22.5, 22.5][i], "z", pivot(sp))))   # vanilla only allows 0, +-22.5, +-45
        return h
    add("released/head", head(False), bone); add("apoc/head", head(True), bone)
    ua = [el(C(-1.8, -9.3, -1.8, 1.8, 0, 1.8)), el(C(-2.6, -8, -2.6, 2.6, -3, 2.6), "#2"), el(C(-2.6, -2.6, -2.6, 2.6, 2.6, 2.6)), el(C(-0.8, -9.3, 1.8, 0.8, -4, 2.8), "#3")]
    add("released/arm_upper", ua, bone)
    la = [el(C(-1.4, -9.3, -1.4, 1.4, 0, 1.4)), el(C(-2.2, -3, -2.2, 2.2, 0.6, 2.2), "#2"), el(C(-2.0, -11.2, -0.6, -1.2, -9.3, 0.6)), el(C(-0.4, -11.8, -0.6, 0.4, -9.3, 0.6)), el(C(1.2, -11.2, -0.6, 2.0, -9.3, 0.6))]
    add("released/arm_lower", la, bone)
    hs = [el(C(-1.4, -5.5, -0.8, 1.4, 5.5, 0.8), "#0", True), el(C(-2.2, -4.5, -0.4, -1.4, 4.5, 0.4), "#0", True)]
    add("released/halo_seg", hs, {"0": T("glow_white")}, True)
    for name, c in EIDOLONS:
        add("apoc/halo_" + name, [el(C(-1.4, -5.5, -0.8, 1.4, 5.5, 0.8), "#0"), el(C(1.4, -1.8, -0.5, 3.8, 1.8, 0.5), "#0"), el(C(-3.8, -1.8, -0.5, -1.4, 1.8, 0.5), "#0")], {"0": T("halo_" + name)})
        for suffix in ("", "_dim"):
            add("mark/" + name + suffix, [el(([0, 0, 7.7], [16, 16, 8.3]), "#0", faces=["north", "south"])], {"0": T("mark_" + name + suffix)})

def build_textures():
    tx = os.path.join(AS, "textures", "item")
    tex_bone(3).save(os.path.join(tx, "bone_armor.png")); tex_gold(5).save(os.path.join(tx, "gold_trim.png")); tex_face().save(os.path.join(tx, "skull_face.png"))
    tex_glow().save(os.path.join(tx, "glow_white.png")); tex_shard().save(os.path.join(tx, "shard.png")); tex_weapon().save(os.path.join(tx, "weapon.png"))
    for name, c in EIDOLONS:
        tex_halo(c).save(os.path.join(tx, "halo_" + name + ".png"))
        tex_mark(name, c, True).save(os.path.join(tx, "mark_" + name + ".png")); tex_mark(name, c, False).save(os.path.join(tx, "mark_" + name + "_dim.png"))

# ------------------------------------------------------------------------------------------------ sounds + voice manifest
SFX = {  # custom event -> (vanilla event, volume, pitch). Replace later with real .ogg by pointing "name" at your file.
 "cast.vigor": ("minecraft:entity.iron_golem.damage", 1.0, 0.6), "cast.abyss": ("minecraft:entity.enderman.teleport", 1.0, 0.5),
 "cast.fate": ("minecraft:block.amethyst_block.resonate", 1.0, 1.0), "cast.ruin": ("minecraft:entity.wither.shoot", 1.0, 0.6),
 "cast.aegis": ("minecraft:block.beacon.activate", 1.0, 1.0), "cast.evolution": ("minecraft:block.respawn_anchor.charge", 1.0, 1.2),
 "cast.wraith": ("minecraft:particle.soul_escape", 1.0, 0.8), "cast.dominion": ("minecraft:entity.ender_dragon.growl", 0.8, 0.7),
 "transform": ("minecraft:entity.wither.spawn", 0.9, 0.7), "release": ("minecraft:block.beacon.power_select", 1.0, 0.8), "dismiss": ("minecraft:block.beacon.deactivate", 1.0, 0.8),
 "summon": ("minecraft:block.beacon.activate", 1.0, 0.7), "ultimate.awaken": ("minecraft:entity.ender_dragon.growl", 1.0, 0.5), "ultimate.charge": ("minecraft:entity.warden.sonic_charge", 1.0, 0.8),
 "ultimate.main": ("minecraft:entity.warden.sonic_boom", 1.0, 0.7), "ultimate.impact": ("minecraft:entity.generic.explode", 1.0, 0.6), "lastguardian": ("minecraft:entity.warden.roar", 1.0, 0.7),
 "intercept": ("minecraft:item.shield.block", 1.0, 1.0), "hit": ("minecraft:entity.player.attack.strong", 1.0, 0.9), "combo": ("minecraft:block.end_portal.spawn", 0.8, 1.2)}

def parse_voice(path):
    cats = {}; out = []; cur = None
    eid = {n for n, _ in EIDOLONS}
    for raw in open(path, encoding="utf-8").read().splitlines():
        s = raw.strip()
        if not s or s.startswith("#"): continue
        if s.startswith("@"): cur = s[1:].strip().lower(); continue
        sub = eidol = None
        while s.startswith("["):
            j = s.index("]"); tag = s[1:j].strip(); s = s[j + 1:].lstrip()
            if tag.startswith("#"): sub = tag[1:].lower()
            elif tag.lower() in eid: eidol = tag.lower()
        cats[cur] = cats.get(cur, 0) + 1
        out.append({"id": "%s.%03d" % (cur, cats[cur]), "sound": "%s_%03d" % (cur, cats[cur]), "category": cur, "sub": sub, "eidolon": eidol, "text": s})
    return out

def build_sounds(scan):
    ev = {k: {"sounds": [{"name": v[0], "type": "event", "volume": v[1], "pitch": v[2]}]} for k, v in SFX.items()}
    found = 0
    if scan:
        base = os.path.join(AS, "sounds", "voice")
        for dp, _, fs in os.walk(base):
            for f in fs:
                if not f.endswith(".ogg"): continue
                rel = os.path.relpath(os.path.join(dp, f), os.path.join(AS, "sounds")).replace("\\", "/")[:-4]; parts = rel.split("/")
                if len(parts) == 2: ev["voice." + parts[1]] = {"sounds": [{"name": "azrathiel:" + rel, "stream": True}]}; found += 1
                elif len(parts) == 4 and parts[1] == "layers": ev["voice.layer.%s.%s" % (parts[2], parts[3])] = {"sounds": [{"name": "azrathiel:" + rel, "stream": True}]}; found += 1
    wjson(os.path.join(AS, "sounds.json"), ev); return found

def build_manifest():
    voice = os.path.join(ROOT, "src", "main", "resources", "azrathiel", "voice", "vaelzarion_voice.txt")
    lines = parse_voice(voice); man = []
    for l in lines:
        have = os.path.exists(os.path.join(AS, "sounds", "voice", l["sound"] + ".ogg"))
        e = dict(l, file="assets/azrathiel/sounds/voice/%s.ogg" % l["sound"], status="RECORDED" if have else "MISSING_RECORDING")
        e["layers"] = {n: "assets/azrathiel/sounds/voice/layers/%s/%s.ogg" % (n, l["sound"]) for n, _ in EIDOLONS}
        man.append(e)
    wjson(os.path.join(PACK, "voice_manifest.json"), {"note": "Every authored line, its text, and the file name the plugin will look for. NO recordings are included.", "count": len(man), "lines": man})
    return len(man)

def main():
    scan = "--scan-voice" in sys.argv
    build_models(); build_textures()
    for key, (m, tint) in MODELS.items():
        wjson(os.path.join(AS, "models", key + ".json"), m)
        item = {"model": {"type": "minecraft:model", "model": "azrathiel:" + key}}
        if tint: item["model"]["tints"] = [{"type": "minecraft:custom_model_data", "index": 0, "default": 16777215}]
        wjson(os.path.join(AS, "items", key + ".json"), item)
    wjson(os.path.join(AS, "models", "weapon.json"), {"parent": "minecraft:item/handheld", "textures": {"layer0": "azrathiel:item/weapon"}})
    wjson(os.path.join(AS, "items", "weapon.json"), {"model": {"type": "minecraft:model", "model": "azrathiel:weapon"}})
    n = build_sounds(scan); c = build_manifest()
    wjson(os.path.join(PACK, "pack.mcmeta"), {"pack": {"description": "AZRATHIEL assets - MERGE the assets/azrathiel folder into the DeS pack; keep the DeS pack's own pack.mcmeta", "pack_format": 46,
             "supported_formats": {"min_inclusive": 46, "max_inclusive": 99}}})
    print("models: %d  textures: %d  sound events: %d (+%d voice files)  voice manifest lines: %d" % (len(MODELS) + 1, len(os.listdir(os.path.join(AS, "textures", "item"))), len(SFX), n, c))

if __name__ == "__main__": main()
