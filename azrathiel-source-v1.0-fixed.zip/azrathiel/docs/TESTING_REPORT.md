# Testing report — what was actually verified

Legend: **VERIFIED** = executed and passed here · **STATIC** = checked by tooling, not executed · **NOT VERIFIED** = needs your server.

## Executed here (VERIFIED) — `tools/run_core_tests.sh`, 79 checks, 0 failures
The pure-logic packages (`core/`) compile with plain `javac` and were run:
* exactly **255** Eidolon combinations; all build valid specs; **255 unique names**; the **10 required handcrafted names resolve exactly**; custom ordering preserved; balance multiplier applied; empty combination rejected
* animation: **25 states** all have valid poses; priority rules (lower cannot interrupt higher, DAMAGE_REACTION cannot interrupt MELEE_ATTACK, ABILITY_CAST can); one-shots end and fall back to base; flicker guard; continuity across all base-state swaps; LAST_GUARDIAN and ULTIMATE_CHARGE converge to their intended postures; DISMISS shrinks
* kinematics: spring follow converges, **never overshoots**, per-tick step bounded (no snapping), shortest-arc turning, turn-rate cap
* voice library: parses with 0 problems; **504 lines**; every category meets its minimum target; **0 duplicate lines**; unique ids; every Eidolon has ≥5 ability and ≥6 personality lines; every secret line requires an explicit trigger; signature ultimate line present
* dialogue director: silent mode; disabled categories; interruption by priority; category cooldown; LAST_GUARDIAN outranks all; shuffle-bag gives **no repeats**; reset on dismiss; Eidolon-owned lines; secrets never fire without trigger and are rare (≈40%) when triggered; personality weighting; history
* threat model, ability chooser (low health → AEGIS; crowd → ABYSS/DOMINION; ranged → FATE; **stops repeating an ineffective ability**; nothing chosen on cooldown), essence resource

## Executed here — resource pack (`tools/verify_pack.py`, VERIFIED)
All JSON valid; every referenced texture exists; every element within legal model bounds; every model key used by `ModelDefs` exists as a model **and** an item definition. Textures were inspected visually. **Not** verified: how it looks in a Minecraft client.

## Static only (STATIC)
* `tools/ParseCheck.java`: all 50 source files parse with zero syntax errors
* `tools/check_imports.py`: no unresolved type names
* `tools/member_check.py`: 693 cross-class member accesses resolve
* `tools/stub_check.py`: compile against empty stubs of the Bukkit types; no inconsistencies between the project's own classes. **Blind spot:** errors hidden behind unresolved external expressions (it caught 2 of 3 deliberately injected bugs). It cannot validate any Paper/Bukkit/Adventure/JOML call.

## NOT VERIFIED — needs a Paper server (nothing below has ever run)
Plugin startup/shutdown · commands and permissions · summon/dismiss · all three forms · model/animation loading and appearance · idle floating and following smoothness · root-teleport-with-passengers behaviour · four-arm animation · halo/fragment motion · guardian positioning · every offensive ability's real damage · all 10 handcrafted finales · custom loadouts · GUI · voice triggers in play · eightfold layering (no recordings exist) · ultimate · autonomous combat · master protection / interception · LAST GUARDIAN · respawn · persistence across restart · chunk unload recovery · bosses · multi-target fights · performance under load.

### How to verify on your server (≈5 minutes)
1. Install, merge the pack, start. Console must show `AZRATHIEL ready: 504 voice lines, 255 Convergences ...` and no stack traces.
2. `/azrathiel admin give <you>`, right-click the vessel, then run **`/azrathiel admin selftest`** while standing in an open area. It spawns 2000-HP dummies and, with **cosmetics OFF and animation/voice suppressed**, executes every Eidolon, every handcrafted Convergence, a custom 4-way order and the ultimate, checking: real health loss, **attribution to the master**, **cooldown refusal of a second cast**, **multi-target ultimate damage** (3 dummies). It prints PASS/FAIL per case to chat and console.
3. Visual checks (use `/azrathiel animation state <NAME>` or the Animation GUI to preview every state): float, follow while sprinting/flying/swimming, turn, release, apocalypse, dismiss.
4. Die in Released form: LAST GUARDIAN, shockwave, exhaustion, respawn recognition. Restart the server: bond/loadouts/combos persist; no duplicate entities.
