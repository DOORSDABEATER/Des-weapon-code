# Voice assets: how to turn the text into VAELZARION's voice

**No recordings are included.** `resourcepack/voice_manifest.json` lists every one of the 504 lines with its id, category, optional Eidolon, text and the exact file name the plugin looks for.

## Files
* Primary voice: `assets/azrathiel/sounds/voice/<soundName>.ogg` — e.g. `summon_dismiss_001.ogg` (id `summon_dismiss.001`).
* Eidolon layers (optional, same length/timing as the primary): `assets/azrathiel/sounds/voice/layers/<eidolon>/<soundName>.ogg`.
* After adding files run `python3 tools/gen_resourcepack.py --scan-voice`; it registers `voice.<soundName>` and `voice.layer.<eidolon>.<soundName>` in `sounds.json`. Then set `voice.recordings-installed: true`.
* Mono OGG Vorbis, 44.1 kHz. Mono is required for positional audio.

## Direction (from the spec)
Primary voice: extremely deep, ancient, masculine, calm, deliberate, clear; terrifying but controlled when angry (lower and colder, not louder). Eight Eidolon textures: Vigor aggressive; Abyss hollow/echoing; Fate prophetic/emotionless; Ruin harsh; Aegis protective/reassuring; Evolution analytical; Wraith spectral/distant; Dominion royal. Lines tagged `[VIGOR]`... in the text file are spoken *by that Eidolon*.

## Runtime behaviour once recordings exist
* Primary plays at `voice volume × form volume × Eidolon volume`, pitch from the bond's pitch setting.
* Layers (Released/Apocalypse only): gain = layer-intensity × (0.25 calm, 0.55 in combat, 1.0 ultimate); each Eidolon layer is placed on a ring 2.5 blocks around the entity; kept at 35% of the primary so the primary stays dominant and intelligible. All eight layers only play for Apocalypse lines; otherwise only awakened (enabled) Eidolons contribute.
* Echo: two delayed, quieter repeats scaled by the reverb setting.

## Extending the dialogue
Drop another `*.txt` into `plugins/<DeS>/azrathiel/voice/` (same format as `vaelzarion_voice.txt`, documented at the top of `core/VoiceLibrary.java`) and `/azrathiel reload`. Ids continue numbering per category across packs, so existing ids/files never change as long as the core pack loads first.
