# Known limitations, placeholders and asset requirements

Nothing here is hidden behind a "complete" label. Items are grouped by how much they matter.

## 1. Not delivered / not done
* **No compiled JAR.** The build sandbox had no network access, so `paper-api` could not be fetched. Build with `mvn package`.
* **Never compiled against Paper, never run on a server.** See `TESTING_REPORT.md`. Expect a small number of compile fixes (renamed API members between Paper versions) and some first-run bugs. The pure logic (`core/`) is tested; the server-facing code is not.
* **No voice recordings.** Zero audio files exist. The 504 lines are *authored text*. Until you record them, VAELZARION is subtitles + a low vanilla cue for important lines (`voice.recordings-installed: false`). I did not, and cannot, produce the deep ancient voice, the eight Eidolon vocal textures or the eightfold ultimate treatment.
* **Models are procedural placeholders, not a sculpted Blockbench model.** 39 cuboid-built models (torso, skull, four-arm segments, halo segments, shards, markings...) and procedurally drawn pixel textures. They are correct, rigged and legible, but they will not look like a hand-made boss model. Replace the files in `resourcepack/assets/azrathiel/models|textures` with Blockbench exports **using the same names** (bone pivots are at the model centre `8,8,8`; arms hang down from the pivot) — no code change needed.
* **No skeletal-mesh animation library.** The spec asks for the "best compatible model/animation technology". I chose a built-in bone rig on vanilla `item_display` entities (hierarchical matrices, client-side interpolation, one root teleport) because it needs no dependency and I could not verify ModelEngine/BetterModel APIs offline. If DeS already uses one of them, swap `RigModel` for an adapter (the rest of the code only talks to `RigModel.render/teleport/remove/valid`). There is **no automatic fallback** if the pack is missing: bones render as vanilla "missing model" cubes, which makes the problem obvious but ugly.

## 2. Unverified assumptions that could break at runtime
* The rig moves **one root display with `TeleportFlag.EntityState.RETAIN_PASSENGERS`** and relies on the client interpolating passengers with the vehicle. If your build does not interpolate passenger display entities, motion will look steppy; `entity.move-interval-ticks`, `anim-interval-ticks` and `smooth-time` are the knobs, and `RigModel.valid()` triggers an automatic rebuild if teleports start failing.
* Bone `Transformation` interpolation (delay 0 / duration = anim interval) assumed to give continuous motion; fast halo spin could alias on slow clients (speeds are capped by pose values).
* Theme colour uses the `custom_model_data` tint source (1.21.4+ item-model format). Untested.
* `ProjectileHitEvent` cancellation is used for interception; behaviour for every projectile type is untested.
* Damage uses `DamageSource` with the master as causing entity (kill credit, claim plugins). If a protection plugin cancels it, abilities will correctly deal nothing there.
* Compiled against API 1.21.4. Paper 26.x is expected to run it through the plugin compatibility layer; unverified.

## 3. Design limits (by choice or constraint)
* **DSP effects cannot run in-game.** Pitch and volume are real; *reverb/echo* is approximated with delayed quieter repeats; *distortion* and the "subtle supernatural" colouring must be baked into the recordings. The settings exist; distortion has no runtime effect.
* The voice **layering** (primary + up to eight Eidolon layers, louder in combat, strongest in the ultimate, spatially arranged around the entity) is implemented in `Voice.recorded()` but can only be heard once `voice/layers/<eidolon>/<id>.ogg` files exist.
* VAELZARION is **not damageable** by mobs (display entities are not valid targets); "entity death" is handled as loss of the rig (auto-rebuild) and the master-death flow. There is no VAELZARION health bar.
* Per-combination *effect editing* is not exposed in the GUI (damage/cooldown/cost are server-side balance multipliers, global and per-Eidolon, in `config.yml`). Ordering, saving, renaming, duplicating, favouriting, presets, testing and preview **are** exposed.
* Per-form audio profiles = per-form **volume**; pitch/reverb are global per bond.
* Progression is kill/boss-point based, add-only. Individual "awakening quests" are not implemented.
* Single-player-bond model: one bond per player UUID.
* Balance numbers (damage, cooldowns, essence costs, ultimate damage) are first-pass and **untested in play**.
* Performance: a Released/Apocalypse guardian is 36 display entities (35 bones + root). Default cap is 40 active guardians; real cost has not been measured. Only bones whose transform actually changed are re-sent.

## 4. Where each spec item stands
| Spec item | State |
|---|---|
| Three forms with distinct models | implemented, procedural art |
| 25 animation states + state machine | implemented, unit-tested |
| Independent four arms / fragments / halo | implemented in rig maths, not seen in a client |
| Eight Eidolons with real mechanics | implemented, not run |
| 255 combinations, 10 handcrafted | engine unit-tested; finales not run |
| Workshop (select/preview/save/rename/delete/duplicate/favourite/order/test) | implemented, not run |
| Loadout (presets, ordering, full arsenal, no slot cap) | implemented, not run |
| Autonomous AI, guardian positioning, interception | implemented, not run |
| Voice library 400-500+ | **504 lines, tested** |
| Voice recordings / layered audio | **architecture only** |
| Master bond, admin reassign, persistence | implemented, not run |
| LAST GUARDIAN (finite, cooldown, shockwave, exhaustion) | implemented, not run |
| Ultimate (6 phases, damage independent of visuals) | implemented, not run; self-test covers it |
| Visual themes (8) + customisation | implemented, not run |
| Performance / config validation | clamping implemented; load unmeasured |

## 5. Asset requirements to reach the intended experience
1. Record/commission the voice (see `VOICE_ASSETS.md`).
2. Replace placeholder models/textures with Blockbench work (same file names).
3. Optionally replace the `sounds.json` vanilla mappings (`cast.*`, `ultimate.*`, `transform`...) with real `.ogg` effects.
