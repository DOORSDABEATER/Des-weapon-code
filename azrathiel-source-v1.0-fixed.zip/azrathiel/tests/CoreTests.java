import com.des.weapons.azrathiel.core.*;
import java.nio.file.*;
import java.util.*;
import java.util.random.RandomGenerator;

/** Pure-logic verification (no Minecraft needed). Run via tools/run_core_tests.sh. */
public class CoreTests {
    static int pass, fail;
    static void check(boolean ok, String what) { if (ok) { pass++; System.out.println("  PASS  " + what); } else { fail++; System.out.println("  FAIL  " + what); } }

    public static void main(String[] args) throws Exception {
        Path voice = Path.of(args.length > 0 ? args[0] : "src/main/resources/azrathiel/voice/vaelzarion_voice.txt");
        convergence(); animation(); kinematics(); voiceLibrary(voice); director(voice); ai(); resource();
        System.out.println("\n" + pass + " passed, " + fail + " failed");
        System.exit(fail == 0 ? 0 : 1);
    }

    static void convergence() {
        System.out.println("[Convergence]");
        List<Integer> masks = Convergence.allMasks();
        check(masks.size() == 255, "exactly 255 non-empty Eidolon combinations");
        Set<String> names = new HashSet<>(); boolean allBuild = true, finite = true;
        for (int m : masks) {
            try {
                Convergence.Spec s = Convergence.build(m, null, Convergence.Balance.DEFAULT);
                names.add(s.name());
                double sum = 0; for (double d : s.stageDamage().values()) sum += d;
                if (Math.abs(sum - s.damage()) > 1e-6 || s.cost() <= 0 || s.cooldownTicks() <= 0 || s.order().size() != Integer.bitCount(m)) allBuild = false;
                if (Double.isNaN(s.damage()) || Double.isInfinite(s.radius())) finite = false;
            } catch (Exception e) { allBuild = false; }
        }
        check(allBuild, "all 255 specs build with consistent damage/cost/cooldown/order");
        check(finite, "no NaN/Infinity values in any spec");
        check(names.size() == 255, "all 255 combination names are unique (found " + names.size() + ")");
        Object[][] hc = {
            {"GRAVITY EXECUTION", Eidolon.VIGOR, Eidolon.ABYSS}, {"INEVITABLE IMPACT", Eidolon.VIGOR, Eidolon.FATE},
            {"NULL BARRIER", Eidolon.ABYSS, Eidolon.AEGIS}, {"ENDLESS DECAY", Eidolon.RUIN, Eidolon.EVOLUTION},
            {"SOUL PROPHECY", Eidolon.FATE, Eidolon.WRAITH}, {"IMPERIAL SANCTUARY", Eidolon.AEGIS, Eidolon.DOMINION},
            {"WORLD DEVOURER", Eidolon.VIGOR, Eidolon.RUIN, Eidolon.ABYSS}, {"FUTURE//REWRITE", Eidolon.FATE, Eidolon.EVOLUTION, Eidolon.WRAITH},
            {"UNBREAKABLE SOVEREIGN", Eidolon.AEGIS, Eidolon.EVOLUTION, Eidolon.DOMINION}, {"KINGDOM OF ASH", Eidolon.RUIN, Eidolon.DOMINION}};
        boolean hcOk = true;
        for (Object[] row : hc) {
            Eidolon[] es = Arrays.copyOfRange(row, 1, row.length, Eidolon[].class);
            Convergence.Spec s = Convergence.build(Convergence.mask(es), null, Convergence.Balance.DEFAULT);
            if (!s.name().equals(row[0]) || !s.handcrafted()) { hcOk = false; System.out.println("    mismatch " + row[0] + " -> " + s.name()); }
        }
        check(hcOk, "all 10 required handcrafted combinations resolve to their exact names");
        check(Convergence.handcrafted().size() == 10, "exactly 10 handcrafted entries registered");
        Convergence.Spec custom = Convergence.build(Convergence.mask(Eidolon.WRAITH, Eidolon.VIGOR, Eidolon.FATE), List.of(Eidolon.WRAITH, Eidolon.VIGOR, Eidolon.FATE), Convergence.Balance.DEFAULT);
        check(custom.order().equals(List.of(Eidolon.WRAITH, Eidolon.VIGOR, Eidolon.FATE)), "custom ordering is preserved (user-edited sequence)");
        Convergence.Balance dbl = new Convergence.Balance(2, 1, 1, new EnumMap<>(Eidolon.class));
        check(Math.abs(Convergence.build(1, null, dbl).damage() - 2 * Convergence.build(1, null, Convergence.Balance.DEFAULT).damage()) < 1e-9, "config damage multiplier scales output");
        check(Convergence.build(255, null, Convergence.Balance.DEFAULT).mode() == Convergence.Mode.SEQUENTIAL, "8-way auto combo is sequential");
        boolean threw = false; try { Convergence.build(0, null, Convergence.Balance.DEFAULT); } catch (IllegalArgumentException e) { threw = true; }
        check(threw, "empty combination is rejected");
    }

    static void animation() {
        System.out.println("[Animation]");
        check(AnimState.values().length == 25, "25 animation states defined");
        boolean allPose = true, finite = true;
        for (AnimState s : AnimState.values()) {
            Pose[] k = Poses.keys(s); if (k == null || k.length == 0) { allPose = false; continue; }
            for (Pose p : k) for (float f : p.v) if (Float.isNaN(f) || Float.isInfinite(f)) finite = false;
        }
        check(allPose, "every state has keyframe poses"); check(finite, "no NaN/Infinity in any pose");
        AnimationController a = new AnimationController();
        a.play(AnimState.MELEE_ATTACK);
        check(!a.play(AnimState.HOVER_UP), "lower-priority one-shot cannot interrupt MELEE_ATTACK");
        check(!a.play(AnimState.DAMAGE_REACTION), "DAMAGE_REACTION (60) cannot interrupt MELEE_ATTACK (65)");
        check(a.play(AnimState.ABILITY_CAST), "higher-priority ABILITY_CAST interrupts melee");
        for (int i = 0; i < 80; i++) a.update(1f / 20f);
        check(!a.shotActive(), "one-shot ends by itself and returns to base state");
        check(a.effective() == AnimState.IDLE_FLOAT, "effective state falls back to base (IDLE_FLOAT)");
        // smoothness: no parameter may jump more than a bounded step per tick while swapping between every pair of states
        AnimationController c = new AnimationController(); float maxJump = 0; float[] prev = new float[P.COUNT];
        AnimState[] loops = Arrays.stream(AnimState.values()).filter(AnimState::loops).toArray(AnimState[]::new);
        for (int round = 0; round < 3; round++) for (AnimState s : loops) {
            c.clearShot(); c.setBase(s);
            for (int t = 0; t < 30; t++) {
                c.update(1f / 20f);
                for (int i = 0; i < P.COUNT; i++) { if (t > 0 || round > 0) maxJump = Math.max(maxJump, Math.abs(c.get(i) - prev[i]) / (i >= P.HALO_SPEED && i != P.CORE_SCALE && i < P.CORE_SCALE ? 40f : 1f)); prev[i] = c.get(i); }
            }
        }
        check(maxJump < 60f, "pose parameters change continuously across base-state swaps (max step " + String.format("%.1f", maxJump) + ")");
        AnimationController f = new AnimationController(); f.setBase(AnimState.COMBAT_IDLE); f.update(0.05f); f.setBase(AnimState.IDLE_FLOAT);
        check(f.base() == AnimState.COMBAT_IDLE, "flicker guard: lower-priority base cannot replace base within 0.35s");
        AnimationController g = new AnimationController(); g.setBase(AnimState.LAST_GUARDIAN); for (int i = 0; i < 100; i++) g.update(0.05f);
        check(g.get(P.SINK) < -0.25f && g.get(P.ARM_RAISE) > 100f, "LAST_GUARDIAN converges to its low guarding posture with raised arms");
        AnimationController h = new AnimationController(); h.setBase(AnimState.ULTIMATE_CHARGE); for (int i = 0; i < 160; i++) h.update(0.05f);
        check(h.get(P.HALO_SPEED) > 380f && h.get(P.CORE_SCALE) > 2.3f && h.get(P.BODY_SCALE) > 1.15f, "ULTIMATE_CHARGE converges to overwhelming halo/core/scale");
        AnimationController d = new AnimationController(); d.play(AnimState.DISMISS); for (int i = 0; i < 40; i++) d.update(0.05f);
        check(d.get(P.BODY_SCALE) < 0.35f || !d.shotActive(), "DISMISS shrinks the body");
    }

    static void kinematics() {
        System.out.println("[Kinematics]");
        double[] vel = {0}; double x = 0, target = 10; double maxX = 0, maxStep = 0, prev = 0;
        for (int i = 0; i < 400; i++) { x = Kinematics.smoothDamp(x, target, vel, 0.25, 30, 0.05); maxX = Math.max(maxX, x); maxStep = Math.max(maxStep, Math.abs(x - prev)); prev = x; }
        check(Math.abs(x - target) < 0.01, "smoothDamp converges to target"); check(maxX <= target + 1e-9, "smoothDamp never overshoots (no rubber-banding)");
        check(maxStep < 1.6, "per-tick movement is bounded (no teleport-like snaps, max " + String.format("%.2f", maxStep) + " blocks)");
        check(Math.abs(Kinematics.wrap180(190) - -170) < 1e-4 && Math.abs(Kinematics.wrap180(-190) - 170) < 1e-4, "angle wrapping");
        float a = 170; for (int i = 0; i < 60; i++) a = Kinematics.approachAngle(a, -170, 6, 220, 0.05f);
        check(Math.abs(Kinematics.wrap180(a + 170)) < 1f, "turning takes the shortest arc across +-180");
        float b = 0; b = Kinematics.approachAngle(b, 180, 50, 220, 0.05f);
        check(Math.abs(b) <= 11.01f, "turn rate is capped (220 deg/s)");
    }

    static VoiceLibrary lib(Path p) throws Exception { return VoiceLibrary.parse(Files.readAllLines(p)); }

    static void voiceLibrary(Path p) throws Exception {
        System.out.println("[Voice library]");
        VoiceLibrary lib = lib(p);
        check(lib.problems().isEmpty(), "authored file parses with no problems " + lib.problems());
        check(lib.size() >= 485, "library holds " + lib.size() + " lines (target 400-500+, minimum distribution sums to 485)");
        boolean dist = true;
        for (Category c : Category.values()) { int n = lib.of(c).size(); if (n < c.target) { dist = false; System.out.println("    category " + c + " has " + n + " < " + c.target); } }
        check(dist, "every category meets its minimum distribution target");
        check(lib.duplicateTexts().isEmpty(), "no duplicate lines " + lib.duplicateTexts());
        for (Eidolon e : Eidolon.values()) {
            long ab = lib.of(Category.ABILITY).stream().filter(v -> v.eidolon() == e).count(), ei = lib.of(Category.EIDOLON).stream().filter(v -> v.eidolon() == e).count();
            check(ab >= 5 && ei >= 6, e + " has " + ab + " ability lines and " + ei + " personality lines");
        }
        check(lib.of(Category.SECRET).stream().allMatch(v -> v.trigger() != null), "every secret line requires an explicit trigger (never in normal browsing)");
        check(lib.of(Category.APOCALYPSE).stream().anyMatch(v -> v.text().equals("KNEEL. BEFORE. YOUR. SOVEREIGN.")), "ultimate signature line present");
        Set<String> ids = new HashSet<>(); for (VoiceLine v : lib.all()) ids.add(v.id());
        check(ids.size() == lib.size(), "line ids are unique (they become sound file names)");
        for (String sub : List.of("summon", "dismiss")) check(lib.of(Category.SUMMON_DISMISS).stream().anyMatch(v -> sub.equals(v.sub())), "summon/dismiss subtype '" + sub + "' exists");
        for (String sub : List.of("follow", "stay", "defend", "attack", "return", "resume")) check(lib.of(Category.COMMAND).stream().filter(v -> sub.equals(v.sub())).count() >= 5, "command lines for '" + sub + "' >= 5");
    }

    static void director(Path p) throws Exception {
        System.out.println("[Dialogue director]");
        VoiceLibrary lib = lib(p);
        DialogueDirector.Prefs pr = new DialogueDirector.Prefs();
        DialogueDirector d = new DialogueDirector(lib, pr, RandomGenerator.of("L64X128MixRandom"));
        long t = 1_000_000;
        Optional<VoiceLine> a = d.request(DialogueDirector.Request.of(Category.SUMMON_DISMISS, Form.DORMANT).sub("summon"), t);
        check(a.isPresent() && "summon".equals(a.get().sub()), "summon request returns a summon line");
        check(d.request(DialogueDirector.Request.of(Category.IDLE, Form.DORMANT), t + 100).isEmpty(), "low priority cannot talk over a line in progress");
        check(d.request(DialogueDirector.Request.of(Category.PROTECT, Form.RELEASED), t + 100).isPresent(), "master-protection line interrupts lower priority speech");
        check(d.request(DialogueDirector.Request.of(Category.PROTECT, Form.RELEASED), t + 200).isEmpty(), "category cooldown blocks immediate repeat");
        check(d.request(DialogueDirector.Request.of(Category.LAST_GUARDIAN, Form.RELEASED), t + 300).isPresent(), "LAST_GUARDIAN outranks everything");
        // no repeats across a long run in one pool
        DialogueDirector d2 = new DialogueDirector(lib, new DialogueDirector.Prefs(), RandomGenerator.of("L64X128MixRandom"));
        Set<String> seen = new HashSet<>(); boolean dup = false; long now = 5_000_000; int got = 0;
        int pool = (int) lib.of(Category.FOLLOW).stream().filter(v -> v.conds().isEmpty()).count();
        for (int i = 0; i < pool; i++) { now += 200_000; var r = d2.request(DialogueDirector.Request.of(Category.FOLLOW, Form.RELEASED).forced(), now); if (r.isPresent()) { got++; if (!seen.add(r.get().id())) dup = true; } }
        check(got == pool && !dup, "shuffle-bag: " + pool + " forced FOLLOW requests yield " + got + " distinct lines, no repeats");
        DialogueDirector.Prefs silent = new DialogueDirector.Prefs(); silent.silent = true;
        check(new DialogueDirector(lib, silent, RandomGenerator.getDefault()).request(DialogueDirector.Request.of(Category.LAST_GUARDIAN, Form.RELEASED), 1).isEmpty(), "silent mode suppresses all voice");
        DialogueDirector.Prefs off = new DialogueDirector.Prefs(); off.disabled.add(Category.IDLE);
        check(new DialogueDirector(lib, off, RandomGenerator.getDefault()).request(DialogueDirector.Request.of(Category.IDLE, Form.DORMANT).forced(), 1).isEmpty(), "disabled category is never spoken");
        DialogueDirector d3 = new DialogueDirector(lib, new DialogueDirector.Prefs(), RandomGenerator.of("L64X128MixRandom"));
        d3.request(DialogueDirector.Request.of(Category.PROTECT, Form.RELEASED), 10); d3.reset();
        check(!d3.isSpeaking(11), "reset (dismiss) clears the speaking state");
        // eidolon-specific
        DialogueDirector d4 = new DialogueDirector(lib, new DialogueDirector.Prefs(), RandomGenerator.of("L64X128MixRandom"));
        var e1 = d4.request(DialogueDirector.Request.of(Category.ABILITY, Form.RELEASED).eid(Eidolon.RUIN), 100);
        check(e1.isPresent() && e1.get().eidolon() == Eidolon.RUIN, "ability request for RUIN yields a RUIN-owned line");
        var e2 = d4.request(DialogueDirector.Request.of(Category.EIDOLON, Form.RELEASED).eid(Eidolon.RUIN), 100_000);
        check(e2.isPresent() && e2.get().eidolon() == Eidolon.RUIN, "EIDOLON personality request yields a RUIN-owned line");
        // secret gating
        int secrets = 0; DialogueDirector d5 = new DialogueDirector(lib, new DialogueDirector.Prefs(), RandomGenerator.of("L64X128MixRandom"));
        boolean noTrigger = true; long n5 = 9_000_000;
        for (int i = 0; i < 400; i++) { n5 += 500_000; if (d5.request(DialogueDirector.Request.of(Category.SECRET, Form.RELEASED), n5).isPresent()) noTrigger = false; }
        for (int i = 0; i < 400; i++) { n5 += 500_000; if (d5.request(DialogueDirector.Request.of(Category.SECRET, Form.RELEASED).trigger("totem"), n5).isPresent()) secrets++; }
        check(noTrigger, "secret lines never fire without their trigger"); check(secrets > 80 && secrets < 240, "secret lines are rare even when triggered (" + secrets + "/400)");
        // personality weighting never excludes, only weights
        DialogueDirector.Prefs calm = new DialogueDirector.Prefs(); calm.personality = Personality.CALM;
        DialogueDirector d6 = new DialogueDirector(lib, calm, RandomGenerator.of("L64X128MixRandom")); int calmHits = 0; long n6 = 20_000_000;
        for (int i = 0; i < 300; i++) { n6 += 200_000; var r = d6.request(DialogueDirector.Request.of(Category.IDLE, Form.DORMANT).forced(), n6); if (r.isPresent() && r.get().affinity().contains(Personality.CALM)) calmHits++; }
        check(calmHits > 0, "personality-tagged lines are favoured when that personality is active (" + calmHits + "/300)");
        check(d.history().size() >= 3, "dialogue history is recorded");
    }

    static void ai() {
        System.out.println("[Threat / AI]");
        var near = new ThreatModel.Threat(3, 4, 1, 20, true, false, false, false, 4, true, false);
        var far = new ThreatModel.Threat(20, 20, 1, 20, false, false, false, false, 0, false, false);
        var boss = new ThreatModel.Threat(12, 12, 1, 500, false, true, false, false, 0, false, false);
        check(ThreatModel.score(near, Form.RELEASED) > ThreatModel.score(far, Form.RELEASED), "attacker on master outranks distant idle mob");
        check(ThreatModel.score(boss, Form.RELEASED) > ThreatModel.score(far, Form.RELEASED), "boss outranks distant idle mob");
        check(ThreatModel.danger(0.2, 5, true, 20) > ThreatModel.danger(1.0, 0, false, 0), "danger rises with low health and crowd");
        RandomGenerator rng = RandomGenerator.of("L64X128MixRandom");
        List<AbilityChooser.Cand> cands = new ArrayList<>();
        for (Eidolon e : Eidolon.values()) cands.add(new AbilityChooser.Cand("C:" + e.bit(), Convergence.build(e.bit(), null, Convergence.Balance.DEFAULT), true));
        EffectivenessTracker tr = new EffectivenessTracker();
        var lowHp = new AbilityChooser.Situation(3, false, false, false, 0.25, true, 3, true, 1, "zombie");
        var pick = AbilityChooser.choose(cands, lowHp, tr, rng, 8);
        check(pick.isPresent() && pick.get().spec().has(Eidolon.AEGIS), "low master health + crowd -> AEGIS defensive ability");
        var crowd = new AbilityChooser.Situation(8, false, false, false, 1.0, false, 6, false, 1, "zombie");
        var pc = AbilityChooser.choose(cands, crowd, tr, rng, 8);
        check(pc.isPresent() && (pc.get().spec().has(Eidolon.ABYSS) || pc.get().spec().has(Eidolon.DOMINION)), "large crowd -> crowd-control Eidolon (ABYSS/DOMINION), got " + pc.map(c -> c.spec().name()).orElse("none"));
        var archer = new AbilityChooser.Situation(1, false, true, false, 1.0, false, 14, false, 1, "skeleton");
        var pa = AbilityChooser.choose(cands, archer, tr, rng, 8);
        check(pa.isPresent() && pa.get().spec().has(Eidolon.FATE), "ranged enemy -> FATE homing, got " + pa.map(c -> c.spec().name()).orElse("none"));
        for (int i = 0; i < 5; i++) tr.record("C:" + Eidolon.FATE.bit(), "skeleton", 0.0, 20);
        check(tr.factor("C:" + Eidolon.FATE.bit(), "skeleton") < 0.5, "tracker learns FATE is ineffective vs skeleton");
        var pb = AbilityChooser.choose(cands, archer, tr, rng, 8);
        check(pb.isPresent() && !pb.get().spec().has(Eidolon.FATE), "AI stops repeating the ineffective ability, got " + pb.map(c -> c.spec().name()).orElse("none"));
        check(AbilityChooser.choose(cands.stream().map(c -> new AbilityChooser.Cand(c.key(), c.spec(), false)).toList(), crowd, tr, rng, 8).isEmpty(), "nothing is chosen while everything is on cooldown");
    }

    static void resource() {
        System.out.println("[Resource]");
        Resource r = new Resource(100, 10);
        check(r.consume(60) && !r.consume(60), "consume succeeds only when affordable"); r.regen(2); check(Math.abs(r.cur - 60) < 1e-9, "regen adds per second"); r.regen(100); check(r.cur == 100, "regen clamps at max");
    }
}
