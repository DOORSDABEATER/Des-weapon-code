package com.des.weapons.azrathiel.entity;

import com.des.weapons.azrathiel.AzrathielModule;
import com.des.weapons.azrathiel.combat.Brain;
import com.des.weapons.azrathiel.combat.LastGuardian;
import com.des.weapons.azrathiel.combat.UltimateRun;
import com.des.weapons.azrathiel.core.*;
import com.des.weapons.azrathiel.data.BondData;
import com.des.weapons.azrathiel.data.Settings;
import com.des.weapons.azrathiel.model.RigModel;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.*;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.random.RandomGenerator;

/**
 * VAELZARION, the living guardian. Owns position/physics, form, animation state, voice director and the AI Brain.
 * Gameplay (damage, cooldowns, essence) lives in combat.* and never reads from the rig or the animation.
 */
public final class Vael {
    public enum Mode { FOLLOW, STAY, DEFEND, ATTACK, RETURN, GUARDIAN, EXHAUSTED, DOWN }

    public final AzrathielModule mod; public final BondData bond;
    public final java.util.UUID ownerId;
    public final AnimationController anim = new AnimationController(); public final Resource essence;
    public final DialogueDirector.Prefs prefs = new DialogueDirector.Prefs(); public final DialogueDirector director;
    public Mode mode = Mode.FOLLOW; public final Brain brain; public UltimateRun ultimate; public LastGuardian guardian; public LivingEntity target;

    private Form form; private RigModel rig; private World world; private double x, y, z; private final double[] vx = {0}, vy = {0}, vz = {0};
    private float bodyYaw, haloAngle, fragAngle; private long ticks, highlightUntil, overrideUntil, boostUntil, faceUntil, nextIdleSwitch, idleUntil, nextTurn, lastMoveMs = System.currentTimeMillis(), lastIdleSecret;
    private int markMask, highlight = -1; private Location stayLoc, overrideSlot, deathLoc, faceTo, cachedSlot, lastMasterLoc; private boolean dismissing;
    private AnimState idleState = AnimState.IDLE_FLOAT, previewState; private long previewUntil; private double speed, vertSpeed; private int rigRespawns; private long rigWindowStart;
    private final RandomGenerator rng = RandomGenerator.getDefault(); private final java.util.ArrayDeque<Long> deathTimes = new java.util.ArrayDeque<>();
    private static final MiniMessage MM = MiniMessage.miniMessage();

    public Vael(AzrathielModule mod, BondData bond, Form startForm) {
        this.mod = mod; this.bond = bond; this.ownerId = bond.owner; this.form = startForm == Form.APOCALYPSE ? Form.RELEASED : startForm;
        Settings c = mod.cfg; essence = new Resource(c.essenceMax, form.combatCapable() ? c.regenReleased : c.regenDormant);
        if (bond.essence >= 0) essence.set(Math.min(bond.essence, c.essenceMax));
        director = new DialogueDirector(mod.voiceLib, prefs, RandomGenerator.getDefault()); syncPrefs(); brain = new Brain(mod, this);
    }

    // ---------------------------------------------------------------------------------------------------------- basics
    public Player master() { return org.bukkit.Bukkit.getPlayer(ownerId); }
    public Form form() { return form; }
    public java.util.Set<java.util.UUID> rigIds() { return rig == null ? java.util.Set.of() : rig.ids(); }
    public boolean released() { return form.combatCapable(); }
    public boolean active() { return rig != null && !dismissing; }
    public Location location() { return new Location(world, x, y, z); }
    public boolean inCombat() { return brain.inCombat(); }
    public AnimState animState() { return anim.effective(); }

    public void syncPrefs() {
        prefs.silent = bond.silent; prefs.frequency = bond.voiceFrequency; prefs.personality = bond.personality; prefs.customMul = bond.customMul;
        prefs.disabled.clear(); prefs.disabled.addAll(bond.disabledCategories); anim.intensity = (float) bond.animIntensity;
    }

    public static int themeColor(BondData b) {
        return switch (b.theme) { case "ANCIENT" -> 0xC9B27E; case "ABYSSAL" -> 0x6A1BFF; case "CELESTIAL" -> 0x9FD6FF; case "CORRUPTED" -> 0xB31F3A;
            case "SPECTRAL" -> 0xC9F4F0; case "PRIMAL" -> 0xFF6A1F; case "CUSTOM" -> b.customColor & 0xFFFFFF; default -> 0xFFC83D; };
    }
    public int tint() { return themeColor(bond); }

    // ------------------------------------------------------------------------------------------------------ lifecycle
    public void spawn(Location at, boolean withFx) {
        world = at.getWorld(); x = at.getX(); y = at.getY(); z = at.getZ(); bodyYaw = at.getYaw(); dismissing = false;
        restoreMarkMask(); respawnRig(); render();
        bond.summoned = true; bond.touch();
        if (withFx) { mod.fx.begin(); mod.fx.safe(() -> { mod.fx.ring(location(), 2.5, tint(), 28, 0.1); mod.fx.spawn(location(), Particle.END_ROD, 30, 0.8, 0.8, 0.8, 0.05); mod.fx.sound(location(), "summon", 1f, 0.8f); });
            say(Category.SUMMON_DISMISS, null, "summon", null, true);
            if (!bond.firstSummonDone) { bond.firstSummonDone = true; mod.tasks.later(120, () -> say(Category.SECRET, null, null, "first_summon", true)); } }
    }

    public void respawnRig() {
        long now = System.currentTimeMillis(); if (now - rigWindowStart > 60_000) { rigWindowStart = now; rigRespawns = 0; }
        if (++rigRespawns > 12) { mod.plugin.getLogger().warning("Rig for " + bond.ownerName + " keeps failing; pausing rebuilds for a minute."); return; }
        if (rig != null) rig.remove();
        rig = RigModel.spawn(mod, location(), form, ownerId, tint());
    }

    public void despawnNow() { if (rig != null) { rig.remove(); rig = null; } if (ultimate != null) ultimate.cancel(); director.reset(); }

    /** Animated dismissal; the rig is removed when the animation ends. No dialogue is possible afterwards. */
    public void dismiss() {
        if (dismissing) return; dismissing = true; bond.summoned = false; bond.touch();
        say(Category.SUMMON_DISMISS, null, "dismiss", null, true);
        anim.play(AnimState.DISMISS); brain.reset();
        mod.fx.begin(); mod.fx.safe(() -> { mod.fx.sound(location(), "dismiss", 1f, 0.8f); mod.fx.spawn(location(), Particle.END_ROD, 40, 0.6, 0.8, 0.6, 0.1); });
        mod.tasks.later(26, () -> { despawnNow(); mod.vaels.forget(this); });
    }

    // --------------------------------------------------------------------------------------------------------- forms
    public void setForm(Form to, boolean withFx) {
        if (to == form && rig != null && rig.valid()) return;
        Form old = form; form = to; bond.form = to == Form.APOCALYPSE ? Form.RELEASED : to; bond.touch();
        essence.regenPerSec = to == Form.DORMANT ? mod.cfg.regenDormant : mod.cfg.regenReleased;
        restoreMarkMask(); respawnRig(); anim.play(AnimState.TRANSFORMATION); render();
        if (withFx) { mod.fx.begin(); mod.fx.safe(() -> { mod.fx.shockwave(location(), to == Form.APOCALYPSE ? 12 : 6, tint(), Particle.END_ROD); mod.fx.sound(location(), to == Form.DORMANT ? "dismiss" : "transform", 1.3f, 0.7f); });
            if (to == Form.RELEASED && old == Form.DORMANT) say(Category.RELEASED, null, null, null, true);
            else if (to == Form.DORMANT) say(Category.RELEASED, null, "dormant", null, true); }
    }

    public void setMarkMask(int m) { markMask = m & 0xFF; }
    public void restoreMarkMask() {
        if (ultimate != null || mode == Mode.GUARDIAN || form == Form.APOCALYPSE) markMask = 0xFF;
        else if (mode == Mode.EXHAUSTED || form == Form.DORMANT) markMask = 0;
        else { int m = 0; for (Eidolon e : Eidolon.values()) if (bond.enabled.contains(e) && mod.unlocked(bond, e)) m |= e.bit(); markMask = m; }
    }
    public void highlight(int ordinal) { highlight = ordinal; highlightUntil = System.currentTimeMillis() + 1500; }

    // -------------------------------------------------------------------------------------------------------- commands
    public void command(Mode m) {
        Mode old = mode; mode = m; brain.reset();
        if (m == Mode.STAY) stayLoc = location();
        String sub = switch (m) { case STAY -> "stay"; case DEFEND -> "defend"; case ATTACK -> "attack"; case RETURN -> "return"; case FOLLOW -> old == Mode.FOLLOW ? "resume" : "follow"; default -> null; };
        if (sub != null) say(Category.COMMAND, null, sub, null, true);
        if (m == Mode.ATTACK && !released() && bond.autoRelease) setForm(Form.RELEASED, true);
        if (m == Mode.RETURN) anim.play(AnimState.RETURN_TO_MASTER);
    }
    public void resume() { Mode o = mode; mode = Mode.FOLLOW; brain.reset(); say(Category.COMMAND, null, "resume", null, true); if (o == Mode.RETURN) anim.play(AnimState.RECOVERY); }

    /** Owner-commanded or AI-chosen ability. Releases automatically if needed. */
    public boolean ultimate(boolean bypass, java.util.function.Consumer<String> err) {
        String why = UltimateRun.check(mod, this, bypass); if (why != null) { err.accept(why); return false; }
        UltimateRun.start(mod, this, bypass); return true;
    }

    // ------------------------------------------------------------------------------------------- gameplay -> animation
    public void say(Category c, Eidolon e, String sub, String trigger, boolean force) { try { if (!dismissing || c == Category.SUMMON_DISMISS) mod.voice.say(this, c, e, sub, trigger, force); } catch (Throwable t) { if (mod.debug) mod.plugin.getLogger().warning("voice failed (ignored): " + t); } }

    public void onCast(Convergence.Spec spec, Location focus) {
        if (!form.combatCapable() && bond.autoRelease) setForm(Form.RELEASED, false);
        AnimState a = spec.order().size() >= 3 || (spec.order().size() == 1 && spec.has(Eidolon.VIGOR)) ? AnimState.HEAVY_ATTACK : (spec.range() >= 12 && !spec.has(Eidolon.AEGIS)) ? AnimState.RANGED_ATTACK : AnimState.ABILITY_CAST;
        if (ultimate == null) anim.play(a);
        lookAtPoint(focus, 1000); highlight(spec.order().get(0).ordinal());
        for (int i = 0; i < Math.min(3, spec.order().size()); i++) { final Eidolon e = spec.order().get(i); final int idx = i; mod.tasks.later(idx * 18L, () -> say(Category.ABILITY, e, null, null, idx > 0)); }
    }
    public void strike(Location at, boolean heavy) { anim.play(heavy ? AnimState.HEAVY_ATTACK : AnimState.MELEE_ATTACK); lookAtPoint(at, 700); }
    public void intercept(Location from) {
        anim.play(AnimState.INTERCEPT); Player m = master(); if (m == null) return;
        Vector dir = from.toVector().subtract(m.getLocation().toVector()).setY(0); if (dir.lengthSquared() > 0.01) overrideSlot = m.getLocation().add(dir.normalize().multiply(1.6)).add(0, 1.6, 0);
        overrideUntil = System.currentTimeMillis() + 600; lookAtPoint(from, 700);
    }
    public void dashTo(Location end, int ticksLong) { overrideSlot = end.clone(); overrideUntil = System.currentTimeMillis() + ticksLong * 50L; boostUntil = overrideUntil; }
    private void lookAtPoint(Location l, long ms) { faceTo = l.clone(); faceUntil = System.currentTimeMillis() + ms; }

    public void onMasterHurt(double finalDamage, double healthAfter) {
        anim.play(AnimState.DAMAGE_REACTION); double frac = healthAfter / Math.max(1, maxHealthOf(master()));
        if (frac < 0.25) say(Category.INJURY, null, null, null, false); else if (frac < 0.5) say(Category.INJURY, null, null, null, false); else if (inCombat() && finalDamage > 4) say(Category.PROTECT, null, null, null, false);
    }
    private static double maxHealthOf(Player p) { try { var a = p.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH); return a == null ? 20 : a.getValue(); } catch (Throwable t) { return 20; } }

    public void onKill(LivingEntity victim) {
        String t = victim.getType().name();
        if (t.equals("ENDER_DRAGON")) say(Category.SECRET, null, null, "kill_dragon", true); else if (t.equals("WITHER")) say(Category.SECRET, null, null, "kill_wither", true);
        else if (t.equals("WARDEN")) say(Category.SECRET, null, null, "kill_warden", true);
        else if (bond.kills % 100 == 0 && bond.kills > 0) say(Category.SECRET, null, null, "hundredth_kill", true);
        else say(Category.COMBAT_REACT, null, "kill", null, false);
    }

    public void onMasterDeath(Location loc) {
        bond.deaths++; deathLoc = loc.clone(); brain.reset(); long now = System.currentTimeMillis();
        deathTimes.addLast(now); while (!deathTimes.isEmpty() && now - deathTimes.peekFirst() > 600_000) deathTimes.removeFirst();
        if (ultimate != null) ultimate.cancel();
        if (form.combatCapable()) {
            if (form == Form.APOCALYPSE) setForm(Form.RELEASED, false);
            LastGuardian g = LastGuardian.start(mod, this, loc);
            if (g != null) {
                guardian = g; mode = Mode.GUARDIAN; setMarkMask(0xFF); anim.setBase(AnimState.LAST_GUARDIAN); say(Category.LAST_GUARDIAN, null, null, null, true);
                mod.fx.begin(); mod.fx.safe(() -> { mod.fx.ring(loc, mod.cfg.lgRadius, 0x2E6FFF, 60, 0.2); mod.fx.sphere(loc.clone().add(0, 1, 0), 2.5, 0x2E6FFF, 40); mod.fx.sound(loc, "lastguardian", 1.5f, 0.7f); });
                return;
            }
        }
        mode = Mode.DOWN; restoreMarkMask(); say(Category.DEATH_RESPAWN, null, "death", null, true);
        if (deathTimes.size() >= 3) mod.tasks.later(160, () -> say(Category.SECRET, null, null, "death_streak", true));
    }

    public void onMasterRespawn() {
        boolean was = mode == Mode.GUARDIAN || mode == Mode.EXHAUSTED || mode == Mode.DOWN;
        guardian = null; mode = Mode.FOLLOW; deathLoc = null; brain.reset(); restoreMarkMask(); Player m = master();
        if (m != null) { Location s = formationSlot(m); snap(s); }
        anim.setBase(AnimState.IDLE_FLOAT); anim.play(AnimState.RECOVERY);
        if (was) say(Category.DEATH_RESPAWN, null, "respawn", null, true);
    }

    public void snap(Location l) {
        if (l.getWorld() != world) { world = l.getWorld(); x = l.getX(); y = l.getY(); z = l.getZ(); respawnRig(); }
        else { x = l.getX(); y = l.getY(); z = l.getZ(); }
        vx[0] = vy[0] = vz[0] = 0; if (rig != null && rig.valid()) rig.teleport(location(), 0);
    }

    // ------------------------------------------------------------------------------------------------------------ tick
    public void tick() {
        Player m = master(); if (m == null || !m.isOnline() || rig == null) return;
        ticks++; final float dt = 0.05f; Settings c = mod.cfg; long now = System.currentTimeMillis();
        if (ticks % 10 == 0 && !dismissing && !rig.valid()) { respawnRig(); render(); }
        if (ticks % 20 == 0) { essence.regen(1.0); bond.essence = essence.cur; if (!m.isDead()) mod.adapt.sample(m); }

        move(m, dt, now);
        if (ticks % c.aiInterval == 0) { try { brain.tick(m); } catch (Throwable t) { mod.plugin.getLogger().warning("Brain error (continuing): " + t); } }
        chooseBase(m, now);
        anim.update(dt);
        haloAngle = (haloAngle + anim.get(P.HALO_SPEED) * (float) bond.haloSpeed * dt) % 360f;      // wrapped so float precision never degrades on long sessions
        fragAngle = (fragAngle + anim.get(P.FRAG_SPEED) * dt) % 36000f;                             // 36000 keeps every per-fragment speed multiplier seamless
        if (ticks % c.animInterval == 0) render();
        if (ticks % c.moveInterval == 0 && rig.valid()) rig.teleport(location(), c.moveInterval);
        if (!dismissing) { if (ticks % c.auraInterval == 0) aura(); if (ticks % 10 == 0) hud(m); ambient(m, now); }
    }

    private void move(Player m, float dt, long now) {
        Location slot = computeSlot(m, now); Settings c = mod.cfg;
        if (slot.getWorld() != world || location().distanceSquared(slot) > c.snapDistance * c.snapDistance) { snap(slot); return; }
        double dist = Math.sqrt(location().distanceSquared(slot)); boolean fast = dist > 6 || now < boostUntil;
        double sp = now < boostUntil ? 70 : fast ? c.fastSpeed : c.maxSpeed, st = c.smoothTime * (fast ? 0.55 : 1.0);
        double ox = x, oy = y, oz = z;
        x = Kinematics.smoothDamp(x, slot.getX(), vx, st, sp, dt); y = Kinematics.smoothDamp(y, slot.getY(), vy, st, sp, dt); z = Kinematics.smoothDamp(z, slot.getZ(), vz, st, sp, dt);
        speed = Math.hypot(vx[0], vz[0]); vertSpeed = vy[0];

        float want = bodyYaw; Location look = null;
        if (faceTo != null && now < faceUntil) look = faceTo; else if (target != null && target.isValid() && brain.inCombat()) look = target.getLocation();
        if (look != null && look.getWorld() == world) want = yawTo(look.getX() - x, look.getZ() - z);
        else if (mode == Mode.GUARDIAN && deathLoc != null) want = yawTo(deathLoc.getX() - x, deathLoc.getZ() - z);
        else want = m.getLocation().getYaw();
        float before = bodyYaw; bodyYaw = Kinematics.approachAngle(bodyYaw, want, 6f, (float) c.maxTurnRate, dt);
        if (Math.abs(Kinematics.wrap180(want - bodyYaw)) > 40f && now > nextTurn && !brain.inCombat() && ultimate == null) { anim.play(AnimState.TURN); nextTurn = now + 1500; }

        Location ml = m.getLocation(); if (lastMasterLoc == null || lastMasterLoc.getWorld() != ml.getWorld() || lastMasterLoc.distanceSquared(ml) > 0.04) { lastMoveMs = now; lastMasterLoc = ml.clone(); }

        // head: look at the master when observing, at the enemy in combat, around when idle
        float hy = 0, hp = 0; Location hl = look;
        if (hl == null && idleState == AnimState.IDLE_OBSERVE_MASTER) hl = m.getEyeLocation();
        if (hl != null && hl.getWorld() == world) { double dx = hl.getX() - x, dz = hl.getZ() - z, dy = hl.getY() - y; hy = Kinematics.wrap180(yawTo(dx, dz) - bodyYaw); hp = (float) -Math.toDegrees(Math.atan2(dy, Math.hypot(dx, dz))); }
        else if (idleState == AnimState.IDLE_LOOK_AROUND) hy = (float) Math.sin(ticks * 0.03) * 55f;
        anim.look(hy, hp);
    }

    private static float yawTo(double dx, double dz) { return (float) Math.toDegrees(Math.atan2(-dx, dz)); }

    private Location computeSlot(Player m, long now) {
        if (overrideSlot != null && now < overrideUntil) return overrideSlot;
        if (mode == Mode.GUARDIAN || mode == Mode.EXHAUSTED || mode == Mode.DOWN) {
            Location c = deathLoc != null ? deathLoc : m.getLocation(); double a = ticks * 0.03, r = mode == Mode.GUARDIAN ? 1.8 : 0.0;
            return c.clone().add(Math.cos(a) * r, 2.2 + (form.scale - 1) * 0.5, Math.sin(a) * r);
        }
        if (mode == Mode.STAY && stayLoc != null) return stayLoc.clone();
        if (brain.inCombat() && mode != Mode.RETURN) { Location cs = brain.combatSlot(m); if (cs != null) return adjust(m, cs); }
        return formationSlot(m);
    }

    /** Behind and beside the master, drifting slowly around them; never directly in the line of sight for long. */
    public Location formationSlot(Player m) {
        Location b = m.getLocation(); double yaw = Math.toRadians(b.getYaw()), t = ticks / 20.0;
        double fx = -Math.sin(yaw), fz = Math.cos(yaw), rx = -Math.cos(yaw), rz = -Math.sin(yaw);
        double mul = form == Form.DORMANT ? 1.0 : form == Form.RELEASED ? 1.7 : 2.3;
        double dist = (bond.followDistance > 0 ? bond.followDistance : mod.cfg.followDistance) * mul, side = 1.1 * Math.sin(t * 0.08 + 0.7) * mul;
        double h = bond.hoverHeight > 0 ? bond.hoverHeight : (form == Form.DORMANT ? mod.cfg.followHeight : mod.cfg.releasedHeight + (form.scale - 1) * 0.8);
        Location slot = b.clone().add(-fx * dist + rx * side, h + 0.25 * Math.sin(t * 0.5), -fz * dist + rz * side);
        return adjust(m, slot);
    }

    private Location adjust(Player m, Location slot) {
        if (ticks % 2 == 0 || cachedSlot == null || cachedSlot.getWorld() != slot.getWorld()) {
            Location eye = m.getEyeLocation(); Vector d = slot.toVector().subtract(eye.toVector()); double len = d.length(); Location out = slot.clone();
            if (len > 0.6 && eye.getWorld() == slot.getWorld()) {
                RayTraceResult r = eye.getWorld().rayTraceBlocks(eye, d.clone().normalize(), len, FluidCollisionMode.NEVER, true);
                if (r != null && r.getHitPosition() != null) out = r.getHitPosition().toLocation(eye.getWorld()).subtract(d.clone().normalize().multiply(0.7));
            }
            for (int i = 0; i < 4 && !out.getBlock().isPassable(); i++) out.add(0, 1.0, 0);
            cachedSlot = out;
        }
        return cachedSlot.clone();
    }

    /** Plays any animation state for a few seconds so the owner can inspect it from the GUI. Purely cosmetic. */
    public void preview(AnimState s) { previewState = s; previewUntil = System.currentTimeMillis() + 4000; anim.clearShot(); if (!s.loops()) anim.play(s); }

    private void chooseBase(Player m, long now) {
        if (dismissing || ultimate != null) return;
        if (previewState != null && now < previewUntil) { if (previewState.loops()) anim.setBase(previewState); return; }
        if (mode == Mode.GUARDIAN) { anim.setBase(AnimState.LAST_GUARDIAN); return; }
        if (mode == Mode.EXHAUSTED || mode == Mode.DOWN) { anim.setBase(AnimState.IDLE_FLOAT); return; }
        double dm = location().distance(m.getLocation().add(0, 1, 0));
        if (form.combatCapable()) {
            if (brain.inCombat()) { anim.setBase(brain.defending() ? AnimState.DEFEND : brain.primary() != null && brain.primary().getLocation().distanceSquared(location()) < 400 ? AnimState.TARGET_LOCK : AnimState.COMBAT_IDLE); return; }
            if (mode == Mode.RETURN || dm > 8) { anim.setBase(AnimState.RETURN_TO_MASTER); return; }
            anim.setBase(speed > 9 ? AnimState.FOLLOW_FAST : speed > 1.8 ? AnimState.FOLLOW : AnimState.RELEASED_IDLE); return;
        }
        if (brain.inCombat()) { anim.setBase(AnimState.COMBAT_IDLE); return; }
        if (speed > 9) { anim.setBase(AnimState.FOLLOW_FAST); return; }
        if (speed > 1.8) { anim.setBase(AnimState.FOLLOW); idleState = AnimState.IDLE_FLOAT; return; }
        if (Math.abs(vertSpeed) > 2.5 && !anim.shotActive()) anim.play(vertSpeed > 0 ? AnimState.HOVER_UP : AnimState.HOVER_DOWN);
        if (now > nextIdleSwitch) { idleState = idleState == AnimState.IDLE_FLOAT ? (rng.nextBoolean() ? AnimState.IDLE_LOOK_AROUND : AnimState.IDLE_OBSERVE_MASTER) : AnimState.IDLE_FLOAT;
            nextIdleSwitch = now + (idleState == AnimState.IDLE_FLOAT ? 6000 + rng.nextInt(8000) : 3000 + rng.nextInt(2000)); }
        anim.setBase(idleState);
    }

    private void render() {
        if (rig == null || !rig.valid()) return; long now = System.currentTimeMillis();
        int hl = now < highlightUntil ? highlight : -1;
        rig.render(new RigModel.RenderState(bodyYaw, (float) (ticks / 20.0), haloAngle, fragAngle, markMask, hl, tint(), bond.showHalo, bond.showFragments, bond.showMarkings,
                (float) bond.coreScale, Math.max(1, mod.cfg.animInterval), anim));
    }

    private void aura() {
        if (!bond.aura || !mod.cfg.particles || world == null) return;
        mod.fx.begin(); mod.fx.safe(() -> { int n = (int) Math.round((form == Form.DORMANT ? 1 : form == Form.RELEASED ? 3 : 8) * bond.particleIntensity);
            if (n > 0) mod.fx.dust(location(), tint(), 1.0f, n, 0.35 * form.scale); });
    }

    private void hud(Player m) {
        if (!mod.cfg.hudActionbar || !mod.weapon.is(m.getInventory().getItemInMainHand()) || mod.voice.subtitleRecent(m)) return;
        var lo = bond.loadout(); String sel = "-"; if (!lo.isEmpty()) { var sp = mod.executor.specFor(bond, lo.get(Math.floorMod(bond.selected, lo.size()))); if (sp != null) { long cd = mod.executor.cooldownLeftMs(bond, sp.key()); sel = sp.name() + (cd > 0 ? " (" + cd / 1000 + "s)" : ""); } }
        int filled = (int) Math.round(essence.fraction() * 10); String bar = "<gold>" + "|".repeat(filled) + "<dark_gray>" + "|".repeat(10 - filled);
        String st = mode == Mode.GUARDIAN ? "<red>LAST GUARDIAN" : ultimate != null ? "<gold>EIGHTFOLD APOCALYPSE" : "<gray>" + form.name();
        try { m.sendActionBar(MM.deserialize("<gradient:#7a1bff:#ffc83d>VAELZARION</gradient> " + st + " <dark_gray>|</dark_gray> " + bar + " <dark_gray>|</dark_gray> <white>" + sel)); } catch (Throwable ignored) { }
    }

    private void ambient(Player m, long now) {
        if (ticks % (mod.cfg.ambientSeconds * 20L) != 0 || ultimate != null || brain.inCombat() || mode == Mode.GUARDIAN || mode == Mode.DOWN || mode == Mode.EXHAUSTED) return;
        if (rng.nextDouble() > 0.7) return;
        if (now - lastMoveMs > 600_000 && now - lastIdleSecret > 900_000) { lastIdleSecret = now; say(Category.SECRET, null, null, "idle_long", true); return; }
        say(speed > 1.8 ? Category.FOLLOW : (rng.nextInt(4) == 0 ? Category.EIDOLON : Category.IDLE), null, null, null, false);
    }

    /** Diagnostics for /azrathiel status and the GUI. */
    public String diagnostics() {
        return "form=" + form + " mode=" + mode + " anim=" + anim.effective() + " base=" + anim.base() + " combat=" + brain.inCombat() + " speed=" + String.format("%.1f", speed)
                + " rigValid=" + (rig != null && rig.valid()) + " essence=" + (int) essence.cur + "/" + (int) essence.max;
    }
}
