package com.des.weapons.azrathiel.data;

import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.Plugin;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/** Bond persistence. Snapshot on the main thread, write on an async thread; synchronous flush on shutdown. */
public final class Store {
    private final Plugin plugin; private final File dir;
    private final Map<UUID, BondData> bonds = new ConcurrentHashMap<>();   // bondId -> data
    private final Map<UUID, UUID> byOwner = new ConcurrentHashMap<>();    // owner -> bondId

    public Store(Plugin plugin, File root) { this.plugin = plugin; this.dir = new File(root, "bonds"); }

    public void loadAll() {
        bonds.clear(); byOwner.clear();
        if (!dir.exists() && !dir.mkdirs()) plugin.getLogger().warning("Could not create " + dir);
        File[] files = dir.listFiles((d, n) -> n.endsWith(".yml"));
        if (files == null) return;
        for (File f : files) {
            try {
                BondData b = BondData.fromYaml(YamlConfiguration.loadConfiguration(f));
                if (byOwner.containsKey(b.owner)) { plugin.getLogger().warning("Duplicate bond for owner " + b.owner + " in " + f.getName() + " - ignored (kept the first one)."); continue; }
                bonds.put(b.bondId, b); byOwner.put(b.owner, b.bondId);
            } catch (Exception ex) {
                File bad = new File(dir, f.getName() + ".corrupt");
                plugin.getLogger().log(Level.SEVERE, "Corrupt bond file " + f.getName() + " moved to " + bad.getName(), ex);
                if (!f.renameTo(bad)) plugin.getLogger().warning("Could not quarantine " + f.getName());
            }
        }
    }

    public BondData byOwner(UUID owner) { UUID id = byOwner.get(owner); return id == null ? null : bonds.get(id); }
    public BondData byId(UUID id) { return id == null ? null : bonds.get(id); }
    public Collection<BondData> all() { return bonds.values(); }

    public BondData create(UUID owner, String name) {
        BondData b = new BondData(UUID.randomUUID(), owner); b.ownerName = name; bonds.put(b.bondId, b); byOwner.put(owner, b.bondId); b.touch(); return b;
    }

    /** Administrator reassignment: the bond (identity, progression, presets, voice) moves to a new UUID unchanged. */
    public boolean reassign(BondData b, UUID newOwner, String newName) {
        if (byOwner.containsKey(newOwner)) return false;
        byOwner.remove(b.owner); b.owner = newOwner; b.ownerName = newName; byOwner.put(newOwner, b.bondId); b.touch(); return true;
    }

    public void delete(BondData b) { bonds.remove(b.bondId); byOwner.remove(b.owner); File f = new File(dir, b.bondId + ".yml"); if (f.exists() && !f.delete()) plugin.getLogger().warning("Could not delete " + f); }

    public void saveDirtyAsync() {
        for (BondData b : bonds.values()) if (b.dirty) { b.dirty = false; final String data = b.toYaml().saveToString(); final File f = new File(dir, b.bondId + ".yml");
            plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> write(f, data)); }
    }
    public void saveAllNow() { for (BondData b : bonds.values()) { b.dirty = false; write(new File(dir, b.bondId + ".yml"), b.toYaml().saveToString()); } }
    public void saveNow(BondData b) { b.dirty = false; write(new File(dir, b.bondId + ".yml"), b.toYaml().saveToString()); }

    private void write(File f, String data) {
        try {
            if (!dir.exists()) //noinspection ResultOfMethodCallIgnored
                dir.mkdirs();
            File tmp = new File(f.getParentFile(), f.getName() + ".tmp");
            Files.writeString(tmp.toPath(), data, StandardCharsets.UTF_8);
            try { Files.move(tmp.toPath(), f.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING, java.nio.file.StandardCopyOption.ATOMIC_MOVE); }
            catch (java.nio.file.AtomicMoveNotSupportedException nam) { Files.move(tmp.toPath(), f.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { plugin.getLogger().log(Level.SEVERE, "Failed to save " + f.getName(), ex); }
    }
}
