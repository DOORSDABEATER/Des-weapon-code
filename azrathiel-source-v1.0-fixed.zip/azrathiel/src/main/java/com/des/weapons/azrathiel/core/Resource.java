package com.des.weapons.azrathiel.core;

/** Essence pool. Server owners can tune max/regen; abilities spend from it. */
public final class Resource {
    public double max, cur, regenPerSec;
    public Resource(double max, double regenPerSec) { this.max = max; this.cur = max; this.regenPerSec = regenPerSec; }
    public boolean has(double amt) { return cur + 1e-9 >= amt; }
    public boolean consume(double amt) { if (!has(amt)) return false; cur -= amt; return true; }
    public void regen(double dt) { cur = Math.min(max, cur + regenPerSec * dt); }
    public void set(double v) { cur = Math.max(0, Math.min(max, v)); }
    public double fraction() { return max <= 0 ? 0 : cur / max; }
}
