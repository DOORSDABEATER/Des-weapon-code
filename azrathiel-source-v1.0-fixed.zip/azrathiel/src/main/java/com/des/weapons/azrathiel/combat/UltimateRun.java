package com.des.weapons.azrathiel.combat;

import com.des.weapons.azrathiel.AzrathielModule;
import com.des.weapons.azrathiel.core.*;
import com.des.weapons.azrathiel.entity.Vael;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/**
 * EIGHTFOLD APOCALYPSE. A server-timed sequence driven by ONE tick counter: awakening (0), eightfold manifestation (40-75),
 * domination (80-139, pulsing), main attack (140), final impact (180), completion (duration). Every damage step runs
 * BEFORE its cosmetics, each part is separately guarded, and nothing here waits for the animation, the rig or the audio.
 */
public final class UltimateRun {
    private final AzrathielModule mod; private final Vael v; private final Player m; private final CastCtx ctx; private boolean finished;

    private UltimateRun(AzrathielModule mod, Vael v, Player m) {
        this.mod = mod; this.v = v; this.m = m;
        this.ctx = new CastCtx(mod, m, Convergence.build(Eidolon.FULL_MASK, null, mod.balance()), true, m.getLocation(), m.getLocation()); ctx.vael = v;
    }

    public static String check(AzrathielModule mod, Vael v, boolean bypass) {
        Player m = v.master();
        if (m == null || m.isDead()) return "the master is not alive";
        if (v.ultimate != null) return "EIGHTFOLD APOCALYPSE is already active";
        if (v.mode == Vael.Mode.GUARDIAN || v.mode == Vael.Mode.EXHAUSTED || v.mode == Vael.Mode.DOWN) return "VAELZARION is not in a state to awaken";
        if (bypass) return null;
        long left = v.bond.ultReadyAt - System.currentTimeMillis(); if (left > 0) return "cooldown: " + (left / 1000) + "s";
        if (!v.essence.has(mod.cfg.ultCost)) return "not enough essence (" + (int) v.essence.cur + "/" + (int) mod.cfg.ultCost + ")";
        return null;
    }

    public static UltimateRun start(AzrathielModule mod, Vael v, boolean bypass) {
        UltimateRun u = new UltimateRun(mod, v, v.master());
        if (!bypass) { v.essence.consume(mod.cfg.ultCost); v.bond.ultReadyAt = System.currentTimeMillis() + mod.cfg.ultCooldownSec * 1000L; }
        v.bond.awakenings++; v.bond.touch(); v.ultimate = u;
        mod.tasks.every(0, 1, u::tick); return u;
    }

    public void cancel() { finished = true; if (v.ultimate == this) v.ultimate = null; }

    private List<LivingEntity> enemies(double r) { return mod.targeting.around(m, m.getLocation(), r); }

    private boolean tick(int n) {
        if (finished) return false;
        if (!m.isOnline() || m.isDead()) { cancel(); return false; }
        var cfg = mod.cfg; Location mc = m.getLocation();
        if (n == 0) {                                                                   // 1. AWAKENING - damage first, cosmetics after
            Dmg.effect(m, "resistance", cfg.ultDurationTicks, 1); Dmg.effect(m, "absorption", cfg.ultDurationTicks, 1);
            for (LivingEntity t : enemies(cfg.ultRadius)) Dmg.deal(ctx, 1, t, cfg.ultAwakeningDmg, true, Util.outward(mc, t.getLocation(), 1.0).setY(0.4));
            mod.fx.safe(() -> { v.setForm(Form.APOCALYPSE, true); v.setMarkMask(0xFF); v.anim.setBase(AnimState.ULTIMATE_CHARGE); v.say(Category.APOCALYPSE, null, null, null, true); });
            mod.fx.begin(); mod.fx.safe(() -> { mod.fx.shockwave(mc, 10, 0xFFC83D, Particle.END_ROD); mod.fx.sound(mc, "ultimate.awaken", 1.5f, 0.6f); });
        }
        if (n >= 40 && n < 80 && (n - 40) % 5 == 0) {                                   // 2. EIGHTFOLD MANIFESTATION - each Eidolon fires its own module, real damage
            Eidolon e = Eidolon.values()[(n - 40) / 5];
            Map<Eidolon, Double> mul = new EnumMap<>(Eidolon.class); mul.put(e, cfg.ultManifestDmg / Math.max(1, Convergence.PROFILES.get(e).damage()));
            CastCtx sub = ctx.derive(Convergence.build(e.bit(), List.of(e), new Convergence.Balance(1, 1, 1, mul)));
            List<LivingEntity> en = enemies(cfg.ultRadius); sub.focus = en.isEmpty() ? mc.clone().add(mc.getDirection().setY(0).multiply(5)) : en.get(0).getLocation(); sub.origin = mc;
            try { Modules.apply(sub, e, 0); } catch (Throwable t) { mod.plugin.getLogger().warning("Ultimate manifestation " + e + " failed: " + t); }
            ctx.totalDamage += sub.totalDamage; ctx.hits += sub.hits; ctx.killed.addAll(sub.killed);
            mod.fx.safe(() -> v.highlight(e.ordinal()));
        }
        if (n == 70) mod.fx.safe(() -> v.anim.setBase(AnimState.ULTIMATE_EXECUTION));
        if (n >= 80 && n < 140 && (n - 80) % 20 == 0) {                                 // 3. BATTLEFIELD DOMINATION - suppression pulses
            List<LivingEntity> en = enemies(cfg.ultRadius);
            for (LivingEntity t : en) { Dmg.deal(ctx, 100 + n, t, cfg.ultDominationDmg, true, null); Dmg.effect(t, "slowness", 40, 3); Dmg.effect(t, "weakness", 40, 1); }
            Util.clearTargets(en);
            mod.fx.begin(); mod.fx.safe(() -> { mod.fx.ring(mc, cfg.ultRadius * 0.5, 0xFFC83D, 48, 0.2); mod.fx.ring(mc, cfg.ultRadius, 0xFFC83D, 64, 0.2); });
        }
        if (n == 140) {                                                                 // 4. MAIN ATTACK
            List<LivingEntity> en = enemies(cfg.ultRadius);
            for (LivingEntity t : en) Dmg.deal(ctx, 200, t, cfg.ultMainDmg, true, Util.outward(mc, t.getLocation(), cfg.ultKnockback * 0.8).setY(0.8));
            mod.fx.safe(() -> v.say(Category.APOCALYPSE, null, null, null, true));
            mod.fx.begin(); mod.fx.safe(() -> { Location from = v.location().add(0, 1.5, 0);
                for (int i = 0; i < 8; i++) { Eidolon e = Eidolon.values()[i]; Location to = en.isEmpty() ? mc.clone().add(Math.cos(i * Math.PI / 4) * 14, 1, Math.sin(i * Math.PI / 4) * 14) : en.get(i % en.size()).getLocation().add(0, 1, 0);
                    mod.fx.line(from, to, e.rgb, 0.5); }
                mod.fx.sound(mc, "ultimate.main", 1.6f, 0.7f); });
        }
        if (n == 180) {                                                                 // 5. FINAL IMPACT
            double r = cfg.ultRadius * 1.15;
            for (LivingEntity t : mod.targeting.around(m, mc, r)) Dmg.deal(ctx, 300, t, cfg.ultFinalDmg, true, Util.outward(mc, t.getLocation(), cfg.ultKnockback).setY(1.0));
            mod.fx.begin(); mod.fx.safe(() -> { mod.fx.shockwave(mc, r, 0xFFFFFF, Particle.EXPLOSION); mod.fx.spawn(mc, Particle.EXPLOSION_EMITTER, 6, r / 4, 1, r / 4, 0); mod.fx.sound(mc, "ultimate.impact", 1.8f, 0.6f); });
        }
        if (n >= cfg.ultDurationTicks) { finish(); return false; }                      // 6. COMPLETION
        return true;
    }

    private void finish() {
        finished = true; mod.onCastFinished(v, ctx);
        if (v.ultimate == this) v.ultimate = null;
        v.essence.set(v.essence.max * mod.cfg.ultExhaustPercent / 100.0);
        mod.fx.safe(() -> { if (m.isOnline() && !m.isDead()) { v.setForm(Form.RELEASED, true); v.restoreMarkMask(); v.anim.play(AnimState.RECOVERY); v.say(Category.APOCALYPSE, null, "end", null, true); } });
    }
}
