package com.des.weapons.azrathiel.combat;

import com.des.weapons.azrathiel.AzrathielModule;
import com.des.weapons.azrathiel.core.Convergence;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.damage.DamageSource;
import org.bukkit.damage.DamageType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.List;

/** Server-authoritative damage. Independent of animation, particles and sound. One call = at most one hit per (ctx, stage, target). */
public final class Dmg {
    private Dmg() {}

    /** Returns the damage actually dealt (health removed). */
    public static double deal(CastCtx c, int stage, LivingEntity t, double amount, boolean magic, Vector knockback) {
        if (t == null || !t.isValid() || t.isDead() || amount <= 0) return 0;
        if (!c.dedupe.add(stage + "|" + t.getUniqueId())) return 0;                       // duplicate-hit guard
        double max = Targeting.maxHealth(t); boolean boss = Targeting.isBoss(t);
        if (boss) amount = Math.min(amount, Math.max(1, max * c.mod.cfg.bossMaxPct));      // boss compatibility: capped % of max health per hit
        double before = t.getHealth();
        try {
            if (c.mod.cfg.bypassIFrames) t.setNoDamageTicks(0);
            var b = DamageSource.builder(magic ? DamageType.MAGIC : DamageType.PLAYER_ATTACK);
            if (c.master != null && !c.master.isDead() && c.master.isOnline()) b.withCausingEntity(c.master).withDirectEntity(c.master);   // kill credit + claim-plugin compatibility
            t.damage(amount, b.build());
        } catch (Throwable ex) { t.damage(amount); }
        double after = t.isDead() ? 0 : t.getHealth(); double dealt = Math.max(0, before - after);
        if (knockback != null && !boss && t.isValid()) { try { t.setVelocity(t.getVelocity().add(knockback)); } catch (Throwable ignored) { } }
        c.totalDamage += dealt; c.hits++; if (t.isDead() || after <= 0) c.killed.add(t);
        if (c.spec != null) c.mod.tracker.record(c.spec.key(), t.getType().name(), dealt, max);
        return dealt;
    }

    public static void effects(LivingEntity t, List<Convergence.Eff> effs, double durationMul) {
        if (t == null || !t.isValid()) return;
        double mul = Targeting.isBoss(t) ? Math.min(durationMul, 0.4) : durationMul;
        for (Convergence.Eff e : effs) {
            try { PotionEffectType type = Registry.POTION_EFFECT_TYPE.get(NamespacedKey.minecraft(e.type()));
                if (type != null) t.addPotionEffect(new PotionEffect(type, Math.max(1, (int) (e.ticks() * mul)), e.amp(), false, true, true)); } catch (Throwable ignored) { }
        }
    }
    public static void effect(LivingEntity t, String type, int ticks, int amp) { effects(t, List.of(new Convergence.Eff(type, ticks, amp)), 1.0); }
}
