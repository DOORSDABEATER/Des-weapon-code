package com.des.weapons.azrathiel.entity;

import com.des.weapons.azrathiel.AzrathielModule;
import com.des.weapons.azrathiel.core.Form;
import com.des.weapons.azrathiel.data.BondData;
import com.des.weapons.azrathiel.model.RigModel;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

/** Owns every live VAELZARION. One per owner, enforced here (duplicate prevention). Single repeating task drives all of them. */
public final class VaelManager {
    private final AzrathielModule mod; private final Map<UUID, Vael> byOwner = new HashMap<>(); private final Map<UUID, Long> missingWeapon = new HashMap<>();
    private BukkitTask loop; private long tickCount;

    public VaelManager(AzrathielModule mod) { this.mod = mod; }

    public void start() { loop = Bukkit.getScheduler().runTaskTimer(mod.plugin, this::tick, 1L, 1L); }
    public Vael of(UUID owner) { return byOwner.get(owner); }
    public Collection<Vael> all() { return new ArrayList<>(byOwner.values()); }
    public int count() { return byOwner.size(); }
    void forgetInternal(Vael v) { byOwner.remove(v.ownerId, v); }
    public void forget(Vael v) { forgetInternal(v); }

    private void tick() {
        tickCount++;
        for (Vael v : new ArrayList<>(byOwner.values())) {
            try { v.tick(); } catch (Throwable t) { mod.plugin.getLogger().warning("VAELZARION tick failed (isolated): " + t); }
            if (tickCount % 20 == 0) try { checkWeapon(v); } catch (Throwable ignored) { }
        }
    }

    private void checkWeapon(Vael v) {
        if (!mod.cfg.requireWeapon) return; Player m = v.master(); if (m == null || m.isDead() || v.mode == Vael.Mode.GUARDIAN || v.mode == Vael.Mode.EXHAUSTED || v.mode == Vael.Mode.DOWN) { missingWeapon.remove(v.ownerId); return; }
        if (hasWeapon(m, v.bond)) { missingWeapon.remove(v.ownerId); return; }
        long since = missingWeapon.computeIfAbsent(v.ownerId, k -> System.currentTimeMillis());
        if (System.currentTimeMillis() - since > mod.cfg.weaponGraceSeconds * 1000L) { missingWeapon.remove(v.ownerId); m.sendMessage(mod.msg("<gray>The vessel left your hands. VAELZARION withdraws.")); v.dismiss(); }
    }

    public boolean hasWeapon(Player p, BondData b) {
        for (ItemStack it : p.getInventory().getContents()) { if (it != null && mod.weapon.is(it)) { UUID id = mod.weapon.bondOf(it); if (id == null || id.equals(b.bondId)) return true; } }
        return false;
    }

    /** Returns an error message or null on success. */
    public String summon(Player p, BondData b) {
        if (byOwner.containsKey(p.getUniqueId())) return "VAELZARION is already at your side.";
        if (byOwner.size() >= mod.cfg.maxActiveRigs) return "Too many guardians are active on this server right now.";
        Vael v = new Vael(mod, b, b.form); byOwner.put(p.getUniqueId(), v);
        try { v.spawn(v.formationSlot(p), true); } catch (Throwable t) { byOwner.remove(p.getUniqueId()); mod.plugin.getLogger().warning("Summon failed: " + t); return "Summoning failed: " + t.getMessage(); }
        return null;
    }

    public void dismiss(UUID owner) { Vael v = byOwner.get(owner); if (v != null) v.dismiss(); }

    /** Player left / plugin stopping: remove the rig but keep the 'summoned' flag so VAELZARION returns on the next join. */
    public void release(UUID owner) {
        Vael v = byOwner.remove(owner); if (v == null) return;
        boolean was = v.bond.summoned; v.despawnNow(); v.bond.summoned = was; v.bond.essence = v.essence.cur; v.bond.touch(); missingWeapon.remove(owner);
    }

    public void shutdown() {
        if (loop != null) loop.cancel();
        for (UUID id : new ArrayList<>(byOwner.keySet())) release(id);
        purgeAll();
    }

    /** Removes rig entities that are not part of a live VAELZARION (crash leftovers, forced chunk reloads). */
    public int purgeOrphans() {
        Set<UUID> live = new HashSet<>(); for (Vael v : byOwner.values()) live.addAll(v.rigIds()); int n = 0;
        for (World w : Bukkit.getWorlds()) for (Entity e : w.getEntities()) if (RigModel.isRigEntity(e) && !live.contains(e.getUniqueId())) { e.remove(); n++; }
        return n;
    }
    public int purgeAll() { int n = 0; for (World w : Bukkit.getWorlds()) for (Entity e : w.getEntities()) if (RigModel.isRigEntity(e)) { e.remove(); n++; } return n; }
}
