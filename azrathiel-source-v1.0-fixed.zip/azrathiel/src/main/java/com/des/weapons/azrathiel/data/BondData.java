package com.des.weapons.azrathiel.data;

import com.des.weapons.azrathiel.core.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.util.*;

/** Everything that persists about one master/VAELZARION bond. One file per bond id: plugins/.../bonds/<id>.yml */
public final class BondData {
    public record Custom(String name, List<Eidolon> order, boolean favorite) {
        public Custom withName(String n) { return new Custom(n, order, favorite); }
        public Custom withFav(boolean f) { return new Custom(name, order, f); }
    }
    public static final List<String> THEMES = List.of("ROYAL", "ANCIENT", "ABYSSAL", "CELESTIAL", "CORRUPTED", "SPECTRAL", "PRIMAL", "CUSTOM");

    public final UUID bondId; public UUID owner; public String ownerName = "";
    public boolean summoned; public Form form = Form.DORMANT; public boolean dirty;
    public final Set<Eidolon> unlocked = EnumSet.noneOf(Eidolon.class), enabled = EnumSet.allOf(Eidolon.class);
    public int kills, bossKills, awakenings, deaths; public boolean firstSummonDone;
    public final Map<String, List<String>> loadouts = new LinkedHashMap<>(); public String activeLoadout = "Default"; public int selected;
    public final List<Custom> customs = new ArrayList<>();
    // voice & personality
    public double voiceVolume = 1.0, voiceFrequency = 0.8, pitch = 1.0, reverb = 0.3, layerIntensity = 0.5, customMul = 1.0;
    public final Map<Eidolon, Double> eidolonVolume = new EnumMap<>(Eidolon.class); public final Map<Form, Double> formVolume = new EnumMap<>(Form.class);
    public final Set<Category> disabledCategories = EnumSet.noneOf(Category.class);
    public String subtitleMode = "ACTIONBAR"; public boolean silent; public Personality personality = Personality.LOYAL;
    // visual / animation
    public String theme = "ROYAL"; public int customColor = 0xFFC83D; public double particleIntensity = 1.0, coreScale = 1.0, haloSpeed = 1.0, animIntensity = 1.0;
    public boolean aura = true, showHalo = true, showFragments = true, showMarkings = true, transformFx = true;
    // combat behaviour overrides
    public boolean autoRelease = true, interceptProjectiles = true; public double followDistance = 0, hoverHeight = 0, aggression = 1.0;
    // runtime state
    public final Map<String, Long> cooldownReadyAt = new HashMap<>(); public double essence = -1; public long ultReadyAt, lgReadyAt;

    public BondData(UUID bondId, UUID owner) {
        this.bondId = bondId; this.owner = owner;
        for (Eidolon e : Eidolon.values()) eidolonVolume.put(e, 1.0);
        for (Form f : Form.values()) formVolume.put(f, f == Form.DORMANT ? 0.8 : 1.0);
        loadouts.put("Default", defaultKeys(true, true));
        loadouts.put("Guardian", keys(Eidolon.AEGIS, Eidolon.DOMINION, Eidolon.EVOLUTION, Eidolon.FATE, Eidolon.ABYSS, Eidolon.WRAITH, Eidolon.VIGOR, Eidolon.RUIN));
        List<String> dev = new ArrayList<>(); for (Integer m : Convergence.handcrafted().keySet()) dev.add("C:" + m);
        loadouts.put("Devastator", dev);
        unlocked.addAll(EnumSet.allOf(Eidolon.class));
    }

    static List<String> keys(Eidolon... es) { List<String> l = new ArrayList<>(); for (Eidolon e : es) l.add("C:" + e.bit()); return l; }
    public static List<String> defaultKeys(boolean singles, boolean handcrafted) {
        List<String> l = new ArrayList<>();
        if (singles) for (Eidolon e : Eidolon.values()) l.add("C:" + e.bit());
        if (handcrafted) for (Integer m : Convergence.handcrafted().keySet()) l.add("C:" + m);
        return l;
    }
    public List<String> loadout() { return loadouts.computeIfAbsent(activeLoadout, k -> defaultKeys(true, true)); }
    public Custom custom(String name) { for (Custom c : customs) if (c.name().equalsIgnoreCase(name)) return c; return null; }
    public void touch() { dirty = true; }

    public YamlConfiguration toYaml() {
        YamlConfiguration y = new YamlConfiguration();
        y.set("bond-id", bondId.toString()); y.set("owner", owner.toString()); y.set("owner-name", ownerName);
        y.set("summoned", summoned); y.set("form", form.name()); y.set("first-summon-done", firstSummonDone);
        List<String> un = new ArrayList<>(), en = new ArrayList<>(); for (Eidolon e : unlocked) un.add(e.name()); for (Eidolon e : enabled) en.add(e.name());
        y.set("eidolons.unlocked", un); y.set("eidolons.enabled", en);
        y.set("progress.kills", kills); y.set("progress.boss-kills", bossKills); y.set("progress.awakenings", awakenings); y.set("progress.deaths", deaths);
        for (var en2 : loadouts.entrySet()) y.set("loadouts.list." + en2.getKey(), en2.getValue());
        y.set("loadouts.active", activeLoadout); y.set("loadouts.selected", selected);
        for (Custom c : customs) { String p = "customs." + c.name(); List<String> o = new ArrayList<>(); for (Eidolon e : c.order()) o.add(e.name()); y.set(p + ".order", o); y.set(p + ".favorite", c.favorite()); }
        y.set("voice.volume", voiceVolume); y.set("voice.frequency", voiceFrequency); y.set("voice.pitch", pitch); y.set("voice.reverb", reverb);
        y.set("voice.layer-intensity", layerIntensity); y.set("voice.custom-multiplier", customMul); y.set("voice.subtitles", subtitleMode); y.set("voice.silent", silent);
        y.set("voice.personality", personality.name());
        for (var e : eidolonVolume.entrySet()) y.set("voice.eidolon-volume." + e.getKey().name(), e.getValue());
        for (var e : formVolume.entrySet()) y.set("voice.form-volume." + e.getKey().name(), e.getValue());
        List<String> dc = new ArrayList<>(); for (Category c : disabledCategories) dc.add(c.name()); y.set("voice.disabled-categories", dc);
        y.set("visual.theme", theme); y.set("visual.custom-color", customColor); y.set("visual.particle-intensity", particleIntensity); y.set("visual.core-scale", coreScale);
        y.set("visual.halo-speed", haloSpeed); y.set("visual.aura", aura); y.set("visual.halo", showHalo); y.set("visual.fragments", showFragments);
        y.set("visual.markings", showMarkings); y.set("visual.transform-fx", transformFx); y.set("animation.intensity", animIntensity);
        y.set("combat.auto-release", autoRelease); y.set("combat.intercept-projectiles", interceptProjectiles); y.set("combat.follow-distance", followDistance);
        y.set("combat.hover-height", hoverHeight); y.set("combat.aggression", aggression);
        for (var e : cooldownReadyAt.entrySet()) if (e.getValue() > System.currentTimeMillis()) y.set("runtime.cooldowns." + e.getKey().replace(':', '_'), e.getValue());
        y.set("runtime.essence", essence); y.set("runtime.ultimate-ready-at", ultReadyAt); y.set("runtime.last-guardian-ready-at", lgReadyAt);
        return y;
    }

    public static BondData fromYaml(YamlConfiguration y) {
        UUID id = UUID.fromString(Objects.requireNonNull(y.getString("bond-id"))), owner = UUID.fromString(Objects.requireNonNull(y.getString("owner")));
        BondData b = new BondData(id, owner);
        b.ownerName = y.getString("owner-name", ""); b.summoned = y.getBoolean("summoned"); b.firstSummonDone = y.getBoolean("first-summon-done");
        try { b.form = Form.valueOf(y.getString("form", "DORMANT")); } catch (Exception ignored) { }
        if (y.contains("eidolons.unlocked")) { b.unlocked.clear(); for (String s : y.getStringList("eidolons.unlocked")) { Eidolon e = Eidolon.parse(s); if (e != null) b.unlocked.add(e); } }
        if (y.contains("eidolons.enabled")) { b.enabled.clear(); for (String s : y.getStringList("eidolons.enabled")) { Eidolon e = Eidolon.parse(s); if (e != null) b.enabled.add(e); } }
        b.kills = y.getInt("progress.kills"); b.bossKills = y.getInt("progress.boss-kills"); b.awakenings = y.getInt("progress.awakenings"); b.deaths = y.getInt("progress.deaths");
        ConfigurationSection ls = y.getConfigurationSection("loadouts.list");
        if (ls != null) { b.loadouts.clear(); for (String k : ls.getKeys(false)) b.loadouts.put(k, new ArrayList<>(ls.getStringList(k))); }
        if (b.loadouts.isEmpty()) b.loadouts.put("Default", defaultKeys(true, true));
        b.activeLoadout = y.getString("loadouts.active", "Default"); b.selected = y.getInt("loadouts.selected");
        ConfigurationSection cs = y.getConfigurationSection("customs");
        if (cs != null) for (String k : cs.getKeys(false)) {
            List<Eidolon> o = new ArrayList<>(); for (String s : cs.getStringList(k + ".order")) { Eidolon e = Eidolon.parse(s); if (e != null) o.add(e); }
            if (!o.isEmpty()) b.customs.add(new Custom(k, o, cs.getBoolean(k + ".favorite")));
        }
        b.voiceVolume = clamp(y.getDouble("voice.volume", 1.0), 0, 2); b.voiceFrequency = clamp(y.getDouble("voice.frequency", 0.8), 0, 1);
        b.pitch = clamp(y.getDouble("voice.pitch", 1.0), 0.5, 2); b.reverb = clamp(y.getDouble("voice.reverb", 0.3), 0, 1);
        b.layerIntensity = clamp(y.getDouble("voice.layer-intensity", 0.5), 0, 1); b.customMul = clamp(y.getDouble("voice.custom-multiplier", 1.0), 0, 1.5);
        b.subtitleMode = y.getString("voice.subtitles", "ACTIONBAR"); b.silent = y.getBoolean("voice.silent");
        try { b.personality = Personality.valueOf(y.getString("voice.personality", "LOYAL")); } catch (Exception ignored) { }
        for (Eidolon e : Eidolon.values()) b.eidolonVolume.put(e, clamp(y.getDouble("voice.eidolon-volume." + e.name(), 1.0), 0, 2));
        for (Form f : Form.values()) b.formVolume.put(f, clamp(y.getDouble("voice.form-volume." + f.name(), f == Form.DORMANT ? 0.8 : 1.0), 0, 2));
        for (String s : y.getStringList("voice.disabled-categories")) { try { b.disabledCategories.add(Category.valueOf(s)); } catch (Exception ignored) { } }
        b.theme = y.getString("visual.theme", "ROYAL"); if (!THEMES.contains(b.theme)) b.theme = "ROYAL";
        b.customColor = y.getInt("visual.custom-color", 0xFFC83D); b.particleIntensity = clamp(y.getDouble("visual.particle-intensity", 1.0), 0, 2);
        b.coreScale = clamp(y.getDouble("visual.core-scale", 1.0), 0.5, 2); b.haloSpeed = clamp(y.getDouble("visual.halo-speed", 1.0), 0.2, 3);
        b.aura = y.getBoolean("visual.aura", true); b.showHalo = y.getBoolean("visual.halo", true); b.showFragments = y.getBoolean("visual.fragments", true);
        b.showMarkings = y.getBoolean("visual.markings", true); b.transformFx = y.getBoolean("visual.transform-fx", true);
        b.animIntensity = clamp(y.getDouble("animation.intensity", 1.0), 0.2, 1.5);
        b.autoRelease = y.getBoolean("combat.auto-release", true); b.interceptProjectiles = y.getBoolean("combat.intercept-projectiles", true);
        b.followDistance = clamp(y.getDouble("combat.follow-distance", 0), 0, 8); b.hoverHeight = clamp(y.getDouble("combat.hover-height", 0), 0, 6); b.aggression = clamp(y.getDouble("combat.aggression", 1.0), 0.2, 2);
        ConfigurationSection cd = y.getConfigurationSection("runtime.cooldowns");
        if (cd != null) for (String k : cd.getKeys(false)) b.cooldownReadyAt.put(k.replace('_', ':'), cd.getLong(k));
        b.essence = y.getDouble("runtime.essence", -1); b.ultReadyAt = y.getLong("runtime.ultimate-ready-at"); b.lgReadyAt = y.getLong("runtime.last-guardian-ready-at");
        return b;
    }
    static double clamp(double v, double lo, double hi) { return Double.isNaN(v) ? lo : Math.max(lo, Math.min(hi, v)); }
}
