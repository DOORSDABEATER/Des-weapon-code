package com.des.weapons.azrathiel.combat;

import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Projectile;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.Supplier;

final class Util {
    private Util() {}

    static Vector outward(Location from, Location to, double mag) {
        Vector v = to.toVector().subtract(from.toVector()); v.setY(0);
        if (v.lengthSquared() < 1e-4) v = new Vector(Math.random() - 0.5, 0, Math.random() - 0.5);
        return v.normalize().multiply(mag);
    }

    /** Distance from point p to segment a-b. */
    static double segDist(Location a, Location b, Location p) {
        Vector ab = b.toVector().subtract(a.toVector()), ap = p.toVector().subtract(a.toVector()); double l2 = ab.lengthSquared();
        double t = l2 < 1e-6 ? 0 : Math.max(0, Math.min(1, ap.dot(ab) / l2)); return a.toVector().add(ab.multiply(t)).distance(p.toVector());
    }

    /** Removes hostile projectiles (anything not shot by the master or an ally) inside the sphere. Returns how many were removed. */
    static int removeProjectiles(CastCtx c, Location center, double r) {
        int n = 0; if (center.getWorld() == null) return 0;
        for (Entity e : center.getWorld().getNearbyEntities(center, r, r, r)) {
            if (!(e instanceof Projectile p) || !p.isValid()) continue;
            if (p.getShooter() instanceof Entity s && c.mod.targeting.isAlly(c.master, s)) continue;
            p.remove(); n++;
        }
        return n;
    }

    static void clearTargets(List<LivingEntity> l) { for (LivingEntity e : l) if (e instanceof Mob m) { try { m.setTarget(null); } catch (Throwable ignored) { } } }

    static void strip(LivingEntity e, boolean beneficial) {
        try { for (PotionEffect pe : e.getActivePotionEffects()) { PotionEffectType t = pe.getType();
            boolean good = "BENEFICIAL".equals(t.getEffectCategory().name()); if (good == beneficial && !"NEUTRAL".equals(t.getEffectCategory().name())) e.removePotionEffect(t); } } catch (Throwable ignored) { }
    }

    /** Repeating area effect. body gets the current enemy list and the pulse index. Stops after durationTicks or when center is null. */
    static void zone(CastCtx c, Supplier<Location> center, double r, int durationTicks, int period, BiConsumer<List<LivingEntity>, Integer> body) {
        c.mod.tasks.every(0, period, n -> {
            if ((long) n * period >= durationTicks) return false;
            Location ctr = center.get(); if (ctr == null || ctr.getWorld() == null) return false;
            body.accept(c.mod.targeting.around(c.master, ctr, r), n); return true;
        });
    }

    static Location masterOrOrigin(CastCtx c) { return (c.master != null && c.master.isOnline() && !c.master.isDead()) ? c.master.getLocation() : c.origin; }
}
