package com.des.weapons.azrathiel.core;

import java.util.*;

/**
 * Parses the authored voice-line resource. Format:
 *   @CATEGORY NAME          starts a block (ids become name.001, name.002 ...)
 *   [tags...] spoken text   tags: [D][R][A] form, [VIGOR] eidolon, [~LOYAL] personality affinity,
 *                           [LOW][CRIT][NIGHT][RAIN][NETHER][END][WATER][ESS][ALLY][HIGH] conditions,
 *                           [#sub] action subtype, [T:key] secret trigger
 * Lines starting with # are comments.
 */
public final class VoiceLibrary {
    private final List<VoiceLine> all = new ArrayList<>();
    private final Map<Category, List<VoiceLine>> byCat = new EnumMap<>(Category.class);
    private final Map<String, VoiceLine> byId = new HashMap<>();
    private final List<String> problems = new ArrayList<>();

    public static VoiceLibrary parse(List<String> lines) {
        VoiceLibrary lib = new VoiceLibrary();
        Category cur = null; int lineNo = 0; Map<Category, Integer> counters = new EnumMap<>(Category.class);
        for (String raw : lines) {
            lineNo++;
            String s = raw.strip();
            if (s.isEmpty() || s.startsWith("#")) continue;
            if (s.startsWith("@")) {
                try { cur = Category.valueOf(s.substring(1).trim().toUpperCase(Locale.ROOT)); }
                catch (IllegalArgumentException ex) { lib.problems.add("line " + lineNo + ": unknown category " + s); cur = null; }
                continue;
            }
            if (cur == null) { lib.problems.add("line " + lineNo + ": line outside a category"); continue; }
            Set<Form> forms = EnumSet.noneOf(Form.class); Set<Personality> aff = EnumSet.noneOf(Personality.class);
            Set<Cond> conds = EnumSet.noneOf(Cond.class); Eidolon eid = null; String sub = null, trig = null;
            int i = 0;
            while (i < s.length() && s.charAt(i) == '[') {
                int close = s.indexOf(']', i);
                if (close < 0) break;
                String t = s.substring(i + 1, close).trim(); i = close + 1;
                while (i < s.length() && s.charAt(i) == ' ') i++;
                if (t.startsWith("~")) { try { aff.add(Personality.valueOf(t.substring(1).toUpperCase(Locale.ROOT))); } catch (Exception e) { lib.problems.add("line " + lineNo + ": bad affinity " + t); } }
                else if (t.startsWith("#")) sub = t.substring(1).toLowerCase(Locale.ROOT);
                else if (t.startsWith("T:")) trig = t.substring(2).toLowerCase(Locale.ROOT);
                else if (t.length() == 1 && Form.ofTag(t.charAt(0)) != null) forms.add(Form.ofTag(t.charAt(0)));
                else if (Eidolon.parse(t) != null && t.length() > 2) eid = Eidolon.parse(t);
                else {
                    Cond c = switch (t.toUpperCase(Locale.ROOT)) {
                        case "LOW" -> Cond.MASTER_LOW; case "CRIT" -> Cond.MASTER_CRIT; case "NIGHT" -> Cond.NIGHT;
                        case "RAIN" -> Cond.RAIN; case "NETHER" -> Cond.NETHER; case "END" -> Cond.END;
                        case "WATER" -> Cond.WATER; case "ESS" -> Cond.LOW_ESSENCE; case "ALLY" -> Cond.ALLY_NEARBY;
                        case "HIGH" -> Cond.HIGH_UP; default -> null; };
                    if (c != null) conds.add(c); else lib.problems.add("line " + lineNo + ": unknown tag [" + t + "]");
                }
            }
            String text = s.substring(i).strip();
            if (text.isEmpty()) { lib.problems.add("line " + lineNo + ": empty text"); continue; }
            int n = counters.merge(cur, 1, Integer::sum);          // numbering continues across blocks and packs: ids stay unique and stable
            String id = cur.key() + "." + String.format("%03d", n);
            VoiceLine v = new VoiceLine(id, cur, sub, forms, eid, aff, conds, trig, text);
            lib.all.add(v); lib.byCat.computeIfAbsent(cur, k -> new ArrayList<>()).add(v); lib.byId.put(id, v);
        }
        return lib;
    }

    public List<VoiceLine> all() { return Collections.unmodifiableList(all); }
    public List<VoiceLine> of(Category c) { return byCat.getOrDefault(c, List.of()); }
    public VoiceLine byId(String id) { return byId.get(id); }
    public int size() { return all.size(); }
    public List<String> problems() { return problems; }

    /** Texts that appear more than once (case/space-insensitive). Used by the self-check. */
    public List<String> duplicateTexts() {
        Map<String, Integer> seen = new HashMap<>(); List<String> dups = new ArrayList<>();
        for (VoiceLine v : all) { String k = v.text().toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", ""); if (seen.merge(k, 1, Integer::sum) == 2) dups.add(v.text()); }
        return dups;
    }
}
