package com.des.weapons.azrathiel.core;

/** Situational conditions a voice line can require. */
public enum Cond { MASTER_LOW, MASTER_CRIT, NIGHT, RAIN, NETHER, END, WATER, LOW_ESSENCE, ALLY_NEARBY, HIGH_UP }
