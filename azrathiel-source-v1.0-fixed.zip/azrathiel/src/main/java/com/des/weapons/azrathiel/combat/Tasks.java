package com.des.weapons.azrathiel.combat;

import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.IntPredicate;
import java.util.logging.Level;

/** Tracked scheduler wrapper: every task is exception-safe and cancelled on shutdown (no leaked combat objects). */
public final class Tasks {
    private final Plugin plugin; private final Set<BukkitTask> live = ConcurrentHashMap.newKeySet();
    public Tasks(Plugin plugin) { this.plugin = plugin; }

    public BukkitTask later(long delay, Runnable r) {
        if (delay <= 0) { try { r.run(); } catch (Throwable t) { plugin.getLogger().log(Level.WARNING, "Azrathiel task failed", t); } return null; }
        BukkitTask t = new BukkitRunnable() { @Override public void run() {
            try { r.run(); } catch (Throwable ex) { plugin.getLogger().log(Level.WARNING, "Azrathiel task failed", ex); } } }.runTaskLater(plugin, delay);
        live.add(t); prune(); return t;
    }

    /** body receives the run index and returns false to stop. Exceptions stop the task but never propagate. */
    public BukkitTask every(long delay, long period, IntPredicate body) {
        BukkitTask t = new BukkitRunnable() { int n = 0;
            @Override public void run() { try { if (!body.test(n++)) cancel(); } catch (Throwable ex) { cancel(); plugin.getLogger().log(Level.WARNING, "Azrathiel timer failed", ex); } } }
                .runTaskTimer(plugin, Math.max(0, delay), Math.max(1, period));
        live.add(t); prune(); return t;
    }

    private void prune() { if (live.size() > 256) live.removeIf(BukkitTask::isCancelled); }
    public int active() { live.removeIf(BukkitTask::isCancelled); return live.size(); }
    public void cancelAll() { for (BukkitTask t : live) { try { t.cancel(); } catch (Throwable ignored) { } } live.clear(); }
}
