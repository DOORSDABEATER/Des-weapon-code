package com.des.weapons.azrathiel;

import com.des.weapons.azrathiel.core.Convergence;
import com.des.weapons.azrathiel.core.Eidolon;
import com.des.weapons.azrathiel.core.Form;
import com.des.weapons.azrathiel.combat.AbilityExecutor;
import com.des.weapons.azrathiel.data.BondData;
import com.des.weapons.azrathiel.entity.Vael;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.Locale;

/** Every player-facing operation, shared by the weapon item, commands and the GUI. Methods return an error message, or null on success. */
public final class Actions {
    private final AzrathielModule mod;
    public Actions(AzrathielModule mod) { this.mod = mod; }

    public BondData bond(Player p) { return mod.store.byOwner(p.getUniqueId()); }
    public Vael vael(Player p) { return mod.vaels.of(p.getUniqueId()); }

    public BondData ensureBond(Player p) {
        BondData b = bond(p);
        if (b == null) { b = mod.store.create(p.getUniqueId(), p.getName());
            if (!mod.cfg.fullAccess && mod.cfg.progressionEnabled) { b.unlocked.clear(); mod.applyProgression(b, null); } }
        b.ownerName = p.getName(); return b;
    }

    /** Resolve which bond an item belongs to for this player. Binds unbound vessels. Returns null (with a message sent) if the player may not use it. */
    public BondData bondForItem(Player p, ItemStack it) {
        if (!p.hasPermission("des.azrathiel.use")) { p.sendMessage(mod.msg("<red>You may not wield AZRATHIEL.")); return null; }
        java.util.UUID id = mod.weapon.bondOf(it); BondData existing = id == null ? null : mod.store.byId(id);
        if (existing == null) { BondData mine = ensureBond(p); mod.weapon.bind(it, mine.bondId); p.sendMessage(mod.msg("<gold>The vessel wakes. VAELZARION recognises you as its master.")); mod.store.saveNow(mine); return mine; }
        if (!existing.owner.equals(p.getUniqueId())) { p.sendMessage(mod.msg("<dark_red>VAELZARION does not answer to you.")); return null; }
        return existing;
    }

    public String summon(Player p) {
        if (!p.hasPermission("des.azrathiel.use")) return "You lack permission.";
        BondData b = bond(p); if (b == null) return "Hold the AZRATHIEL vessel and right-click it to awaken your bond.";
        if (mod.cfg.requireWeapon && !p.hasPermission("des.azrathiel.admin") && !mod.vaels.hasWeapon(p, b)) return "VAELZARION answers only to one who carries the vessel.";
        return mod.vaels.summon(p, b);
    }
    public String dismiss(Player p) { Vael v = vael(p); if (v == null) return "VAELZARION is not summoned."; v.dismiss(); return null; }
    public String toggleSummon(Player p) { return vael(p) == null ? summon(p) : dismiss(p); }

    public String release(Player p, Boolean toReleased) {
        Vael v = vael(p); if (v == null) return "VAELZARION is not summoned.";
        if (v.mode == Vael.Mode.GUARDIAN || v.ultimate != null) return "Not now.";
        boolean want = toReleased != null ? toReleased : !v.released(); if (want == v.released()) return null;
        v.setForm(want ? Form.RELEASED : Form.DORMANT, true); return null;
    }

    public String ultimate(Player p) {
        if (!p.hasPermission("des.azrathiel.ultimate")) return "You lack permission.";
        Vael v = vael(p); if (v == null) return "VAELZARION is not summoned.";
        String[] err = {null}; v.ultimate(false, s -> err[0] = s);
        if (err[0] == null && v.bond.essence >= 0 && p.getHealth() < 4) v.say(com.des.weapons.azrathiel.core.Category.SECRET, null, null, "low_hp_ult", true);
        return err[0];
    }

    public String stance(Player p, Vael.Mode m) { Vael v = vael(p); if (v == null) return "VAELZARION is not summoned."; if (v.mode == Vael.Mode.GUARDIAN || v.mode == Vael.Mode.EXHAUSTED || v.mode == Vael.Mode.DOWN) return "Not now."; v.command(m); return null; }
    public String resume(Player p) { Vael v = vael(p); if (v == null) return "VAELZARION is not summoned."; v.resume(); return null; }

    public String cast(Player p, String key) {
        Vael v = vael(p); if (v == null) return "VAELZARION is not summoned.";
        if (v.mode == Vael.Mode.GUARDIAN || v.mode == Vael.Mode.EXHAUSTED || v.mode == Vael.Mode.DOWN || v.ultimate != null) return "Not now.";
        var res = mod.executor.cast(v, key, new AbilityExecutor.Opts()); return res.ok() ? null : res.reason();
    }
    public String castSelected(Player p) {
        BondData b = bond(p); if (b == null) return "No bond."; var lo = b.loadout(); if (lo.isEmpty()) return "Your loadout is empty.";
        return cast(p, lo.get(Math.floorMod(b.selected, lo.size())));
    }
    public String cycle(Player p, int dir) {
        BondData b = bond(p); if (b == null) return "No bond."; var lo = b.loadout(); if (lo.isEmpty()) return "Your loadout is empty.";
        b.selected = Math.floorMod(b.selected + dir, lo.size()); b.touch(); var s = mod.executor.specFor(b, lo.get(b.selected));
        p.sendActionBar(mod.msg("<gold>Selected: <white>" + (s == null ? "?" : s.name()))); return null;
    }

    /** Parses "vigor+abyss", "C:5", "5", a custom combo name, or a handcrafted name into an ability key. Returns null if unknown. */
    public String parseKey(BondData b, String s) {
        if (s == null || s.isBlank()) return null; String t = s.trim();
        if (t.startsWith("C:") || t.startsWith("X:")) return t;
        if (b != null && b.custom(t) != null) return "X:" + b.custom(t).name();
        for (var e : Convergence.handcrafted().entrySet()) if (e.getValue().equalsIgnoreCase(t.replace('_', ' '))) return "C:" + e.getKey();
        int mask = 0; for (String part : t.split("[+,&]")) { Eidolon e = Eidolon.parse(part); if (e == null) { mask = 0; break; } mask |= e.bit(); }
        if (mask != 0) return "C:" + mask;
        try { int m = Integer.parseInt(t); if (m >= 1 && m <= 255) return "C:" + m; } catch (NumberFormatException ignored) { }
        return null;
    }
    public String keyName(BondData b, String key) { var s = mod.executor.specFor(b, key); return s == null ? key : s.name(); }
    public static String bar(double frac, int len) { int f = (int) Math.round(Math.max(0, Math.min(1, frac)) * len); return "|".repeat(f) + "<dark_gray>" + "|".repeat(len - f); }
    public static String title(String s) { return s.substring(0, 1).toUpperCase(Locale.ROOT) + s.substring(1).toLowerCase(Locale.ROOT); }
}
