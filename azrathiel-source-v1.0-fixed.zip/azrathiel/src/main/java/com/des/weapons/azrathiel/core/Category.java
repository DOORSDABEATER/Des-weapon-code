package com.des.weapons.azrathiel.core;

/** Dialogue categories. priority: higher interrupts lower. critical: always allowed even in reduced-chatter modes. */
public enum Category {
    LAST_GUARDIAN(100, 3000, true, 20), PROTECT(90, 4000, true, 35), INJURY(88, 8000, true, 25),
    DEATH_RESPAWN(85, 0, true, 15), APOCALYPSE(80, 1500, true, 20), RELEASED(70, 3000, false, 20),
    BOSS(60, 20000, false, 25), DETECT(55, 9000, false, 30), ABILITY(52, 3500, false, 40),
    COMBAT_START(50, 15000, false, 30), COMBAT_REACT(48, 7000, false, 40), SUMMON_DISMISS(45, 2000, false, 25),
    COMMAND(40, 1500, false, 30), EIDOLON(30, 25000, false, 40), FOLLOW(15, 40000, false, 25),
    SECRET(12, 120000, false, 30), IDLE(10, 45000, false, 35);

    public final int priority, cooldownMs, target; public final boolean critical;
    Category(int priority, int cooldownMs, boolean critical, int target) {
        this.priority = priority; this.cooldownMs = cooldownMs; this.critical = critical; this.target = target;
    }
    public boolean ambient() { return priority <= 15; }
    public String key() { return name().toLowerCase(java.util.Locale.ROOT); }
}
