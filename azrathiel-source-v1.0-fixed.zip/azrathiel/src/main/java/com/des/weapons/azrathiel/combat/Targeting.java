package com.des.weapons.azrathiel.combat;

import com.des.weapons.azrathiel.AzrathielModule;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.*;
import org.bukkit.scoreboard.Team;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

/** Target acquisition and filtering. Decides who counts as an enemy; everything else (master, pets, villagers, NPCs...) is safe. */
public final class Targeting {
    private static final Set<String> NEVER = Set.of("VILLAGER", "WANDERING_TRADER", "IRON_GOLEM", "SNOW_GOLEM", "ALLAY", "COPPER_GOLEM", "ARMOR_STAND", "MANNEQUIN");
    private static final Set<String> RANGED = Set.of("SKELETON", "STRAY", "BOGGED", "PILLAGER", "BLAZE", "GHAST", "WITCH", "BREEZE", "SHULKER", "EVOKER", "ILLUSIONER", "WITHER", "GUARDIAN", "ELDER_GUARDIAN");
    private final AzrathielModule mod;
    public Targeting(AzrathielModule mod) { this.mod = mod; }

    public static boolean isBoss(LivingEntity e) {
        if (e instanceof Boss || e instanceof Warden) return true;
        String n = e.getType().name(); if (n.equals("ELDER_GUARDIAN") || n.equals("WITHER") || n.equals("ENDER_DRAGON")) return true;
        return maxHealth(e) >= 300;
    }
    public static double maxHealth(LivingEntity e) { try { var a = e.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH); return a == null ? e.getHealth() : a.getValue(); } catch (Throwable t) { return Math.max(20, e.getHealth()); } }
    public static boolean isRanged(LivingEntity e) { return RANGED.contains(e.getType().name()); }
    public static boolean isFlying(LivingEntity e) { return e instanceof Flying || e instanceof Phantom || e instanceof Vex || e instanceof Blaze || e instanceof EnderDragon || e instanceof Bat; }

    public boolean valid(Player master, Entity e) {
        if (!(e instanceof LivingEntity le) || le.isDead() || !le.isValid() || e.equals(master)) return false;
        if (NEVER.contains(e.getType().name()) || e.hasMetadata("NPC") || le.isInvulnerable()) return false;
        if (e instanceof Tameable t && t.isTamed()) return false;
        if (e instanceof Player p) return pvpAllowed(master, p);
        if (e instanceof Enemy || e instanceof Monster) return true;
        return e instanceof Mob m && master.equals(m.getTarget());
    }

    public boolean pvpAllowed(Player master, Player p) {
        String mode = mod.cfg.pvpMode; if (mode.equals("OFF")) return false;
        if (p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR || p.isDead()) return false;
        Team a = master.getScoreboard().getEntryTeam(master.getName()), b = p.getScoreboard().getEntryTeam(p.getName());
        if (a != null && a.equals(b)) return false;
        return mode.equals("ALL") || mod.adapt.recentPvpAttacker(master.getUniqueId(), p.getUniqueId(), 10_000);
    }

    /** Enemies within r of a point. Capped by performance.target-search-cap. */
    public List<LivingEntity> around(Player master, Location c, double r) {
        List<LivingEntity> out = new ArrayList<>(); if (c.getWorld() == null) return out;
        for (Entity e : c.getWorld().getNearbyEntities(c, r, r, r)) { if (valid(master, e) && e.getLocation().distanceSquared(c) <= r * r) { out.add((LivingEntity) e); if (out.size() >= mod.cfg.targetCap) break; } }
        out.sort(Comparator.comparingDouble(x -> x.getLocation().distanceSquared(c))); return out;
    }

    public LivingEntity nearestInCone(Player master, Location from, Vector dir, double range, double minDot) {
        LivingEntity best = null; double bd = Double.MAX_VALUE; Vector d = dir.clone().normalize();
        for (LivingEntity e : around(master, from, range)) {
            Vector to = e.getLocation().add(0, e.getHeight() / 2, 0).toVector().subtract(from.toVector()); double dist = to.length(); if (dist < 0.01) continue;
            if (to.normalize().dot(d) >= minDot && dist < bd) { bd = dist; best = e; }
        }
        return best;
    }

    public boolean isAlly(Player master, Entity e) {
        if (e.equals(master)) return true;
        if (e instanceof Tameable t && t.isTamed() && t.getOwner() != null && t.getOwner().getUniqueId().equals(master.getUniqueId())) return true;
        if (e instanceof Player p) { Team a = master.getScoreboard().getEntryTeam(master.getName()), b = p.getScoreboard().getEntryTeam(p.getName()); return a != null && a.equals(b); }
        return false;
    }
}
