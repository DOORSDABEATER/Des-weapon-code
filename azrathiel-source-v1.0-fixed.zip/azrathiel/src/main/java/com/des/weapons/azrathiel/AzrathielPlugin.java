package com.des.weapons.azrathiel;

import org.bukkit.plugin.java.JavaPlugin;

/**
 * STANDALONE test entry point only. When merging into the DeS plugin, DELETE this class and (in DeS's own main class) do:
 *     private AzrathielModule azrathiel;
 *     onEnable():  azrathiel = new AzrathielModule(this); azrathiel.enable();
 *     onDisable(): if (azrathiel != null) azrathiel.disable();
 * There is exactly one plugin entry point in the final JAR.
 */
public final class AzrathielPlugin extends JavaPlugin {
    private AzrathielModule module;
    @Override public void onEnable() { module = new AzrathielModule(this); module.enable(); }
    @Override public void onDisable() { if (module != null) module.disable(); }
}
