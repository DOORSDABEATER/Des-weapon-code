package com.des.weapons.azrathiel.model;

import com.des.weapons.azrathiel.AzrathielModule;
import com.des.weapons.azrathiel.core.AnimationController;
import com.des.weapons.azrathiel.core.Eidolon;
import com.des.weapons.azrathiel.core.Form;
import com.des.weapons.azrathiel.core.P;
import com.des.weapons.azrathiel.model.ModelDefs.Bone;
import io.papermc.paper.entity.TeleportFlag;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.components.CustomModelDataComponent;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.util.Transformation;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.List;
import java.util.UUID;

/**
 * Bone-rig renderer on item_display entities. ONE root display is moved (with client-side teleport interpolation);
 * every bone is a passenger and is animated purely through interpolated Transformations - no per-bone teleporting.
 * Bone matrices form a real hierarchy (torso > arm > forearm, head, core, markings); halo, fragments and rings are
 * independent root-level bones. All maths lives here; gameplay never reads from or waits on this class.
 */
public final class RigModel {
    private static final float D = (float) (Math.PI / 180.0);
    public static final String SCOREBOARD_TAG = "azrathiel_rig";

    public record RenderState(float yaw, float time, float haloAngle, float fragAngle, int markMask, int highlight, int tint,
                              boolean showHalo, boolean showFrags, boolean showMarks, float coreMul, int interp, AnimationController anim) {}

    private final AzrathielModule mod; private final Form form; private final List<Bone> bones; private final ItemDisplay[] disp;
    private ItemDisplay root; private final Matrix4f[] chain; private final Matrix4f rootM = new Matrix4f();
    private final float[][] last; private int lastTint = Integer.MIN_VALUE, lastMarkMask = -1; private int teleportFailures;
    private final Vector3f tv = new Vector3f(), sv = new Vector3f(); private final Quaternionf q = new Quaternionf();
    private Material mat = Material.PAPER;

    private RigModel(AzrathielModule mod, Form form) {
        this.mod = mod; this.form = form; this.bones = ModelDefs.of(form);
        disp = new ItemDisplay[bones.size()]; chain = new Matrix4f[bones.size()]; last = new float[bones.size()][8];
        for (int i = 0; i < chain.length; i++) chain[i] = new Matrix4f();
        Material m = Material.matchMaterial(mod.cfg.rigItemMaterial); if (m != null && m.isItem()) mat = m;
    }

    public static RigModel spawn(AzrathielModule mod, Location loc, Form form, UUID owner, int tint) {
        RigModel r = new RigModel(mod, form); World w = loc.getWorld(); String tag = owner.toString();
        r.root = w.spawn(loc, ItemDisplay.class, d -> { r.common(d, tag); d.setTeleportDuration(3); });
        for (int i = 0; i < r.bones.size(); i++) {
            Bone b = r.bones.get(i); final int ii = i;
            ItemDisplay d = w.spawn(loc, ItemDisplay.class, e -> {
                r.common(e, tag); e.setItemStack(r.stack(b.model(), tint, b.tint())); e.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.FIXED);
                if (b.glow()) e.setBrightness(new Display.Brightness(15, 15));
                e.setTransformation(new Transformation(new Vector3f(), new Quaternionf(), new Vector3f(0.0001f), new Quaternionf()));
            });
            r.disp[ii] = d; r.root.addPassenger(d);
        }
        r.lastTint = tint; return r;
    }

    private void common(ItemDisplay d, String ownerTag) {
        d.setPersistent(false); d.setInvulnerable(true); d.setGravity(false); d.setViewRange((float) mod.cfg.viewRange);
        d.setBillboard(Display.Billboard.FIXED); d.setShadowRadius(0f); d.addScoreboardTag(SCOREBOARD_TAG);
        d.getPersistentDataContainer().set(mod.keyRig, PersistentDataType.STRING, ownerTag);
    }

    private ItemStack stack(String model, int tint, boolean doTint) {
        ItemStack it = new ItemStack(mat); ItemMeta m = it.getItemMeta();
        try { m.setItemModel(NamespacedKey.fromString("azrathiel:" + model)); } catch (Throwable ignored) { }
        if (doTint) { try { CustomModelDataComponent c = m.getCustomModelDataComponent(); c.setColors(List.of(Color.fromRGB(tint & 0xFFFFFF))); m.setCustomModelDataComponent(c); } catch (Throwable ignored) { } }
        it.setItemMeta(m); return it;
    }

    public static boolean isRigEntity(Entity e) { return e instanceof ItemDisplay && e.getScoreboardTags().contains(SCOREBOARD_TAG); }
    public Form form() { return form; }
    /** UUIDs of every entity that belongs to this rig (used to tell live rigs from orphans). */
    public java.util.Set<UUID> ids() {
        java.util.Set<UUID> s = new java.util.HashSet<>(); if (root != null) s.add(root.getUniqueId());
        for (ItemDisplay d : disp) if (d != null) s.add(d.getUniqueId()); return s;
    }
    public Location location() { return root == null ? null : root.getLocation(); }
    public boolean valid() {
        if (root == null || !root.isValid() || teleportFailures > 5) return false;
        for (ItemDisplay d : disp) if (d == null || !d.isValid()) return false;
        return true;
    }

    public void teleport(Location loc, int duration) {
        if (root == null || !root.isValid()) return;
        root.setTeleportDuration(Math.max(0, Math.min(59, duration)));
        boolean ok; try { ok = root.teleport(loc, TeleportFlag.EntityState.RETAIN_PASSENGERS); } catch (Throwable t) { ok = false; }
        if (ok) teleportFailures = 0; else teleportFailures++;
    }

    public void remove() {
        for (ItemDisplay d : disp) if (d != null && d.isValid()) d.remove();
        if (root != null && root.isValid()) root.remove();
    }

    public void render(RenderState s) {
        AnimationController a = s.anim(); float t = s.time();
        float S = form.scale * Math.max(0.0001f, a.get(P.BODY_SCALE));
        float hover = a.get(P.HOVER_AMP) * (float) Math.sin(2 * Math.PI * a.get(P.HOVER_HZ) * t);
        rootM.identity().rotateY(-s.yaw() * D).translate(0, hover, 0).scale(S);
        boolean humanoid = form != Form.DORMANT;

        if (s.tint() != lastTint) { lastTint = s.tint(); for (int i = 0; i < bones.size(); i++) if (bones.get(i).tint() && disp[i] != null && disp[i].isValid()) disp[i].setItemStack(stack(bones.get(i).model(), s.tint(), true)); }
        if (humanoid && s.markMask() != lastMarkMask) {
            lastMarkMask = s.markMask();
            for (int i = 0; i < bones.size(); i++) { Bone b = bones.get(i); if (b.group() != ModelDefs.Group.MARK || disp[i] == null || !disp[i].isValid()) continue;
                boolean on = (s.markMask() & (1 << b.idx())) != 0; String key = on ? b.model().replace("_dim", "") : b.model(); disp[i].setItemStack(stack(key, 0, false)); }
        }

        for (int i = 0; i < bones.size(); i++) {
            Bone b = bones.get(i); Matrix4f m = chain[i]; m.set(b.parent() < 0 ? rootM : chain[b.parent()]);
            float leaf = b.s(); boolean hide = false; int idx = b.idx();
            switch (b.group()) {
                case BODY -> {
                    m.translate(b.x(), b.y() + (humanoid ? a.get(P.SINK) : 0f), b.z()).rotateX((a.get(P.TORSO_PITCH) + a.get(P.LEAN)) * D).rotateZ(a.get(P.TORSO_ROLL) * D);
                    if (!humanoid) m.rotateY(a.headYaw() * 0.5f * D);
                }
                case HEAD -> m.translate(b.x(), b.y(), b.z()).rotateY(a.headYaw() * D).rotateX(a.headPitch() * D);
                case CORE -> {
                    m.translate(b.x(), b.y(), b.z());
                    leaf = b.s() * a.get(P.CORE_SCALE) * (1f + 0.12f * (float) Math.sin(2 * Math.PI * a.get(P.CORE_PULSE) * t)) * s.coreMul();
                }
                case ARM_UP -> {
                    float sway = (float) Math.sin(t * (0.9 + 0.23 * idx) + idx * 1.9) * 2.5f; float sign = (idx % 2 == 0) ? -1f : 1f;
                    m.translate(b.x(), b.y(), b.z()).rotateZ(sign * (a.get(P.ARM_SPREAD + idx) + sway * 0.6f) * D).rotateX(-(a.get(P.ARM_RAISE + idx) + sway) * D);
                }
                case ARM_LO -> {
                    float sway = (float) Math.sin(t * (1.1 + 0.19 * idx) + idx * 2.3) * 2f;
                    m.translate(b.x(), b.y(), b.z()).rotateX(-(a.get(P.FORE_BEND + idx) + sway) * D);
                }
                case HALO -> {
                    float theta = (s.haloAngle() + idx * 45f) * D, R = 0.85f * a.get(P.HALO_RADIUS); hide = !s.showHalo();
                    m.translate(0, 1.0f, -0.42f).rotateX(a.get(P.HALO_TILT) * D).rotateZ(theta).translate(R, 0, 0);
                    leaf = b.s() * Math.max(0.2f, a.get(P.HALO_RADIUS));
                }
                case FRAG -> {
                    float phi = (s.fragAngle() * (1f + 0.13f * idx) + idx * 45f) * D, r = a.get(P.FRAG_RADIUS) * (1f + 0.08f * ((idx * 7) % 5));
                    float h = ((idx % 3) - 1) * 0.28f + a.get(P.FRAG_BOB) * (float) Math.sin(t * 1.3 + idx * 0.9) + (humanoid ? 0.1f : 0f); hide = !s.showFrags();
                    m.translate(r * (float) Math.cos(phi), h, r * (float) Math.sin(phi)).rotateY(t * 0.9f + idx).rotateX(t * 0.6f + idx * 0.5f);
                }
                case MARK -> {
                    float psi = (idx * 45f + 22.5f) * D; boolean on = (s.markMask() & (1 << idx)) != 0; hide = !s.showMarks();
                    m.translate(0.30f * (float) Math.cos(psi), 0.12f + 0.30f * (float) Math.sin(psi), 0.37f);
                    leaf = b.s() * (on ? (s.highlight() == idx ? 1.35f + 0.12f * (float) Math.sin(t * 6) : 1.0f) : 0.6f);
                }
                case RING -> {
                    float ang = t * (30f + 25f * idx) * (idx % 2 == 0 ? 1f : -1f); hide = !s.showHalo();
                    m.rotateY(ang * D).rotateX((35f + 50f * idx) * D).rotateZ(ang * 0.4f * D); leaf = b.s() * Math.max(0.2f, a.get(P.HALO_RADIUS));
                }
            }
            push(i, m, leaf, hide, s.interp());
        }
    }

    private void push(int i, Matrix4f m, float leaf, boolean hide, int interp) {
        ItemDisplay d = disp[i]; if (d == null || !d.isValid()) return;
        m.getTranslation(tv); float uni = m.getScale(sv).x; m.getNormalizedRotation(q);
        float sc = hide ? 0.0001f : Math.max(0.0001f, uni * leaf);
        float[] c = {tv.x, tv.y, tv.z, q.x, q.y, q.z, q.w, sc}; float[] l = last[i]; boolean changed = false;
        for (int k = 0; k < 8; k++) if (Math.abs(c[k] - l[k]) > (k < 3 ? 0.003f : 0.002f)) { changed = true; break; }
        if (!changed) return;
        System.arraycopy(c, 0, l, 0, 8);
        d.setInterpolationDelay(0); d.setInterpolationDuration(Math.max(1, interp));
        d.setTransformation(new Transformation(new Vector3f(tv), new Quaternionf(q), new Vector3f(sc, sc, sc), new Quaternionf()));
    }
}
