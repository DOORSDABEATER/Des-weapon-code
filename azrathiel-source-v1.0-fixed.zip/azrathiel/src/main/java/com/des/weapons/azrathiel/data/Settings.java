package com.des.weapons.azrathiel.data;

import com.des.weapons.azrathiel.core.Eidolon;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/** Validated view of config.yml. Every value is clamped to a sane range; problems are collected in {@link #warnings}. */
public final class Settings {
    public final List<String> warnings = new ArrayList<>();

    // access / weapon
    public boolean fullAccess, requireWeapon, progressionEnabled;
    public int weaponGraceSeconds, killsPerEidolon, bossKillBonus;
    public String weaponMaterial, rigItemMaterial; public double weaponDamage, weaponSpeed;
    public List<Eidolon> unlockOrder = new ArrayList<>();
    // essence
    public double essenceMax, regenDormant, regenReleased;
    // entity
    public double followDistance, followHeight, releasedHeight, smoothTime, maxSpeed, fastSpeed, snapDistance, maxTurnRate, viewRange;
    public int moveInterval, animInterval, aiInterval;
    // combat
    public double detectionRadius, leashRadius, damageMul, cooldownMul, costMul, bossMaxPct, defendTriggerHealth, basicDamage, basicReach;
    public int globalCooldownMs, basicCooldownMs; public boolean autoReleaseOnDanger, dormantCanFight, bypassIFrames;
    public String pvpMode; public final Map<Eidolon, Double> eidolonDamage = new EnumMap<>(Eidolon.class);
    // defense
    public boolean interceptProjectiles, meleeShove; public int interceptCooldownMs; public double interceptCost;
    // ultimate
    public double ultCost, ultRadius, ultAwakeningDmg, ultManifestDmg, ultDominationDmg, ultMainDmg, ultFinalDmg, ultKnockback;
    public int ultCooldownSec, ultDurationTicks, ultExhaustPercent;
    // last guardian
    public boolean lgEnabled; public double lgRadius, lgEnergy, lgDrain, lgInterceptCost, lgBastionCost, lgShockDamage, lgShockRadius, lgShockCost;
    public int lgMaxSeconds, lgExhaustSeconds, lgCooldownSeconds;
    // voice / audio / visual / perf
    public boolean recordingsInstalled, usePackSoundEvents, particles, hudActionbar, voiceBroadcast;
    public String subtitleMode, placeholderSound; public int ambientSeconds, maxParticlesPerCast, auraInterval, maxActiveRigs, targetCap;

    public void load(FileConfiguration c) {
        warnings.clear();
        fullAccess = c.getBoolean("access.full-access", true);
        requireWeapon = c.getBoolean("access.require-weapon", true);
        weaponGraceSeconds = i(c, "access.weapon-grace-seconds", 5, 0, 600);
        weaponMaterial = c.getString("weapon.material", "NETHERITE_SWORD");
        rigItemMaterial = c.getString("weapon.rig-item-material", "PAPER");
        weaponDamage = d(c, "weapon.attack-damage", 11.0, 1, 100); weaponSpeed = d(c, "weapon.attack-speed", 1.6, 0.4, 4);
        progressionEnabled = c.getBoolean("progression.enabled", false);
        killsPerEidolon = i(c, "progression.kills-per-eidolon", 40, 1, 100000); bossKillBonus = i(c, "progression.boss-kill-bonus", 10, 0, 1000);
        unlockOrder.clear();
        for (String s : c.getStringList("progression.unlock-order")) { Eidolon e = Eidolon.parse(s); if (e != null && !unlockOrder.contains(e)) unlockOrder.add(e); else if (e == null) warnings.add("progression.unlock-order: unknown Eidolon '" + s + "'"); }
        for (Eidolon e : Eidolon.values()) if (!unlockOrder.contains(e)) unlockOrder.add(e);

        essenceMax = d(c, "essence.max", 1000, 50, 1_000_000); regenDormant = d(c, "essence.regen-dormant", 6, 0, 1000); regenReleased = d(c, "essence.regen-released", 4, 0, 1000);

        followDistance = d(c, "entity.follow-distance", 1.7, 0.8, 8); followHeight = d(c, "entity.follow-height", 1.5, 0.3, 6);
        releasedHeight = d(c, "entity.hover-height-released", 1.4, 0.3, 6); smoothTime = d(c, "entity.smooth-time", 0.30, 0.05, 2);
        maxSpeed = d(c, "entity.max-speed", 14, 2, 80); fastSpeed = d(c, "entity.fast-speed", 30, 4, 120); snapDistance = d(c, "entity.snap-distance", 30, 8, 200);
        maxTurnRate = d(c, "entity.max-turn-rate", 220, 30, 1080); viewRange = d(c, "entity.view-range", 1.6, 0.2, 8);
        moveInterval = i(c, "entity.move-interval-ticks", 2, 1, 6); animInterval = i(c, "entity.anim-interval-ticks", 2, 1, 6); aiInterval = i(c, "entity.ai-interval-ticks", 5, 1, 40);

        detectionRadius = d(c, "combat.detection-radius", 20, 5, 64); leashRadius = d(c, "combat.leash-radius", 26, 8, 96);
        autoReleaseOnDanger = c.getBoolean("combat.auto-release-on-danger", true); dormantCanFight = c.getBoolean("combat.dormant-can-fight", false);
        globalCooldownMs = i(c, "combat.global-cooldown-ms", 1400, 0, 60000);
        basicDamage = d(c, "combat.basic-attack.damage", 7.0, 0, 1000); basicCooldownMs = i(c, "combat.basic-attack.cooldown-ms", 1100, 100, 60000); basicReach = d(c, "combat.basic-attack.reach", 7.0, 2, 24);
        damageMul = d(c, "combat.damage-multiplier", 1.0, 0, 100); cooldownMul = d(c, "combat.cooldown-multiplier", 1.0, 0.05, 100); costMul = d(c, "combat.cost-multiplier", 1.0, 0, 100);
        bossMaxPct = d(c, "combat.boss-max-health-percent", 0.12, 0.001, 1.0); bypassIFrames = c.getBoolean("combat.bypass-invulnerability-frames", true);
        defendTriggerHealth = d(c, "combat.defend-trigger-health", 0.5, 0.05, 1.0);
        pvpMode = String.valueOf(c.getString("combat.pvp", "DEFENSIVE")).toUpperCase();
        if (!List.of("OFF", "DEFENSIVE", "ALL").contains(pvpMode)) { warnings.add("combat.pvp must be OFF, DEFENSIVE or ALL - using DEFENSIVE"); pvpMode = "DEFENSIVE"; }
        ConfigurationSection pe = c.getConfigurationSection("combat.per-eidolon-damage");
        for (Eidolon e : Eidolon.values()) eidolonDamage.put(e, pe == null ? 1.0 : Math.max(0, Math.min(20, pe.getDouble(e.name(), 1.0))));

        interceptProjectiles = c.getBoolean("defense.intercept-projectiles", true); meleeShove = c.getBoolean("defense.melee-shove", true);
        interceptCooldownMs = i(c, "defense.intercept-cooldown-ms", 2500, 0, 60000); interceptCost = d(c, "defense.intercept-cost", 8, 0, 1000);

        ultCost = d(c, "ultimate.cost", 800, 0, 1_000_000); ultCooldownSec = i(c, "ultimate.cooldown-seconds", 180, 0, 86400);
        ultRadius = d(c, "ultimate.radius", 28, 6, 96); ultDurationTicks = i(c, "ultimate.duration-ticks", 240, 120, 1200);
        ultAwakeningDmg = d(c, "ultimate.damage.awakening", 25, 0, 10000); ultManifestDmg = d(c, "ultimate.damage.manifestation-per-eidolon", 12, 0, 10000);
        ultDominationDmg = d(c, "ultimate.damage.domination-per-second", 8, 0, 10000); ultMainDmg = d(c, "ultimate.damage.main-attack", 90, 0, 100000);
        ultFinalDmg = d(c, "ultimate.damage.final-impact", 60, 0, 100000); ultKnockback = d(c, "ultimate.knockback", 2.0, 0, 10);
        ultExhaustPercent = i(c, "ultimate.essence-left-percent", 10, 0, 100);

        lgEnabled = c.getBoolean("last-guardian.enabled", true); lgRadius = d(c, "last-guardian.radius", 12, 3, 48);
        lgEnergy = d(c, "last-guardian.energy", 600, 10, 100000); lgDrain = d(c, "last-guardian.drain-per-second", 4, 0.1, 1000);
        lgInterceptCost = d(c, "last-guardian.intercept-cost", 6, 0, 1000); lgBastionCost = d(c, "last-guardian.bastion-cost", 80, 0, 10000);
        lgShockDamage = d(c, "last-guardian.final-shockwave.damage", 40, 0, 10000); lgShockRadius = d(c, "last-guardian.final-shockwave.radius", 14, 2, 64); lgShockCost = d(c, "last-guardian.final-shockwave.cost", 100, 0, 10000);
        lgMaxSeconds = i(c, "last-guardian.max-seconds", 90, 5, 3600); lgExhaustSeconds = i(c, "last-guardian.exhaust-seconds", 20, 1, 3600); lgCooldownSeconds = i(c, "last-guardian.cooldown-seconds", 300, 0, 86400);

        recordingsInstalled = c.getBoolean("voice.recordings-installed", false); subtitleMode = String.valueOf(c.getString("voice.subtitle-mode", "ACTIONBAR")).toUpperCase();
        placeholderSound = c.getString("voice.placeholder-sound", "minecraft:entity.warden.listening"); ambientSeconds = i(c, "voice.ambient-interval-seconds", 40, 5, 3600);
        voiceBroadcast = c.getBoolean("voice.broadcast-to-nearby", false);
        usePackSoundEvents = c.getBoolean("audio.use-pack-sound-events", true);
        particles = c.getBoolean("visual.particles", true); maxParticlesPerCast = i(c, "visual.max-particles-per-cast", 400, 0, 20000); auraInterval = i(c, "visual.aura-interval-ticks", 4, 1, 40);
        maxActiveRigs = i(c, "performance.max-active-rigs", 40, 1, 500); targetCap = i(c, "performance.target-search-cap", 64, 8, 512);
        hudActionbar = c.getBoolean("hud.actionbar", true);
    }

    private double d(FileConfiguration c, String path, double def, double min, double max) {
        double v = c.getDouble(path, def);
        if (Double.isNaN(v) || v < min || v > max) { warnings.add(path + "=" + v + " out of range [" + min + ".." + max + "], clamped"); v = Double.isNaN(v) ? def : Math.max(min, Math.min(max, v)); }
        return v;
    }
    private int i(FileConfiguration c, String path, int def, int min, int max) {
        int v = c.getInt(path, def);
        if (v < min || v > max) { warnings.add(path + "=" + v + " out of range [" + min + ".." + max + "], clamped"); v = Math.max(min, Math.min(max, v)); }
        return v;
    }
}
