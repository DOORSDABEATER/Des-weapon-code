package com.des.weapons.azrathiel.combat;

import com.des.weapons.azrathiel.core.Convergence;
import com.des.weapons.azrathiel.core.Convergence.Profile;
import com.des.weapons.azrathiel.core.Eidolon;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;
import org.bukkit.FluidCollisionMode;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

/**
 * One module per Eidolon. Each does its DAMAGE and EFFECTS first (server-authoritative), then its cosmetics in a guarded block.
 * Stage keys: stage*100 = direct hit, stage*100+n = follow-up hits, so nothing is ever double counted.
 */
final class Modules {
    private Modules() {}

    static void apply(CastCtx c, Eidolon e, int stage) {
        switch (e) {
            case VIGOR -> vigor(c, stage); case ABYSS -> abyss(c, stage); case FATE -> fate(c, stage); case RUIN -> ruin(c, stage);
            case AEGIS -> aegis(c, stage); case EVOLUTION -> evolution(c, stage); case WRAITH -> wraith(c, stage); case DOMINION -> dominion(c, stage);
        }
    }

    static double dmg(CastCtx c, Eidolon e) { return c.spec.stageDamage().getOrDefault(e, 0.0); }
    static double radius(CastCtx c, Eidolon e) { return Convergence.PROFILES.get(e).radius() + 0.5 * (c.spec.order().size() - 1); }
    static List<LivingEntity> around(CastCtx c, Location l, double r) { return c.mod.targeting.around(c.master, l, r); }
    static int rgb(Eidolon e) { return e.rgb; }

    // ---- VIGOR: TITAN BREAKER -------------------------------------------------------------------------------------
    static void vigor(CastCtx c, int st) {
        Profile p = Convergence.PROFILES.get(Eidolon.VIGOR); double r = radius(c, Eidolon.VIGOR), d = dmg(c, Eidolon.VIGOR); Location f = c.focus.clone();
        for (LivingEntity t : around(c, f, r)) {
            double dist = t.getLocation().distance(f);
            Vector kb = Util.outward(f, t.getLocation(), p.knockback() * (1.0 - 0.5 * dist / (r + 1))).setY(0.45);
            Dmg.deal(c, st * 100, t, d * (dist < 1.6 ? 1.25 : 1.0), false, kb);
            Dmg.effects(t, p.enemy(), 1.0);
        }
        if (c.cosmetics) c.mod.fx.safe(() -> { c.mod.fx.shockwave(f, r, rgb(Eidolon.VIGOR), Particle.CRIT); c.mod.fx.spawn(f, Particle.EXPLOSION_EMITTER, 1, 0, 0, 0, 0);
            c.mod.fx.sound(f, "cast.vigor", 1.3f, 0.7f); });
    }

    // ---- ABYSS: VOID CONSUMPTION ----------------------------------------------------------------------------------
    static void abyss(CastCtx c, int st) {
        Profile p = Convergence.PROFILES.get(Eidolon.ABYSS); double r = radius(c, Eidolon.ABYSS), d = dmg(c, Eidolon.ABYSS); Location f = c.focus.clone();
        for (int pulse = 0; pulse < 3; pulse++) {
            final int pp = pulse;
            c.mod.tasks.later(pulse * 20L, () -> {
                for (LivingEntity t : around(c, f, r)) {
                    Vector pull = f.toVector().subtract(t.getLocation().toVector()); double len = pull.length();
                    if (len > 0.8 && !Targeting.isBoss(t)) { try { t.setVelocity(pull.normalize().multiply(Math.min(1.1, len * 0.3)).setY(0.12)); } catch (Throwable ignored) { } }
                    Dmg.deal(c, st * 100 + pp, t, d * (pp == 0 ? 0.5 : 0.25), true, null);
                    if (pp == 0) Dmg.effects(t, p.enemy(), 1.0);
                }
                Util.removeProjectiles(c, f, r);   // the void consumes what is thrown into it
                if (c.cosmetics) c.mod.fx.safe(() -> { c.mod.fx.spawn(f.clone().add(0, 1, 0), Particle.REVERSE_PORTAL, 80, r * 0.4, 0.8, r * 0.4, 0.2);
                    c.mod.fx.ring(f, r, rgb(Eidolon.ABYSS), 28, 0.2); c.mod.fx.sound(f, "cast.abyss", 1f, 0.6f + 0.1f * pp); });
            });
        }
    }

    // ---- FATE: INEVITABLE FUTURE ----------------------------------------------------------------------------------
    static void fate(CastCtx c, int st) {
        double range = Convergence.PROFILES.get(Eidolon.FATE).range(), d = dmg(c, Eidolon.FATE);
        List<LivingEntity> all = new ArrayList<>(around(c, c.origin, range));
        all.sort(Comparator.comparing((LivingEntity t) -> !Targeting.isBoss(t)).thenComparingDouble(t -> t.getLocation().distanceSquared(c.origin)));
        List<LivingEntity> marked = new ArrayList<>(all.subList(0, Math.min(4, all.size())));
        for (LivingEntity t : marked) {
            Dmg.effect(t, "glowing", 120, 0); Dmg.deal(c, st * 100, t, d * 0.35, true, null);
            if (c.cosmetics) c.mod.fx.safe(() -> c.mod.fx.line(c.origin.clone().add(0, 1.5, 0), t.getLocation().add(0, 1, 0), rgb(Eidolon.FATE), 0.6));
        }
        c.mod.tasks.later(15, () -> {
            for (LivingEntity t : marked) {
                if (!t.isValid()) continue;
                Dmg.deal(c, st * 100 + 1, t, d * 0.65, true, new Vector(0, 0.3, 0));    // the strike that was always going to land
                if (c.cosmetics) c.mod.fx.safe(() -> { c.mod.fx.spawn(t.getLocation().add(0, 1, 0), Particle.END_ROD, 24, 0.3, 0.6, 0.3, 0.05); c.mod.fx.sound(t.getLocation(), "cast.fate", 1f, 1.2f); });
            }
        });
    }

    // ---- RUIN: DECAYING JUDGEMENT ---------------------------------------------------------------------------------
    static void ruin(CastCtx c, int st) {
        Profile p = Convergence.PROFILES.get(Eidolon.RUIN); double r = radius(c, Eidolon.RUIN), d = dmg(c, Eidolon.RUIN); Location f = c.focus.clone();
        for (LivingEntity t : around(c, f, r)) { Dmg.deal(c, st * 100, t, d * 0.4, true, null); Dmg.effects(t, p.enemy(), 1.0); }
        for (int pulse = 0; pulse < 4; pulse++) {
            final int pp = pulse;
            c.mod.tasks.later(10L * (pulse + 1), () -> {
                for (LivingEntity t : around(c, f, r)) { double dot = d * 0.15 + (Targeting.isBoss(t) ? 0 : Math.min(4, Targeting.maxHealth(t) * 0.01)); Dmg.deal(c, st * 100 + 1 + pp, t, dot, true, null); }
                if (c.cosmetics) c.mod.fx.safe(() -> { c.mod.fx.spawn(f.clone().add(0, 0.5, 0), Particle.ASH, 60, r * 0.5, 0.6, r * 0.5, 0.01); c.mod.fx.ring(f, r, rgb(Eidolon.RUIN), 30, 0.1); });
            });
        }
        if (c.cosmetics) c.mod.fx.safe(() -> c.mod.fx.sound(f, "cast.ruin", 1.1f, 0.6f));
    }

    // ---- AEGIS: ABSOLUTE BASTION ----------------------------------------------------------------------------------
    static void aegis(CastCtx c, int st) {
        double r = radius(c, Eidolon.AEGIS), d = dmg(c, Eidolon.AEGIS); Profile p = Convergence.PROFILES.get(Eidolon.AEGIS);
        Location ctr0 = Util.masterOrOrigin(c);
        if (c.master != null && c.master.isOnline() && !c.master.isDead()) Dmg.effects(c.master, p.self(), 1.0);
        for (Entity e : ctr0.getWorld().getNearbyEntities(ctr0, r, r, r)) if (e instanceof LivingEntity le && !le.equals(c.master) && c.mod.targeting.isAlly(c.master, e)) Dmg.effects(le, p.self(), 1.0);
        for (LivingEntity t : around(c, ctr0, r)) Dmg.deal(c, st * 100, t, d, false, Util.outward(ctr0, t.getLocation(), 0.9).setY(0.3));
        c.mod.tasks.every(0, 2, n -> {
            if (n >= 80) return false; Location ctr = Util.masterOrOrigin(c); if (ctr.getWorld() == null) return false;
            Util.removeProjectiles(c, ctr, r);                                                      // the wall: nothing hostile flies through
            for (LivingEntity t : around(c, ctr, r)) { if (Targeting.isBoss(t)) continue; try { t.setVelocity(t.getVelocity().add(Util.outward(ctr, t.getLocation(), 0.25))); } catch (Throwable ignored) { } }
            if (c.cosmetics && n % 5 == 0) c.mod.fx.safe(() -> { c.mod.fx.sphere(ctr.clone().add(0, 1, 0), r, rgb(Eidolon.AEGIS), 40); });
            return true;
        });
        if (c.cosmetics) c.mod.fx.safe(() -> c.mod.fx.sound(ctr0, "cast.aegis", 1.2f, 1.0f));
    }

    // ---- EVOLUTION: ADAPTIVE RESPONSE -----------------------------------------------------------------------------
    static void evolution(CastCtx c, int st) {
        Profile p = Convergence.PROFILES.get(Eidolon.EVOLUTION); double r = radius(c, Eidolon.EVOLUTION), d = dmg(c, Eidolon.EVOLUTION);
        Location ctr = Util.masterOrOrigin(c); String cause = c.master == null ? "" : c.mod.adapt.dominantCause(c.master.getUniqueId(), 15_000);
        Set<String> seen = c.master == null ? Set.of() : c.mod.adapt.attackerTypes(c.master.getUniqueId(), 30_000);
        if (c.master != null && c.master.isOnline() && !c.master.isDead()) {
            Dmg.effects(c.master, p.self(), 1.0);
            switch (cause) {                                              // learn from what has been hurting the master, and counter it
                case "PROJECTILE" -> { Dmg.effect(c.master, "speed", 160, 1); Util.removeProjectiles(c, ctr, 10); }
                case "FIRE", "FIRE_TICK", "LAVA", "HOT_FLOOR" -> Dmg.effect(c.master, "fire_resistance", 300, 0);
                case "ENTITY_EXPLOSION", "BLOCK_EXPLOSION" -> Dmg.effect(c.master, "resistance", 200, 1);
                case "MAGIC", "WITHER", "POISON" -> Dmg.effect(c.master, "absorption", 300, 2);
                case "ENTITY_ATTACK", "ENTITY_SWEEP_ATTACK" -> { Dmg.effect(c.master, "resistance", 160, 0); Dmg.effect(c.master, "regeneration", 100, 0); }
                default -> { }
            }
        }
        for (LivingEntity t : around(c, ctr, r)) Dmg.deal(c, st * 100, t, d * (seen.contains(t.getType().name()) ? 1.5 : 1.0), true, null);   // hits harder against what it has already learned
        if (c.cosmetics) c.mod.fx.safe(() -> { c.mod.fx.ring(ctr, r, rgb(Eidolon.EVOLUTION), 36, 0.3); c.mod.fx.spawn(ctr.clone().add(0, 1, 0), Particle.ENCHANT, 50, 1, 1, 1, 1); c.mod.fx.sound(ctr, "cast.evolution", 1f, 1.1f); });
    }

    // ---- WRAITH: SPECTRAL EXECUTION -------------------------------------------------------------------------------
    static void wraith(CastCtx c, int st) {
        double range = Convergence.PROFILES.get(Eidolon.WRAITH).range(), d = dmg(c, Eidolon.WRAITH);
        boolean alive = c.master != null && c.master.isOnline() && !c.master.isDead();
        Location start = (alive ? c.master.getEyeLocation() : c.origin.clone().add(0, 1.5, 0));
        Vector dir = c.focus.toVector().subtract(start.toVector()); if (dir.lengthSquared() < 0.25) dir = start.getDirection();
        dir.normalize(); World w = start.getWorld();
        RayTraceResult rt = w.rayTraceBlocks(start, dir, range, FluidCollisionMode.NEVER, true);
        double len = rt == null ? range : Math.max(2, start.toVector().distance(rt.getHitPosition()) - 0.8);
        Location end = start.clone().add(dir.clone().multiply(len)); Location mid = start.clone().add(dir.clone().multiply(len / 2));
        for (LivingEntity t : around(c, mid, len / 2 + 3)) {
            if (Util.segDist(start, end, t.getLocation().add(0, t.getHeight() / 2, 0)) > 2.4) continue;
            boolean execute = !Targeting.isBoss(t) && t.getHealth() <= Targeting.maxHealth(t) * 0.15;     // executes only the nearly dead, never bosses
            Dmg.deal(c, st * 100, t, execute ? t.getHealth() + 5 : d, true, dir.clone().multiply(0.4));
            Dmg.effects(t, Convergence.PROFILES.get(Eidolon.WRAITH).enemy(), 1.0);
        }
        if (c.vael != null) c.vael.dashTo(end, 12);
        if (c.cosmetics) c.mod.fx.safe(() -> { c.mod.fx.line(start, end, rgb(Eidolon.WRAITH), 0.5); c.mod.fx.spawn(mid, Particle.SOUL, 30, len / 4, 0.5, len / 4, 0.02); c.mod.fx.sound(start, "cast.wraith", 1f, 0.9f); });
    }

    // ---- DOMINION: SOVEREIGN DECREE -------------------------------------------------------------------------------
    static void dominion(CastCtx c, int st) {
        Profile p = Convergence.PROFILES.get(Eidolon.DOMINION); double r = radius(c, Eidolon.DOMINION), d = dmg(c, Eidolon.DOMINION); Location ctr = Util.masterOrOrigin(c);
        for (LivingEntity t : around(c, ctr, r)) { Dmg.deal(c, st * 100, t, d, false, Util.outward(ctr, t.getLocation(), 0.4)); Dmg.effects(t, p.enemy(), 1.0); }
        Util.zone(c, () -> Util.masterOrOrigin(c), r, 80, 10, (list, n) -> Util.clearTargets(list));      // suppression: enemies lose their aggression
        if (c.cosmetics) c.mod.fx.safe(() -> { c.mod.fx.ring(ctr, r, rgb(Eidolon.DOMINION), 40, 0.2); c.mod.fx.ring(ctr, r * 0.6, rgb(Eidolon.DOMINION), 24, 0.6); c.mod.fx.sound(ctr, "cast.dominion", 1f, 0.8f); });
    }
}
