package com.des.weapons.azrathiel;

import com.des.weapons.azrathiel.cmd.AzrathielCommand;
import com.des.weapons.azrathiel.combat.*;
import com.des.weapons.azrathiel.core.*;
import com.des.weapons.azrathiel.data.BondData;
import com.des.weapons.azrathiel.data.Settings;
import com.des.weapons.azrathiel.data.Store;
import com.des.weapons.azrathiel.entity.Vael;
import com.des.weapons.azrathiel.entity.VaelManager;
import com.des.weapons.azrathiel.gui.Menu;
import com.des.weapons.azrathiel.gui.Prompts;
import com.des.weapons.azrathiel.item.WeaponItem;
import com.des.weapons.azrathiel.voice.Voice;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.HandlerList;
import org.bukkit.permissions.Permission;
import org.bukkit.permissions.PermissionDefault;
import org.bukkit.plugin.Plugin;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;

/**
 * Single integration point of the AZRATHIEL weapon. A host plugin (the DeS plugin) only does:
 *   module = new AzrathielModule(this); module.enable();     // onEnable
 *   module.disable();                                         // onDisable
 * No plugin.yml entries are required: command and permissions are registered programmatically.
 */
public final class AzrathielModule {
    private static final MiniMessage MM = MiniMessage.miniMessage();
    public static AzrathielModule instance;

    public final Plugin plugin; public final Settings cfg = new Settings(); public boolean debug, testing;
    public Store store; public VoiceLibrary voiceLib; public Tasks tasks; public Fx fx; public Targeting targeting; public AbilityExecutor executor;
    public Voice voice; public VaelManager vaels; public WeaponItem weapon; public Prompts prompts; public Actions actions; public Events events;
    public final AdaptLog adapt = new AdaptLog(); public final EffectivenessTracker tracker = new EffectivenessTracker();
    public NamespacedKey keyRig; public File dir; private Convergence.Balance balance = Convergence.Balance.DEFAULT; private AzrathielCommand command; private Menu.Listener menuListener; private boolean enabled;

    public AzrathielModule(Plugin plugin) { this.plugin = plugin; }

    public void enable() {
        if (enabled) return; instance = this; dir = new File(plugin.getDataFolder(), "azrathiel");
        if (!dir.exists() && !dir.mkdirs()) plugin.getLogger().warning("Could not create " + dir);
        copyResource("azrathiel/config.yml", new File(dir, "config.yml")); copyResource("azrathiel/voice/vaelzarion_voice.txt", new File(dir, "voice/vaelzarion_voice.txt"));
        loadConfig(); loadVoice();
        keyRig = new NamespacedKey(plugin, "azrathiel_rig_owner");
        store = new Store(plugin, dir); store.loadAll(); tasks = new Tasks(plugin); fx = new Fx(this); targeting = new Targeting(this); executor = new AbilityExecutor(this);
        voice = new Voice(this); weapon = new WeaponItem(plugin, cfg); vaels = new VaelManager(this); prompts = new Prompts(this); actions = new Actions(this); events = new Events(this);
        registerPermissions();
        Bukkit.getPluginManager().registerEvents(events, plugin); menuListener = new Menu.Listener(); Bukkit.getPluginManager().registerEvents(menuListener, plugin); Bukkit.getPluginManager().registerEvents(prompts, plugin);
        command = new AzrathielCommand(this); Bukkit.getCommandMap().register("azrathiel", command);
        int purged = vaels.purgeAll(); vaels.start();
        tasks.every(600, 600, n -> { store.saveDirtyAsync(); return true; });
        enabled = true;
        plugin.getLogger().info("AZRATHIEL ready: " + voiceLib.size() + " voice lines, " + Convergence.allMasks().size() + " Convergences, " + store.all().size() + " bonds, purged " + purged + " stray rig entities."
                + (cfg.fullAccess ? " FULL ACCESS is ON (development default)." : ""));
        for (String w : cfg.warnings) plugin.getLogger().warning("config: " + w);
        for (Player p : Bukkit.getOnlinePlayers()) { BondData b = store.byOwner(p.getUniqueId()); if (b != null && b.summoned) tasks.later(20, () -> { if (p.isOnline() && vaels.of(p.getUniqueId()) == null) vaels.summon(p, b); }); }
    }

    public void disable() {
        if (!enabled) return; enabled = false;
        try { tasks.cancelAll(); } catch (Throwable ignored) { }
        try { vaels.shutdown(); } catch (Throwable t) { plugin.getLogger().log(Level.WARNING, "shutdown", t); }
        try { store.saveAllNow(); } catch (Throwable t) { plugin.getLogger().log(Level.SEVERE, "final save failed", t); }
        try { if (command != null) command.unregister(Bukkit.getCommandMap()); } catch (Throwable ignored) { }
        try { HandlerList.unregisterAll(events); HandlerList.unregisterAll(prompts); if (menuListener != null) HandlerList.unregisterAll(menuListener); } catch (Throwable ignored) { }   // only our own listeners
        instance = null;
    }

    /** Hot reload of config.yml and voice packs. Bonds, rigs and cooldowns are untouched. */
    public List<String> reload() {
        loadConfig(); loadVoice(); weapon = new WeaponItem(plugin, cfg);
        for (Vael v : vaels.all()) v.syncPrefs();
        return new ArrayList<>(cfg.warnings);
    }

    private void loadConfig() {
        YamlConfiguration y = YamlConfiguration.loadConfiguration(new File(dir, "config.yml"));
        try (InputStream in = plugin.getResource("azrathiel/config.yml")) { if (in != null) y.setDefaults(YamlConfiguration.loadConfiguration(new java.io.InputStreamReader(in, java.nio.charset.StandardCharsets.UTF_8))); } catch (IOException ignored) { }
        cfg.load(y); debug = y.getBoolean("debug", false);
        balance = new Convergence.Balance(cfg.damageMul, cfg.cooldownMul, cfg.costMul, new java.util.EnumMap<>(cfg.eidolonDamage));
    }

    private void loadVoice() {
        List<String> all = new ArrayList<>(); File vd = new File(dir, "voice"); File[] files = vd.listFiles((d, n) -> n.endsWith(".txt"));
        if (files != null) { Arrays.sort(files, (a, b) -> a.getName().equals("vaelzarion_voice.txt") ? -1 : b.getName().equals("vaelzarion_voice.txt") ? 1 : a.getName().compareTo(b.getName()));
            for (File f : files) try { all.addAll(Files.readAllLines(f.toPath())); } catch (IOException e) { plugin.getLogger().warning("Could not read voice pack " + f.getName() + ": " + e); } }
        VoiceLibrary lib = VoiceLibrary.parse(all);
        if (lib.size() == 0) { try (InputStream in = plugin.getResource("azrathiel/voice/vaelzarion_voice.txt")) { if (in != null) lib = VoiceLibrary.parse(List.of(new String(in.readAllBytes(), java.nio.charset.StandardCharsets.UTF_8).split("\n"))); } catch (IOException ignored) { } }
        for (String p : lib.problems()) plugin.getLogger().warning("voice: " + p);
        voiceLib = lib;
    }

    private void copyResource(String res, File target) {
        if (target.exists()) return;
        try (InputStream in = plugin.getResource(res)) {
            if (in == null) { plugin.getLogger().warning("Bundled resource missing: " + res); return; }
            if (target.getParentFile() != null) //noinspection ResultOfMethodCallIgnored
                target.getParentFile().mkdirs();
            Files.copy(in, target.toPath(), StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) { plugin.getLogger().warning("Could not write " + target + ": " + e); }
    }

    private void registerPermissions() {
        add("des.azrathiel.use", PermissionDefault.TRUE, "Bond with and command VAELZARION"); add("des.azrathiel.ultimate", PermissionDefault.TRUE, "Use EIGHTFOLD APOCALYPSE");
        add("des.azrathiel.admin", PermissionDefault.OP, "Administer AZRATHIEL (give, reassign, unlock, reload, selftest)");
    }
    private void add(String node, PermissionDefault def, String desc) { try { Bukkit.getPluginManager().addPermission(new Permission(node, desc, def)); } catch (IllegalArgumentException ignored) { } }

    // ---------------------------------------------------------------------------------------------- shared helpers
    public Component msg(String mm) { return MM.deserialize("<dark_gray>[<gradient:#7a1bff:#ffc83d>Azrathiel</gradient>]</dark_gray> " + mm); }
    public Convergence.Balance balance() { return balance; }
    public boolean unlocked(BondData b, Eidolon e) { return cfg.fullAccess || b.unlocked.contains(e); }

    /** Hook after any ability finishes its scheduled stages. */
    public void onCastFinished(Vael v, CastCtx ctx) { v.bond.touch(); if (debug) plugin.getLogger().info("cast " + (ctx.spec == null ? "basic" : ctx.spec.name()) + " dealt " + String.format("%.1f", ctx.totalDamage) + " in " + ctx.hits + " hits"); }

    /** Progression only ever ADDS unlocks (never removes), in the configured order. */
    public void applyProgression(BondData b, Player notify) {
        if (cfg.fullAccess || !cfg.progressionEnabled) return;
        long points = b.kills + (long) b.bossKills * cfg.bossKillBonus; int count = (int) Math.min(8, 1 + points / cfg.killsPerEidolon); boolean changed = false;
        for (int i = 0; i < count && i < cfg.unlockOrder.size(); i++) { Eidolon e = cfg.unlockOrder.get(i); if (b.unlocked.add(e)) { changed = true;
            if (notify != null) notify.sendMessage(msg("<gold>" + e.display.toUpperCase() + "</gold> <gray>awakens within VAELZARION: " + e.signature)); } }
        if (changed) { b.touch(); Vael v = vaels.of(b.owner); if (v != null) v.restoreMarkMask(); }
    }
}
