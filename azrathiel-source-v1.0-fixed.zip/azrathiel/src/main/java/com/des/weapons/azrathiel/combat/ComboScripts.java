package com.des.weapons.azrathiel.combat;

import com.des.weapons.azrathiel.core.Convergence;
import com.des.weapons.azrathiel.core.Eidolon;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static com.des.weapons.azrathiel.core.Eidolon.*;

/**
 * Handcrafted finales for the ten named Convergences. They run AFTER the generic modules of that combination
 * (which already did their own damage), and add the signature behaviour. Stage keys 9000+ never collide with module keys.
 */
final class ComboScripts {
    private ComboScripts() {}
    static final int GRAVITY = Convergence.mask(VIGOR, ABYSS), IMPACT = Convergence.mask(VIGOR, FATE), NULL = Convergence.mask(ABYSS, AEGIS),
            DECAY = Convergence.mask(RUIN, EVOLUTION), PROPHECY = Convergence.mask(FATE, WRAITH), SANCTUARY = Convergence.mask(AEGIS, DOMINION),
            DEVOURER = Convergence.mask(VIGOR, RUIN, ABYSS), REWRITE = Convergence.mask(FATE, EVOLUTION, WRAITH),
            SOVEREIGN = Convergence.mask(AEGIS, EVOLUTION, DOMINION), ASH = Convergence.mask(RUIN, DOMINION);

    static void finale(CastCtx c) {
        int m = c.spec.mask();
        if (m == GRAVITY) gravity(c); else if (m == IMPACT) impact(c); else if (m == NULL) nullBarrier(c); else if (m == DECAY) endlessDecay(c);
        else if (m == PROPHECY) prophecy(c); else if (m == SANCTUARY) sanctuary(c); else if (m == DEVOURER) devourer(c);
        else if (m == REWRITE) rewrite(c); else if (m == SOVEREIGN) unbreakable(c); else if (m == ASH) kingdomOfAsh(c);
    }

    private static boolean masterOk(CastCtx c) { return c.master != null && c.master.isOnline() && !c.master.isDead(); }

    /** VIGOR + ABYSS: everything pulled in is slammed down; the nearly dead are executed. */
    static void gravity(CastCtx c) {
        Location f = c.focus.clone();
        for (LivingEntity t : c.mod.targeting.around(c.master, f, 4.0)) {
            Dmg.deal(c, 9000, t, c.spec.damage() * 0.35, false, new Vector(0, -1.2, 0));
            if (!Targeting.isBoss(t) && t.isValid() && t.getHealth() <= Targeting.maxHealth(t) * 0.2) Dmg.deal(c, 9001, t, t.getHealth() + 5, true, null);
            Dmg.effect(t, "slowness", 40, 3);
        }
        if (c.cosmetics) c.mod.fx.safe(() -> { c.mod.fx.sphere(f.clone().add(0, 1, 0), 3, 0xFF6A1F, 40); c.mod.fx.spawn(f, Particle.EXPLOSION_EMITTER, 1, 0, 0, 0, 0); c.mod.fx.sound(f, "combo", 1.2f, 0.6f); });
    }

    /** VIGOR + FATE: a guaranteed impact on up to six enemies anywhere in range. */
    static void impact(CastCtx c) {
        double range = Convergence.PROFILES.get(FATE).range(); int n = 0;
        for (LivingEntity t : c.mod.targeting.around(c.master, c.origin, range)) {
            if (n++ >= 6) break;
            Dmg.deal(c, 9100, t, c.spec.damage() * 0.3, true, new Vector(0, 0.9, 0));
            if (c.cosmetics) c.mod.fx.safe(() -> { c.mod.fx.spawn(t.getLocation(), Particle.EXPLOSION, 1, 0, 0, 0, 0); c.mod.fx.line(c.origin.clone().add(0, 2, 0), t.getLocation().add(0, 1, 0), 0xFFD27F, 0.7); });
        }
    }

    /** ABYSS + AEGIS: the barrier nullifies - enemies lose their buffs, allies lose their debuffs, projectiles vanish. */
    static void nullBarrier(CastCtx c) {
        double r = Modules.radius(c, AEGIS) + 1;
        Util.zone(c, () -> Util.masterOrOrigin(c), r, 160, 10, (list, n) -> {
            for (LivingEntity t : list) Util.strip(t, true);
            Location ctr = Util.masterOrOrigin(c);
            if (masterOk(c)) Util.strip(c.master, false);
            for (org.bukkit.entity.Entity e : ctr.getWorld().getNearbyEntities(ctr, r, r, r)) if (e instanceof LivingEntity le && c.mod.targeting.isAlly(c.master, e)) Util.strip(le, false);
            Util.removeProjectiles(c, ctr, r);
            if (c.cosmetics) c.mod.fx.safe(() -> c.mod.fx.spawn(ctr.clone().add(0, 1, 0), Particle.REVERSE_PORTAL, 30, r / 2, 1, r / 2, 0.1));
        });
    }

    /** RUIN + EVOLUTION: decay that stacks and escalates every second. */
    static void endlessDecay(CastCtx c) {
        Map<UUID, Integer> stacks = new HashMap<>(); Location f = c.focus.clone();
        Util.zone(c, () -> f, 8, 200, 20, (list, n) -> {
            for (LivingEntity t : list) { int s = stacks.merge(t.getUniqueId(), 1, Integer::sum);
                Dmg.deal(c, 9200 + n, t, c.spec.damage() * 0.08 * (1 + 0.25 * Math.min(s, 5)), true, null); Dmg.effect(t, "wither", 40, Math.min(3, s / 2)); }
            if (c.cosmetics) c.mod.fx.safe(() -> { c.mod.fx.spawn(f.clone().add(0, 1, 0), Particle.ASH, 40, 3, 1, 3, 0.02); c.mod.fx.ring(f, 8, 0x39E06B, 30, 0.2); });
        });
    }

    /** FATE + WRAITH: the strongest enemy is marked; the prophecy resolves three seconds later. */
    static void prophecy(CastCtx c) {
        LivingEntity mark = null;
        for (LivingEntity t : c.mod.targeting.around(c.master, c.origin, Convergence.PROFILES.get(FATE).range()))
            if (mark == null || (Targeting.isBoss(t) && !Targeting.isBoss(mark)) || Targeting.maxHealth(t) > Targeting.maxHealth(mark)) mark = t;
        if (mark == null) return; final LivingEntity target = mark; Dmg.effect(target, "glowing", 80, 0);
        c.mod.tasks.later(60, () -> {
            if (!target.isValid()) return; Location tl = target.getLocation();
            Dmg.deal(c, 9300, target, c.spec.damage() * 1.6, true, new Vector(0, 0.4, 0));
            for (LivingEntity n : c.mod.targeting.around(c.master, tl, 4)) if (!n.equals(target)) Dmg.deal(c, 9301, n, c.spec.damage() * 0.3, true, null);
            if (c.cosmetics) c.mod.fx.safe(() -> { c.mod.fx.spawn(tl.clone().add(0, 1, 0), Particle.SOUL, 60, 0.6, 1, 0.6, 0.05); c.mod.fx.sound(tl, "combo", 1f, 1.4f); });
        });
    }

    /** AEGIS + DOMINION: a protected zone - allies regenerate, enemies are slowed, pushed out and lose their target. */
    static void sanctuary(CastCtx c) {
        double r = 8;
        Util.zone(c, () -> Util.masterOrOrigin(c), r, 200, 10, (list, n) -> {
            Location ctr = Util.masterOrOrigin(c);
            if (masterOk(c)) { Dmg.effect(c.master, "regeneration", 40, 0); Dmg.effect(c.master, "resistance", 40, 0); }
            for (org.bukkit.entity.Entity e : ctr.getWorld().getNearbyEntities(ctr, r, r, r)) if (e instanceof LivingEntity le && !le.equals(c.master) && c.mod.targeting.isAlly(c.master, e)) { Dmg.effect(le, "regeneration", 40, 0); Dmg.effect(le, "resistance", 40, 0); }
            for (LivingEntity t : list) { Dmg.effect(t, "slowness", 30, 2); if (!Targeting.isBoss(t)) { try { t.setVelocity(t.getVelocity().add(Util.outward(ctr, t.getLocation(), 0.3))); } catch (Throwable ignored) { } } }
            Util.clearTargets(list);
            if (c.cosmetics) c.mod.fx.safe(() -> c.mod.fx.ring(ctr, r, 0xFFC83D, 40, 0.2));
        });
    }

    /** VIGOR + RUIN + ABYSS: a collapsing singularity that ends in a detonation. */
    static void devourer(CastCtx c) {
        Location f = c.focus.clone(); double r = 10;
        Util.zone(c, () -> f, r, 60, 10, (list, n) -> {
            for (LivingEntity t : list) { Vector pull = f.toVector().subtract(t.getLocation().toVector()); if (pull.length() > 1 && !Targeting.isBoss(t)) { try { t.setVelocity(pull.normalize().multiply(0.6)); } catch (Throwable ignored) { } }
                Dmg.deal(c, 9400 + n, t, c.spec.damage() * 0.05, true, null); }
            if (c.cosmetics) c.mod.fx.safe(() -> c.mod.fx.spawn(f.clone().add(0, 1, 0), Particle.REVERSE_PORTAL, 80, 2, 2, 2, 0.4));
        });
        c.mod.tasks.later(70, () -> {
            for (LivingEntity t : c.mod.targeting.around(c.master, f, r)) Dmg.deal(c, 9499, t, c.spec.damage() * 0.5, false, Util.outward(f, t.getLocation(), 1.6).setY(0.7));
            if (c.cosmetics) c.mod.fx.safe(() -> { c.mod.fx.shockwave(f, r, 0xB31217, Particle.LARGE_SMOKE); c.mod.fx.spawn(f, Particle.EXPLOSION_EMITTER, 3, 1, 1, 1, 0); c.mod.fx.sound(f, "ultimate.impact", 1.3f, 0.7f); });
        });
    }

    /** FATE + EVOLUTION + WRAITH: rewrite the last seconds - the master recovers what was lost and enemy intent is erased. No resurrection. */
    static void rewrite(CastCtx c) {
        if (!masterOk(c)) return;
        AdaptLog.Snap s = c.mod.adapt.snapshotAgo(c.master.getUniqueId(), 5000); double max = Targeting.maxHealth(c.master);
        if (s != null) { double gain = Math.min(max * 0.4, Math.max(0, s.health() - c.master.getHealth())); c.master.setHealth(Math.min(max, c.master.getHealth() + gain)); }
        Util.strip(c.master, false); Util.removeProjectiles(c, c.master.getLocation(), 20); Dmg.effect(c.master, "speed", 100, 1);
        List<LivingEntity> near = c.mod.targeting.around(c.master, c.master.getLocation(), 14); Util.clearTargets(near); for (LivingEntity t : near) Dmg.effect(t, "glowing", 100, 0);
        if (c.cosmetics) c.mod.fx.safe(() -> { c.mod.fx.spawn(c.master.getLocation().add(0, 1, 0), Particle.ENCHANT, 80, 1, 1, 1, 1.5); c.mod.fx.ring(c.master.getLocation(), 3, 0x7FDBFF, 30, 0.2); c.mod.fx.sound(c.master.getLocation(), "combo", 1f, 1.6f); });
    }

    /** AEGIS + EVOLUTION + DOMINION: strong but finite - heavy resistance, a shield, immunity to the damage type hurting the master, suppressed enemies. */
    static void unbreakable(CastCtx c) {
        if (masterOk(c)) {
            Dmg.effect(c.master, "resistance", 160, 2); Dmg.effect(c.master, "absorption", 160, 4);
            c.mod.adapt.grantImmunity(c.master.getUniqueId(), c.mod.adapt.dominantCause(c.master.getUniqueId(), 15_000), 8000);
        }
        Util.zone(c, () -> Util.masterOrOrigin(c), 12, 160, 20, (list, n) -> { for (LivingEntity t : list) Dmg.effect(t, "slowness", 30, 2); Util.clearTargets(list);
            if (c.cosmetics) c.mod.fx.safe(() -> c.mod.fx.ring(Util.masterOrOrigin(c), 12, 0xFFC83D, 48, 0.2)); });
    }

    /** RUIN + DOMINION: a kingdom of ash - a zone where enemies rot, slow and cannot fight. */
    static void kingdomOfAsh(CastCtx c) {
        Location f = c.focus.clone(); double r = 9;
        Util.zone(c, () -> f, r, 200, 10, (list, n) -> {
            for (LivingEntity t : list) { double dot = c.spec.damage() * 0.06 + (Targeting.isBoss(t) ? 0 : Math.min(5, Targeting.maxHealth(t) * 0.01));
                Dmg.deal(c, 9600 + n, t, dot, true, null); Dmg.effect(t, "slowness", 30, 1); Dmg.effect(t, "weakness", 30, 0); }
            Util.clearTargets(list);
            if (c.cosmetics) c.mod.fx.safe(() -> { c.mod.fx.spawn(f.clone().add(0, 0.5, 0), Particle.ASH, 70, r / 2, 0.8, r / 2, 0.01); c.mod.fx.spawn(f.clone().add(0, 0.2, 0), Particle.WHITE_ASH, 40, r / 2, 0.3, r / 2, 0.01); c.mod.fx.ring(f, r, 0xFFC83D, 36, 0.1); });
        });
    }
}
