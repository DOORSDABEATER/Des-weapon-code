package com.des.weapons.azrathiel.combat;

import com.des.weapons.azrathiel.AzrathielModule;
import com.des.weapons.azrathiel.core.*;
import com.des.weapons.azrathiel.data.Settings;
import com.des.weapons.azrathiel.entity.Vael;
import org.bukkit.Location;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.List;
import java.util.random.RandomGenerator;

/** Autonomous combat intelligence: perceive -> assess threats -> choose stance -> choose ability -> act. Runs on a coarse interval. */
public final class Brain {
    private final AzrathielModule mod; private final Vael v; private final RandomGenerator rng = RandomGenerator.getDefault();
    private boolean inCombat, defending; private long lastThreatMs, nextCastAt, nextBasicAt, nextInterceptAt; private LivingEntity primary; private boolean bossAnnounced;

    public Brain(AzrathielModule mod, Vael v) { this.mod = mod; this.v = v; }
    public boolean inCombat() { return inCombat; }
    public boolean defending() { return defending; }
    public LivingEntity primary() { return primary; }
    public void reset() { inCombat = false; defending = false; primary = null; v.target = null; bossAnnounced = false; }

    public void tick(Player m) {
        if (mod.testing) return;                                                       // self-test drives abilities explicitly
        if (v.mode == Vael.Mode.GUARDIAN) { if (v.guardian != null) v.guardian.tick(); return; }
        if (v.mode == Vael.Mode.EXHAUSTED || v.mode == Vael.Mode.DOWN || v.ultimate != null || m.isDead()) return;
        Settings cfg = mod.cfg; long now = System.currentTimeMillis();
        if (v.mode == Vael.Mode.RETURN) { if (v.location().distanceSquared(m.getLocation()) < 16) v.mode = Vael.Mode.FOLLOW; reset(); return; }   // RETURN ignores enemies until it is back
        Location center = v.mode == Vael.Mode.STAY ? v.location() : m.getLocation();
        List<LivingEntity> threats = mod.targeting.around(m, center, v.mode == Vael.Mode.STAY ? 12 : cfg.detectionRadius);
        if (threats.isEmpty()) { if (inCombat && now - lastThreatMs > 2000) endCombat(); return; }
        lastThreatMs = now;

        Location mc = m.getLocation(); double hp = m.getHealth() / Math.max(1, Targeting.maxHealth(m)); boolean boss = false, ranged = false, flying = false, threatened = false;
        int near = 0, within7 = 0; double nearest = 999, hpFracSum = 0; LivingEntity best = null; double bestScore = -1;
        for (LivingEntity t : threats) {
            double dm = t.getLocation().distance(mc), dv = t.getLocation().distance(v.location()); boolean b = Targeting.isBoss(t);
            boolean tm = t instanceof Mob mb && m.equals(mb.getTarget());
            double frac = t.getHealth() / Math.max(1, Targeting.maxHealth(t)); hpFracSum += frac;
            boolean pvp = t instanceof Player pl && mod.adapt.recentPvpAttacker(m.getUniqueId(), pl.getUniqueId(), 10_000);
            double score = ThreatModel.score(new ThreatModel.Threat(dm, dv, frac, Targeting.maxHealth(t), tm, b, Targeting.isRanged(t), Targeting.isFlying(t),
                    mod.adapt.attackerTypes(m.getUniqueId(), 8000).contains(t.getType().name()) ? 4 : 0, pvp, t instanceof Player), v.form());
            if (score > bestScore) { bestScore = score; best = t; }
            boss |= b; ranged |= Targeting.isRanged(t); flying |= Targeting.isFlying(t); nearest = Math.min(nearest, dm);
            if (dm <= 6) { threatened = true; near++; } if (dm <= 7) within7++;
        }
        primary = best; v.target = best;
        double danger = ThreatModel.danger(hp, near, boss, mod.adapt.recentDamage(m.getUniqueId(), 6000));
        defending = v.mode == Vael.Mode.DEFEND || hp < cfg.defendTriggerHealth || near >= 2 || danger > 0.6;

        if (!inCombat) {
            inCombat = true;
            v.say(Category.DETECT, null, null, null, false);
            v.say(Category.COMBAT_START, null, null, null, false);
            if (!v.form().combatCapable() && v.bond.autoRelease && cfg.autoReleaseOnDanger && (boss || danger > 0.55 || threats.size() >= 4)) v.setForm(Form.RELEASED, true);
        }
        if (boss && !bossAnnounced) { bossAnnounced = true; v.say(Category.BOSS, null, null, null, false); }
        if (defending && hp < 0.5) v.say(hp < 0.25 ? Category.INJURY : Category.PROTECT, null, null, null, false);
        if (!v.form().combatCapable() && !cfg.dormantCanFight) return;            // Dormant only watches, warns and (optionally) auto-releases

        double aggr = v.bond.aggression;
        if (now >= nextCastAt) {
            List<AbilityChooser.Cand> cands = mod.executor.candidates(v);
            if (v.mode == Vael.Mode.DEFEND) cands.removeIf(c -> !(c.spec().has(Eidolon.AEGIS) || c.spec().has(Eidolon.DOMINION)));
            var sit = new AbilityChooser.Situation(threats.size(), boss, ranged, flying, hp, threatened, nearest, within7 >= 3, hpFracSum / threats.size(), best.getType().name());
            var pick = AbilityChooser.choose(cands, sit, mod.tracker, rng, 8.0 / Math.max(0.2, aggr));
            if (pick.isPresent()) {
                var o = new AbilityExecutor.Opts(); o.targets = new ArrayList<>(List.of(best));
                var res = mod.executor.cast(v, pick.get().key(), pick.get().spec(), o);
                if (res.ok()) { nextCastAt = now + (long) (cfg.globalCooldownMs / Math.max(0.2, aggr)); return; }
            }
        }
        if (cfg.meleeShove && now >= nextInterceptAt && v.essence.has(cfg.interceptCost)) {
            for (LivingEntity t : threats) if (!Targeting.isBoss(t) && t.getLocation().distance(mc) <= 3.5 && t instanceof Mob mb && m.equals(mb.getTarget())) { shove(m, t); nextInterceptAt = now + cfg.interceptCooldownMs; return; }
        }
        if (now >= nextBasicAt && best.getLocation().distance(v.location()) <= cfg.basicReach + 2) { basicStrike(m, threats, best); nextBasicAt = now + cfg.basicCooldownMs; }
    }

    private void endCombat() { reset(); v.anim.play(AnimState.RECOVERY); v.say(Category.COMBAT_REACT, null, "kill", null, false); }

    private void shove(Player m, LivingEntity t) {
        CastCtx c = new CastCtx(mod, m, null, true, m.getLocation(), t.getLocation()); c.vael = v;
        v.essence.consume(mod.cfg.interceptCost);
        Dmg.deal(c, 1, t, mod.cfg.basicDamage * 0.5, false, Util.outward(m.getLocation(), t.getLocation(), 1.2).setY(0.3));
        v.intercept(t.getLocation());
        mod.fx.begin(); mod.fx.safe(() -> { mod.fx.spawn(t.getLocation().add(0, 1, 0), org.bukkit.Particle.SWEEP_ATTACK, 3, 0.4, 0.3, 0.4, 0); mod.fx.sound(t.getLocation(), "intercept", 1f, 1f); });
        v.say(Category.PROTECT, null, null, null, false);
    }

    private void basicStrike(Player m, List<LivingEntity> threats, LivingEntity primary) {
        CastCtx c = new CastCtx(mod, m, null, true, m.getLocation(), primary.getLocation()); c.vael = v;
        List<LivingEntity> hit = new ArrayList<>(); hit.add(primary);
        for (LivingEntity t : threats) if (hit.size() < 3 && t != primary && t.getLocation().distance(primary.getLocation()) <= 4) hit.add(t);   // four arms: up to three targets
        boolean heavy = rng.nextInt(5) == 0;
        for (LivingEntity t : hit) Dmg.deal(c, 0, t, mod.cfg.basicDamage * (heavy ? 1.6 : 1.0), false, Util.outward(v.location(), t.getLocation(), heavy ? 0.9 : 0.4).setY(0.2));
        v.strike(primary.getLocation(), heavy);
        mod.fx.begin(); mod.fx.safe(() -> { mod.fx.spawn(primary.getLocation().add(0, 1, 0), org.bukkit.Particle.SWEEP_ATTACK, 2, 0.3, 0.3, 0.3, 0); mod.fx.sound(primary.getLocation(), "hit", 0.9f, heavy ? 0.7f : 1f); });
        v.say(Category.COMBAT_REACT, null, null, null, false);
        mod.onCastFinished(v, c);
    }

    /** Where VAELZARION wants to hover while fighting: between the master and the threat (guardian), or near the target (hunter). */
    public Location combatSlot(Player m) {
        if (primary == null || !primary.isValid()) return null;
        Location mc = m.getLocation(), tl = primary.getLocation(); Vector dir = tl.toVector().subtract(mc.toVector()); dir.setY(0);
        if (dir.lengthSquared() < 0.25) return null; dir.normalize();
        double h = mod.cfg.releasedHeight + (v.form().scale - 1) * 0.8;
        Location slot;
        if (v.mode == Vael.Mode.ATTACK && !defending) { Location approach = tl.clone().subtract(dir.clone().multiply(3.0)); slot = approach; if (slot.distance(mc) > mod.cfg.leashRadius) slot = mc.clone().add(dir.clone().multiply(mod.cfg.leashRadius * 0.8)); }
        else slot = mc.clone().add(dir.clone().multiply(defending ? 1.9 : 2.6));
        return slot.add(0, h, 0);
    }
}
