package com.des.weapons.azrathiel.core;

/** Personality only changes WHAT is said and HOW OFTEN. It never touches damage or balance. */
public enum Personality {
    LOYAL, PROTECTIVE, AGGRESSIVE, CALM, DOMINANT, SILENT, CUSTOM;

    /** Multiplier applied to the chance that a line in this category is spoken. */
    public double frequency(Category c, double customMul) {
        double m = switch (this) {
            case LOYAL -> (c == Category.FOLLOW || c == Category.COMMAND || c == Category.SUMMON_DISMISS) ? 1.3 : 1.0;
            case PROTECTIVE -> (c == Category.PROTECT || c == Category.INJURY || c == Category.DETECT) ? 1.4 : 0.95;
            case AGGRESSIVE -> (c == Category.COMBAT_START || c == Category.COMBAT_REACT || c == Category.ABILITY) ? 1.4 : 0.9;
            case CALM -> (c == Category.IDLE || c == Category.FOLLOW) ? 1.2 : 0.8;
            case DOMINANT -> (c == Category.COMMAND || c == Category.RELEASED || c == Category.APOCALYPSE) ? 1.4 : 1.0;
            case SILENT -> c.critical ? 0.9 : 0.12;
            case CUSTOM -> customMul;
        };
        return Math.max(0, Math.min(1.5, m));
    }
}
