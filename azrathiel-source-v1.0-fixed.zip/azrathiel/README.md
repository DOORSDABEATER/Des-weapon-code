# AZRATHIEL — The Eightfold Sovereign  ·  Living entity: VAELZARION
**Secret-rarity weapon for DeS — Dragon Empire SMP**

> **Status, stated plainly:** complete source + resource pack + docs, statically verified and unit-tested where possible.
> **It has NOT been compiled against the Paper API and has NOT been run on a Minecraft server.** No JAR is included, because the
> build environment had no network access to fetch the Paper API. Read `docs/TESTING_REPORT.md` and `docs/KNOWN_LIMITATIONS.md`
> before shipping. An in-game self-test (`/azrathiel admin selftest`) is included so you can verify damage on your own server in minutes.

## What you get
| Area | Contents |
|---|---|
| **Weapon** | `AZRATHIEL` vessel (Secret rarity, PDC-identified, UUID-bound to one master, unbound until first awakened) |
| **Entity** | VAELZARION: 3 forms (Dormant / Released / Eightfold Apocalypse), bone-rig of 11 / 35 / 35 `item_display` bones, four independently animated arms, orbiting fragments, independently spinning halo, eight Eidolon markings |
| **Animation** | 25-state machine with priority rules + critically-damped spring poses (no teleport spam; one root teleport per 2 ticks + client interpolation) |
| **Eidolons** | 8 authorities with real, distinct mechanics (Titan Breaker, Void Consumption, Inevitable Future, Decaying Judgement, Absolute Bastion, Adaptive Response, Spectral Execution, Sovereign Decree) |
| **Convergence** | modular engine for all **255** combinations + the **10 handcrafted** ones, custom ordering, sequential/simultaneous/layered modes |
| **AI** | threat scoring, stance logic, ability chooser with learned effectiveness, guardian positioning, projectile interception, melee shove |
| **Ultimate** | EIGHTFOLD APOCALYPSE: 6 server-timed phases, damage never waits on animation/audio/visuals |
| **LAST GUARDIAN** | finite-energy defence of the master's death location, final shockwave, exhaustion, cooldown |
| **Voice** | **504 authored lines** (17 categories), director with priority/interruption/cooldowns/history/personality, playback architecture incl. Eidolon layering — *recordings not included* |
| **GUI** | AZRATHIEL CONTROL with 13 sections, Convergence Workshop, loadouts/presets, voice, visuals, animation preview |
| **Persistence** | per-bond YAML, async atomic saves, corruption quarantine, orphan-entity purge |
| **Pack** | 39 models, 30 textures, item definitions, sound events, voice manifest (`resourcepack/`) |

## Requirements
* Paper (or fork) **1.21.4 or newer**, Java 21+ (Paper 26.x requires Java 25 on the server; the plugin is Java-21 bytecode and compiled against the 1.21.4 API).
* The DeS resource pack (mandatory for DeS) with `assets/azrathiel/` merged in. **No client mods.** Clients need 1.21.4+ (item-model components).
* Not Folia-compatible (uses the classic Bukkit scheduler).

## Build
```
mvn -q package          # needs network once, for io.papermc.paper:paper-api:1.21.4-R0.1-SNAPSHOT
```
If your server is on a different API line, change the version in `pom.xml` and fix any renamed enum constants the compiler reports
(the code deliberately avoids `Sound`/`PotionEffectType` constants and uses string keys + registries to reduce this).

## Merging into the DeS plugin (you said you will merge it yourself)
1. Copy `src/main/java/com/des/weapons/azrathiel/**` into the DeS project (any package is fine; update the `package` lines if you rename).
2. **Delete `AzrathielPlugin.java` and `plugin.yml`.** There must be exactly one plugin entry point. In the DeS main class:
   ```java
   private AzrathielModule azrathiel;
   @Override public void onEnable()  { /* ...existing... */ azrathiel = new AzrathielModule(this); azrathiel.enable(); }
   @Override public void onDisable() { if (azrathiel != null) azrathiel.disable(); /* ...existing... */ }
   ```
3. Copy `src/main/resources/azrathiel/` into DeS's resources (kept under its own sub-folder so it cannot collide with DeS's `config.yml`).
   It is copied to `plugins/<DeS>/azrathiel/` on first start (`config.yml`, `voice/*.txt`). Bonds are stored in `plugins/<DeS>/azrathiel/bonds/`.
4. No `plugin.yml` edits are needed: the `/azrathiel` command (alias `/azr`) and the permissions are registered programmatically.
5. Resource pack: copy `resourcepack/assets/azrathiel/` into the DeS pack. Keep **your** `pack.mcmeta`. The namespace `azrathiel` cannot collide with `des`.
6. Optional: register the weapon in DeS's rarity/weapon registry by calling `azrathiel.weapon.create(null)` (unbound vessel) — the item is tagged `rarity=SECRET` in its PDC.
7. Give yourself the item: `/azrathiel admin give <player>`.

Dependencies of the module on the host: **none** (no DeS classes are referenced).

## Using it
Hold the vessel: **Right-click** summon/dismiss · **Shift+Right** control panel · **Left-click** cast selected ability at what you aim at · **Shift+Left** next ability · **F** Dormant⇄Released · **Shift+F** EIGHTFOLD APOCALYPSE.
Commands: `/azrathiel [summon|dismiss|release [dormant]|ultimate|follow|stay|defend|attack|return|resume|status|eidolon|convergence|loadout|voice|personality|customize|animation|reload|admin]`.
Permissions: `des.azrathiel.use` (default true) · `des.azrathiel.ultimate` (true) · `des.azrathiel.admin` (op).
Development default is **FULL ACCESS** (`access.full-access: true`). For the live server set it to `false` and optionally enable `progression`.

## Source map
```
core/    pure logic, no server dependency, unit-tested: Eidolon, Convergence engine, AnimationController+Poses, DialogueDirector, VoiceLibrary, AbilityChooser, ThreatModel, Kinematics
model/   ModelDefs (bone hierarchy), RigModel (item_display renderer)
entity/  Vael (physics, forms, animation sync, hooks), VaelManager
combat/  Targeting, Dmg, AbilityExecutor, Modules (8 Eidolons), ComboScripts (10 handcrafted), Brain, UltimateRun, LastGuardian, Fx, Tasks, AdaptLog, SelfTest
voice/   Voice (subtitles, recorded playback, layering, echo)      gui/ Menu, Menus, Prompts      cmd/ AzrathielCommand      data/ Settings, BondData, Store
tools/   run_core_tests.sh · gen_resourcepack.py · verify_pack.py · ParseCheck.java · check_imports.py · stub_check.py · member_check.py
```
