# Model brief: replacing the procedural placeholders with hand-made models

The current models are generated cuboid geometry (see `docs/previews/*.png`, rendered from the real files by `tools/preview_models.py`).
They are rigged correctly and read as an armoured, four-armed, horned guardian with glowing eyes and circuitry, but they are not hand-sculpted art. This brief lets an artist replace them **drop-in**.
Editable starting points: `blockbench/<key>.bbmodel` (generated, **not opened in Blockbench by me** — if one fails to load, the JSON in `resourcepack/assets/azrathiel/models` is the source of truth).

## Technology constraints
* Vanilla Java **block/item models**: cuboids only, rotation per element in {-45, -22.5, 0, 22.5, 45}° on one axis, coordinates in -16..32, UV in 0..16 space (texture PNG may be 16-128 px).
* **No skinned mesh.** Each bone is its own `item_display` entity; the plugin animates bones procedurally (25 states, springs, orbits). So: model each part as a separate rigid piece with the pivot below.
* If you want true skeletal animation with curves exported from Blockbench, that needs ModelEngine/BetterModel and a replacement for `RigModel.java` (the rest of the plugin only calls `render/teleport/remove/valid`). Say so and I will write that adapter once you pick the library.

## Conventions
Forward = model **south** face (+Z). Pivot = model centre (8,8,8). 16 units = 1 block at scale 1; runtime scale per form: Dormant ×1.0, Released ×1.75, Apocalypse ×2.6 (so a 14-unit-wide torso is 1.5 blocks in Released).
Left and right arms share **one symmetric model** (no mirroring), so keep arms symmetric or ask for mirrored variants.

## Parts (file = `assets/azrathiel/models/<key>.json`, item def in `items/<key>.json`)
| Key | Pivot / orientation | Current size (units) | Current elements |
|---|---|---|---|
| `released/torso`, `apoc/torso` | centre of chest; spine at -Z; front plate +Z; pauldrons at x≈±10 | 14 W × 25 H × 11 D (+ pauldron spikes) | 56 / 60 |
| `released/head`, `apoc/head` | centre of skull; **face on south**, horns up/out | 9 × 12 × 8 | 23 / 28 |
| `released/arm_upper` | **top = shoulder joint at (8,8,8)**, hangs down -Y 9.3 u | 5.4 × 17 | 7 |
| `released/arm_lower` | **top = elbow joint at (8,8,8)**, hangs down, claws at the bottom | 5 × 20 | 9 |
| `released/halo_seg`, `apoc/halo_<eidolon>` | centre of segment; long axis = Y (tangent); 8 placed on a ring; chord ≈ 11 u | 3 × 11 | 2 / 2 |
| `frag_a/b/c` | centre; free-floating shard, spins | ≈ 3 × 10 | 2 each |
| `core`, `core_apoc` | centre of gem | 6 / 16 | 3 / 9 |
| `mark/<eidolon>` and `_dim` | flat 16×16 plate, glyph facing ±Z (lit / unlit versions) | 16 × 16 × 0.6 | 1 |
| `dormant/body`, `dormant/ring` | centre of skull-guardian / ring in XY plane | ≈ 9 × 12 / 13 | 11 / 8 |
| `*_glow` (`released/head_glow`, `released/torso_glow`, `apoc/…`, `dormant/body_glow`) | same pivot as the parent bone | thin boxes **proud of the armour by ≥0.1 u** | 3-24 |
| `weapon` | 2D sprite (`textures/item/weapon.png`, 32×32) or a 3D handheld model | — | — |

Budget for reference: a Released guardian is 37 entities / ≈215 elements. Staying within ≈1.5× that is fine; each bone costs one entity, each element costs client GPU only.

## Glow and colour
* Elements with `"tintindex": 0` are recoloured at runtime to the owner's theme colour (use a white/grey texture there). Used by core, halo segments, rings and all `*_glow` models.
* `*_glow` bones render at full brightness: put **only** emissive things on them (eyes, runes, circuitry). Everything else belongs on the armour models.
* `apoc/halo_<eidolon>` and `mark/<eidolon>` use fixed Eidolon colours (vigor FF6A1F · abyss 6A1BFF · fate 7FDBFF · ruin B31217 · aegis 2E6FFF · evolution 39E06B · wraith C9F4F0 · dominion FFC83D).

## Delivery checklist
Same file names · pivots as above · `python3 tools/verify_pack.py` passes · `python3 tools/preview_models.py` looks right · test in game with `/azrathiel animation state <NAME>` (previews any of the 25 states).
