# Voice production: from the text to VAELZARION's voice

**What exists:** 504 authored lines, a recording script with a delivery direction per line, and a processing pipeline that has been *tested on a synthetic signal*.
**What does not exist:** any recording. I cannot create the performance (no speech synthesis is available to me, and a performance is the part that makes the voice feel alive).
The kit makes a human (or licensed AI) performance **deeper, larger, layered and game-ready**; it cannot turn a weak take into a great one.

## 1. Get the raw takes
`python3 tools/voice_kit.py script` writes `voice_kit/voice_script.csv` — one row per line: tier, file name, speaker, form, text, **delivery direction**, whether layer takes are wanted.
* **Tier 1 (212 lines)** brings the entity alive: summon/dismiss, commands, abilities, Released, Apocalypse, LAST GUARDIAN, master-protection, death/respawn.
  Tier 2 (198) is combat chatter, detection, bosses, injuries, Eidolon personalities. Tier 3 (94) is idle/follow/secret.
* Record **dry** (no reverb/EQ/compression), mono WAV, 48 kHz 24-bit, treated room, mic 15-20 cm. A natural *mid-low* male voice works best — the pipeline lowers it further.
  Perform at normal pitch; do not growl or fake depth (the formant-shifted pitch drop supplies the size).
* Name files `<file_name>` exactly as in the CSV (e.g. `summon_dismiss_001.wav`) into `voice_raw/`.
* Optional, best quality: for Apocalypse lines record the eight Eidolon textures as separate in-character takes into `voice_raw/layers/<eidolon>/<file_name>.wav`; they replace the synthesised layers.
* AI voices: only with a licence/consent you have verified for game distribution. Feed the CSV text and direction to the service; export dry WAVs with the same names.

## 2. Process
```
python3 tools/voice_kit.py process --raw voice_raw --layers key --register
```
`--tier 1` to do only tier 1 · `--layers all|key|none` · `--only apocalypse_001,summon_dismiss_003` · `--dry-run` prints the ffmpeg commands. Needs `ffmpeg` with `libvorbis` and `rubberband`.
It trims silence, denoises, **drops pitch with formant shifting** (bigger vocal tract, not just slower tape), shapes tone per register, compresses, normalises to -18 LUFS, and writes mono OGG to
`resourcepack/assets/azrathiel/sounds/voice/<name>.ogg` plus `layers/<eidolon>/<name>.ogg` (22 kHz, -26 LUFS). `--register` then updates `sounds.json`. Finally set `voice.recordings-installed: true`.

### Registers (all in `PROFILES`, tweak freely)
| Register | Used for | Treatment |
|---|---|---|
| calm | default speech, idle, follow, commands | pitch ×0.82, low shelf, light cave echo |
| stern | combat, abilities, bosses, detection, hurt | ×0.77, colder/darker top, mild saturation, short slap echo |
| wrath | master protection, LAST GUARDIAN, near-death alarm | ×0.72 **plus an octave-down blend**, hard-edged mids, colder top |
| released | Released form | ×0.76, large hall echo |
| ultimate | EIGHTFOLD APOCALYPSE | ×0.68 + octave-down blend, chorus doubling, long multi-tap reverb |
| eight Eidolons | lines tagged `[VIGOR]`… and all layer files | Vigor saturated mids · Abyss hollow+echo+chorus · Fate flat, dry, compressed · Ruin bit-crush+clip · Aegis warm, compressed · Evolution presence+tremolo · Wraith high-passed phaser+airy echo · Dominion chorus+hall |

## 3. What was verified (`python3 tools/voice_kit.py selftest`)
On a synthetic vowel-like signal: every profile runs without ffmpeg errors; outputs are mono 44.1 kHz Vorbis; loudness lands at -17 LUFS (target -18); the calm register is measurably deeper
(f0 131 → 107 Hz); duration is preserved; the ultimate register has more sub-octave energy than calm; and **all 28 pairs of Eidolon layers differ in spectral shape** (closest pair 3.2 dB RMS; a negative control proves the check can fail).
**Not verified:** how real speech sounds through these chains. Expect to adjust `pitch` and the EQ values by ear on the first real take, then re-run on everything.

## 4. In game (needs recordings to exist)
Primary plays at `voice × form × Eidolon volume`; layers (Released/Apocalypse only) sit on a ring 2.5 blocks around the entity at 35% of primary, gain 0.25 calm / 0.55 combat / 1.0 ultimate, scaled by the layer-intensity setting; echo repeats scale with the reverb setting.
Runtime **cannot** do distortion/DSP; that is what this pipeline bakes in.

## 5. Extending the dialogue
Add another `*.txt` to `plugins/<DeS>/azrathiel/voice/` (format at the top of `core/VoiceLibrary.java`), `/azrathiel reload`, re-run `voice_kit.py script`. Ids continue per category so existing file names never change.
