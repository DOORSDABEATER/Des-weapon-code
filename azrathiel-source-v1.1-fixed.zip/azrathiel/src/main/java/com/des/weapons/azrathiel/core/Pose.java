package com.des.weapons.azrathiel.core;

public final class Pose {
    public final float[] v = new float[P.COUNT];

    public static Pose idle() {
        Pose p = new Pose();
        p.arm(0, 10, 12, 24).arm(1, 10, 12, 24).arm(2, 20, 28, 32).arm(3, 20, 28, 32);
        p.v[P.HALO_SPEED] = 22; p.v[P.HALO_RADIUS] = 1f; p.v[P.HALO_TILT] = 0;
        p.v[P.FRAG_RADIUS] = 1.5f; p.v[P.FRAG_SPEED] = 40; p.v[P.FRAG_BOB] = 0.12f;
        p.v[P.CORE_SCALE] = 1f; p.v[P.CORE_PULSE] = 0.6f; p.v[P.HOVER_AMP] = 0.10f; p.v[P.HOVER_HZ] = 0.45f;
        p.v[P.BODY_SCALE] = 1f; p.v[P.GLOW] = 0.6f;
        return p;
    }
    public Pose copy() { Pose p = new Pose(); System.arraycopy(v, 0, p.v, 0, v.length); return p; }
    public Pose set(int i, float x) { v[i] = x; return this; }
    public Pose arms(float raise, float spread, float bend) { for (int a = 0; a < 4; a++) arm(a, raise, spread, bend); return this; }
    public Pose arm(int a, float raise, float spread, float bend) { v[P.ARM_RAISE + a] = raise; v[P.ARM_SPREAD + a] = spread; v[P.FORE_BEND + a] = bend; return this; }
    public Pose halo(float speed, float radius, float tilt) { v[P.HALO_SPEED] = speed; v[P.HALO_RADIUS] = radius; v[P.HALO_TILT] = tilt; return this; }
    public Pose frags(float radius, float speed, float bob) { v[P.FRAG_RADIUS] = radius; v[P.FRAG_SPEED] = speed; v[P.FRAG_BOB] = bob; return this; }
    public Pose core(float scale, float pulse) { v[P.CORE_SCALE] = scale; v[P.CORE_PULSE] = pulse; return this; }
    public Pose body(float pitch, float roll, float lean, float sink) { v[P.TORSO_PITCH] = pitch; v[P.TORSO_ROLL] = roll; v[P.LEAN] = lean; v[P.SINK] = sink; return this; }
    public Pose hover(float amp, float hz) { v[P.HOVER_AMP] = amp; v[P.HOVER_HZ] = hz; return this; }
    public Pose scale(float s) { v[P.BODY_SCALE] = s; return this; }
    public Pose glow(float g) { v[P.GLOW] = g; return this; }

    public static void lerp(Pose a, Pose b, float t, float[] out) { for (int i = 0; i < out.length; i++) out[i] = a.v[i] + (b.v[i] - a.v[i]) * t; }
}
