package com.des.weapons.azrathiel.model;

import com.des.weapons.azrathiel.core.Eidolon;
import com.des.weapons.azrathiel.core.Form;

import java.util.ArrayList;
import java.util.List;

/**
 * Bone hierarchy of the three forms. Bone = one item_display; model keys resolve to assets/azrathiel/items/<key>.json.
 * Only uniform leaf scales are used so parent chains never shear.
 */
public final class ModelDefs {
    private ModelDefs() {}
    public enum Group { BODY, HEAD, CORE, ARM_UP, ARM_LO, HALO, FRAG, MARK, RING, OVERLAY }
    public record Bone(String name, int parent, String model, Group group, int idx, float x, float y, float z, float s, boolean glow, boolean tint) {}

    public static final float ARM_LEN = 0.58f;
    private static final float[][] SHOULDER = {{-0.58f, 0.50f, 0f}, {0.58f, 0.50f, 0f}, {-0.50f, -0.22f, 0.12f}, {0.50f, -0.22f, 0.12f}};
    private static final String[] ARM = {"upper_left", "upper_right", "lower_left", "lower_right"};

    public static List<Bone> of(Form f) { return f == Form.DORMANT ? dormant() : humanoid(f); }

    private static List<Bone> dormant() {
        List<Bone> l = new ArrayList<>();
        l.add(new Bone("body", -1, "dormant/body", Group.BODY, 0, 0, 0, 0, 1.0f, false, false));
        l.add(new Bone("core", 0, "core", Group.CORE, 0, 0, 0.02f, 0.16f, 0.30f, true, true));
        for (int i = 0; i < 3; i++) l.add(new Bone("ring_" + i, -1, "dormant/ring", Group.RING, i, 0, 0, 0, 1.35f + 0.3f * i, true, true));
        String[] fr = {"frag_a", "frag_b", "frag_c"};
        for (int i = 0; i < 6; i++) l.add(new Bone("fragment_" + i, -1, fr[i % 3], Group.FRAG, i, 0, 0, 0, 0.28f, false, false));
        l.add(new Bone("body_glow", 0, "dormant/body_glow", Group.OVERLAY, 0, 0, 0, 0, 1f, true, true));       // glowing eyes, full-bright
        return l;
    }

    private static List<Bone> humanoid(Form f) {
        boolean apoc = f == Form.APOCALYPSE; String p = apoc ? "apoc/" : "released/";
        List<Bone> l = new ArrayList<>();
        l.add(new Bone("torso", -1, p + "torso", Group.BODY, 0, 0, 0, 0, 1f, false, false));
        l.add(new Bone("head", 0, p + "head", Group.HEAD, 0, 0, 0.92f, 0.03f, 1f, false, false));
        l.add(new Bone("core", 0, apoc ? "core_apoc" : "core", Group.CORE, 0, 0, 0.12f, 0.33f, apoc ? 0.62f : 0.44f, true, true));
        for (int a = 0; a < 4; a++) l.add(new Bone("arm_" + ARM[a], 0, "released/arm_upper", Group.ARM_UP, a, SHOULDER[a][0], SHOULDER[a][1], SHOULDER[a][2], 1f, false, false));
        for (int a = 0; a < 4; a++) l.add(new Bone("forearm_" + ARM[a], 3 + a, "released/arm_lower", Group.ARM_LO, a, 0, -ARM_LEN, 0, 1f, false, false));
        for (int i = 0; i < 8; i++) l.add(new Bone("halo_" + i, -1, apoc ? "apoc/halo_" + Eidolon.values()[i].id() : "released/halo_seg", Group.HALO, i, 0, 0, 0, apoc ? 1.3f : 1f, true, !apoc));
        String[] fr = {"frag_a", "frag_b", "frag_c"};
        for (int i = 0; i < 8; i++) l.add(new Bone("fragment_" + i, -1, fr[i % 3], Group.FRAG, i, 0, 0, 0, 0.36f, false, false));
        for (int i = 0; i < 8; i++) l.add(new Bone("marking_" + Eidolon.values()[i].id(), 0, "mark/" + Eidolon.values()[i].id() + "_dim", Group.MARK, i, 0, 0, 0, 0.16f, true, false));
        l.add(new Bone("head_glow", 1, p + "head_glow", Group.OVERLAY, 0, 0, 0, 0, 1f, true, true));            // overlays ride on their parent bone exactly
        l.add(new Bone("torso_glow", 0, p + "torso_glow", Group.OVERLAY, 1, 0, 0, 0, 1f, true, true));
        return l;
    }
}
