package com.des.weapons.azrathiel.core;

import java.util.EnumMap;
import java.util.Map;

/** Keyframe poses for every animation state. One-shots have several keys spread evenly over their duration. */
public final class Poses {
    private Poses() {}
    private static final Map<AnimState, Pose[]> KEYS = new EnumMap<>(AnimState.class);

    private static void put(AnimState s, Pose... keys) { KEYS.put(s, keys); }
    private static Pose b() { return Pose.idle(); }

    static {
        put(AnimState.IDLE_FLOAT, b());
        put(AnimState.IDLE_LOOK_AROUND, b().body(0, 4, 0, 0).halo(14, 1f, 0).hover(0.12f, 0.35f));
        put(AnimState.IDLE_OBSERVE_MASTER, b().body(7, -5, 0, 0).arm(0, 18, 20, 30).arm(1, 6, 10, 20).halo(18, 1f, 0));
        put(AnimState.FOLLOW, b().body(3, 0, 6, 0).frags(1.5f, 80, 0.08f).halo(40, 1f, 0).hover(0.07f, 0.6f).arms(-6, 12, 20));
        put(AnimState.FOLLOW_FAST, b().body(6, 0, 18, 0).frags(1.9f, 170, 0.04f).halo(75, 1f, 0).hover(0.04f, 0.8f).arms(-28, 10, 14).glow(0.85f));
        put(AnimState.TURN, b().body(0, 11, 4, 0).halo(65, 1f, 0).frags(1.6f, 90, 0.1f));
        put(AnimState.HOVER_UP, b().body(-6, 0, -8, 0).arms(24, 32, 36).frags(1.7f, 70, 0.1f));
        put(AnimState.HOVER_DOWN, b().body(4, 0, 4, 0).arms(-10, 8, 12).frags(1.3f, 50, 0.1f));
        put(AnimState.COMBAT_IDLE, b().body(8, 0, 0, 0).arms(50, 35, 45).halo(95, 1.05f, 0).frags(1.7f, 125, 0.1f).hover(0.05f, 0.7f).glow(0.9f).core(1.15f, 1.0f));
        put(AnimState.TARGET_LOCK, b().body(12, 0, 6, -0.1f).arms(72, 22, 62).halo(150, 1.1f, 0).frags(1.5f, 170, 0.04f).hover(0.02f, 0.5f).glow(1f).core(1.25f, 1.4f));
        put(AnimState.MELEE_ATTACK,
                b().body(-10, -6, -6, 0).arm(1, -45, 25, 70).arm(3, -30, 20, 60).arm(0, 55, 30, 50).arm(2, 50, 30, 50).glow(1f).halo(140, 1.05f, 0),
                b().body(22, 4, 26, 0).arm(1, 88, 8, 6).arm(3, 80, 12, 10).arm(0, 45, 32, 48).arm(2, 40, 34, 52).glow(1f).core(1.6f, 1.2f).halo(190, 1.1f, 0),
                b().body(8, 0, 4, 0).arms(50, 35, 45).glow(0.9f).halo(95, 1.05f, 0));
        put(AnimState.HEAVY_ATTACK,
                b().body(-14, 0, -10, 0.05f).arms(165, 18, 25).core(1.9f, 1.4f).frags(2.1f, 220, 0.05f).halo(260, 1.15f, 0).glow(1f),
                b().body(-14, 0, -10, 0.05f).arms(172, 14, 18).core(2.1f, 1.5f).frags(2.2f, 260, 0.05f).halo(300, 1.2f, 0).glow(1f),
                b().body(28, 0, 32, -0.1f).arms(15, 20, 8).core(2.4f, 1.6f).glow(1f).halo(320, 1.2f, 0),
                b().body(10, 0, 8, 0).arms(45, 35, 45).glow(0.9f).halo(100, 1.05f, 0));
        put(AnimState.RANGED_ATTACK,
                b().body(-4, 0, -4, 0).arms(70, 40, 40).core(1.4f, 1.2f).glow(1f),
                b().body(6, 0, 10, 0).arms(92, 6, 2).core(1.9f, 1.5f).glow(1f).frags(1.3f, 240, 0.03f),
                b().body(6, 0, 4, 0).arms(55, 30, 40).glow(0.9f));
        put(AnimState.ABILITY_CAST,
                b().body(-6, 0, -4, 0).arms(40, 60, 40).core(1.4f, 1.2f).halo(180, 1.1f, 0).frags(2f, 180, 0.1f).glow(1f),
                b().body(-2, 0, 0, 0.05f).arms(45, 82, 20).core(1.8f, 1.6f).halo(220, 1.2f, 0).frags(2.4f, 240, 0.12f).glow(1f),
                b().body(4, 0, 2, 0).arms(50, 40, 40).glow(0.9f).halo(110, 1.05f, 0));
        put(AnimState.DEFEND, b().body(6, 0, 4, -0.05f).arms(102, 10, 92).halo(110, 1.1f, 0).frags(1.2f, 140, 0.04f).hover(0.03f, 0.6f).glow(1f).core(1.3f, 1.2f));
        put(AnimState.INTERCEPT, b().body(14, 0, 30, 0).arms(96, 8, 70).glow(1f).halo(160, 1.05f, 0).frags(1.2f, 200, 0.03f));
        put(AnimState.DAMAGE_REACTION,
                b().body(0, 0, 0, 0),
                b().body(-16, 12, -12, 0.05f).arms(25, 40, 60).core(0.7f, 2f).glow(0.3f),
                b().body(-4, 3, -3, 0).glow(0.7f));
        put(AnimState.RECOVERY, b().body(4, 0, 0, -0.08f).arms(30, 22, 40).halo(30, 1f, 0).frags(1.5f, 50, 0.08f).glow(0.45f).core(0.9f, 0.5f), b().glow(0.55f));
        put(AnimState.TRANSFORMATION,
                b().body(0, 0, 0, 0).arms(20, 20, 30).core(0.6f, 2f).scale(0.85f).glow(1f).frags(1f, 300, 0.1f),
                b().body(-8, 0, -6, 0.05f).arms(60, 118, 20).core(2.2f, 2.2f).halo(360, 1.4f, 0).frags(2.6f, 340, 0.15f).scale(1.15f).glow(1f),
                b().body(0, 0, 0, 0).arms(35, 60, 30).core(1.4f, 1.0f).halo(120, 1.2f, 0).frags(1.8f, 140, 0.1f).scale(1f).glow(0.9f));
        put(AnimState.RELEASED_IDLE, b().arm(0, 14, 16, 26).arm(1, 14, 16, 26).arm(2, 26, 34, 38).arm(3, 26, 34, 38).halo(28, 1f, 0).frags(1.6f, 52, 0.12f).hover(0.12f, 0.42f).glow(0.7f));
        put(AnimState.ULTIMATE_CHARGE, b().body(-8, 0, -6, 0.08f).arms(152, 55, 20).halo(420, 1.5f, 0).frags(3.0f, 260, 0.18f).core(2.6f, 2.0f).scale(1.2f).glow(1f).hover(0.08f, 0.9f));
        put(AnimState.ULTIMATE_EXECUTION, b().body(8, 0, 15, 0).arms(90, 90, 10).halo(700, 1.7f, 0).frags(3.4f, 400, 0.2f).core(3.2f, 2.6f).scale(1.3f).glow(1f).hover(0.05f, 1.1f));
        put(AnimState.LAST_GUARDIAN, b().body(4, 0, 0, -0.3f).arms(120, 70, 40).halo(120, 1.3f, 0).frags(1.6f, 150, 0.05f).core(1.5f, 1.0f).hover(0.03f, 0.3f).glow(1f));
        put(AnimState.DISMISS,
                b().arms(30, 30, 30).glow(0.8f),
                b().body(0, 0, -4, 0.1f).arms(5, 8, 70).core(0.5f, 0.4f).halo(10, 0.8f, 0).frags(0.8f, 30, 0.02f).scale(0.6f).glow(0.3f),
                b().scale(0.02f).core(0.01f, 0).glow(0f).frags(0.1f, 0, 0).halo(0, 0.1f, 0));
        put(AnimState.RETURN_TO_MASTER, b().body(5, 0, 20, 0).arms(-16, 14, 20).frags(1.7f, 130, 0.05f).halo(60, 1f, 0).glow(0.8f));
    }

    public static Pose[] keys(AnimState s) { return KEYS.get(s); }

    /** Sample the pose of a state at normalized time t (0..1) into out. */
    public static void sample(AnimState s, float t, float[] out) {
        Pose[] k = KEYS.get(s);
        if (k.length == 1) { System.arraycopy(k[0].v, 0, out, 0, out.length); return; }
        float x = Math.max(0f, Math.min(1f, t)) * (k.length - 1);
        int i = Math.min((int) x, k.length - 2); float f = x - i;
        f = f * f * (3f - 2f * f);                                  // smoothstep between keys
        Pose.lerp(k[i], k[i + 1], f, out);
    }
}
