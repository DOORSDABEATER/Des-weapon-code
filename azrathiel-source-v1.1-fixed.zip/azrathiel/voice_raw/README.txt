Put raw DRY recordings here, named exactly as in voice_kit/voice_script.csv (e.g. summon_dismiss_001.wav).
Optional in-character layer takes: voice_raw/layers/<eidolon>/<same file name>.wav
Then: python3 tools/voice_kit.py process --raw voice_raw --layers key --register
